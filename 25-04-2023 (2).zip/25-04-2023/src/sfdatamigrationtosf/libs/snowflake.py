query = {
    "use_schema": "use {database_name}.{schema_name}",
    "use_schema_1": "use {database_name}.{schema_name}",
    "pre_copy_script": "Truncate table {schema_name}.{schema_name}.{table_name}",
    "copy_cmd": "copy into {database_name} .{schema_name}.{table_name} FROM {s3_path} "
                "storage_integration = {snowflake_integration} file_format = (format_name = "
                "{format_name},FIELD_DELIMITER = ',') FORCE = TRUE;",
    "del_cmd": "delete from {database_name}.{schema_name}.{table_name} where {column_name} >= \'{"
               "min_value}\' and {column_name} <= \'{max_value}\'  ",
    "query_id_1": "SELECT QUERY_ID,TOTAL_ELAPSED_TIME,EXECUTION_STATUS,START_TIME,substr("
                  "QUERY_TEXT,1,(len(QUERY_TEXT)-(charindex(')',reverse(QUERY_TEXT))))) "
                  "base_folder  from table({schema_name}.information_schema.query_history())  "
                  "WHERE QUERY_TYPE LIKE 'COPY' "
                  "AND substring(query_text,REGEXP_INSTR(query_text,'[\.]',1,2)+1,((REGEXP_INSTR("
                  "query_text,'FROM')))  -(REGEXP_INSTR(query_text,'[\.]',1,2)+2))='{table_name}' "
                  "and base_folder like '%load_time={timestamp}' order by start_time DESC limit 1",
    "query_id_1_ftp": "SELECT QUERY_ID,TOTAL_ELAPSED_TIME,EXECUTION_STATUS,START_TIME  from table({"
                  "schema_name}.information_schema.query_history())  WHERE QUERY_TYPE LIKE 'COPY' "
                  "AND substring(query_text,REGEXP_INSTR(query_text,'[\.]',1,2)+1,((REGEXP_INSTR("
                  "query_text,'FROM')))  -(REGEXP_INSTR(query_text,'[\.]',1,2)+2))='{table_name}' "
                  "order by start_time DESC limit 1",
    "query_id_2": "SELECT base_folder,sum(row_count) as ROW_COUNT, sum(row_parsed) as ROW_PARSED "
                  "from ( SELECT FILE_NAME,substr(FILE_NAME,1,(len(FILE_NAME)-(charindex('/',"
                  "reverse(FILE_NAME))))) base_folder,row_count,row_parsed FROM {"
                  "schema_name}.information_schema.load_history where TABLE_NAME = '{table_name}' "
                  "AND base_folder like '%/load_time={timestamp}') group by base_folder",
    "query_id_3": "SELECT ERROR_MESSAGE  from table({"
                  "schema_name}.information_schema.query_history())  WHERE QUERY_TYPE LIKE 'COPY' "
                  "AND substring(query_text,REGEXP_INSTR(query_text,'[\.]',1,2)+1,((REGEXP_INSTR("
                  "query_text,'FROM')))  -(REGEXP_INSTR(query_text,'[\.]',1,2)+2))='{table_name}' "
                  "order by start_time DESC limit 1 "

}
