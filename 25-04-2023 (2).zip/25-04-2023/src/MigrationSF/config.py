import os
import configparser
import pymongo
import boto3
from client import send_message

config = configparser.ConfigParser()
if "FLASK_ENV" in os.environ and os.environ["FLASK_ENV"] == "development":
    config.read("dev-config.ini")
    mongo_client = pymongo.MongoClient(config["mongodb"]["host"])
else:
    config.read("config.ini")

session = boto3.session.Session()

# Creating AWS Secret Manager Client
client = session.client(
    service_name='secretsmanager',
    region_name=config['aws']['region_name'],
    aws_access_key_id="AKIAWSJ3O4ZMD22ZOZLW",
    aws_secret_access_key="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"
)

# Creating IAM client 
iam_client = session.client(
    service_name='iam',
    region_name=config['aws']['region_name'])
    

# Creating AWS Glue Client
glue_client = session.client(
    service_name='glue',
    region_name=config['aws']['region_name'])

# Creating the s3 Client
s3_client = session.client(
    service_name='s3'
)

config.update({
        "jwt": {
            "access_secret": 'wz|jvr89ixcsfoof*hcqw2y8mamfl=s'
        },
        "documentdb": {
            "hostname": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_hostname"])["SecretString"],
            "username": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_user"])["SecretString"],
            "password": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_password"])["SecretString"]
                    },
        "snowflake": {
            "conn": config['snowflakecred']['conn'],
            "link_dwh": config['snowflakecred']['link_dwh'],
            "discover_dwh": config['snowflakecred']['discover_dwh'],
            "schema_migration_dwh": config['snowflakecred']['schema_migration_dwh'],
            "data_migration_dwh": config['snowflakecred']['data_migration_dwh'],
            "Role": config['snowflakecred']['Role'],
            "file_format": config['snowflakecred']['file_format'],
            "file_format_ftp": config['snowflakecred']['file_format_ftp'],
            "integration_name": config['snowflakecred']['integration_name'],
            "stage_type": config['snowflakecred']['stage_type'],
            "storage_provider": config['snowflakecred']['storage_provider'],
            "enabled": config['snowflakecred']['enabled'],
            "stage_name": config['snowflakecred']['stage_name'],
            "database_snowflake": config['snowflakecred']['database_snowflake'],
            "schema": config['snowflakecred']['schema'],
            "storage_aws_role_arn" : config['snowflakecred']['storage_aws_role_arn'],
            "storage_allowed_locations" : config['snowflakecred']['storage_allowed_locations'],
            'idea_schema':config['snowflakecred']['idea_schema']
        },
        "kafka": {
            "host": "20.172.185.47:9092",
            "topic_job_register": config['kafkatopics']['topic_job_register'],
            "topic_job_run": config['kafkatopics']['topic_job_run'],
            "topic_sr_s3": config['kafkatopics']['topic_sr_s3'],
            "topic_s3_sf": config['kafkatopics']['topic_s3_sf'],
            "topic_discovery_schema": config['kafkatopics']['topic_discovery_schema'],
            "topic_complexity_analyzer": config['kafkatopics']['topic_complexity_analyzer'],
            "topic_etl_migration": config['kafkatopics']['topic_etl_migration'],
        }
    })

# Connecting to DocumentDB Server
db_client = pymongo.MongoClient("mongodb://ideatfdocdb:ideatfdocdb%21%23@localhost:27017/?authSource=admin&readPreference=primary&directConnection=true&ssl=true&tlsAllowInvalidCertificates=true&tlsAllowInvalidHostnames=true&retryWrites=false")

db = db_client[config["database"]["dbname"]]
