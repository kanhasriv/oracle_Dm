# BaseSampleRepo


## List of microservices in this repo
|Sr no| Name of Microservices | Status| A brief description           | Calls  | Called by|
| :-- | :----		          | :--   | :----                         | :--    | :---     |
| 1   | snowflake Microservice|       | Migration fron TD to snowflake|        |  UI      |

## Key packages used
boto3==1.17.87
botocore
configobj==5.0.6
deepdiff==5.5.0
Flask==1.1.2
Flask-API==2.0
Flask-Cors==3.0.9
Flask-JWT==0.3.2
Flask-JWT-Extended
Flask-RESTful==0.3.8
httplib2==0.9.2
importlib-metadata==2.0.0
isodate==0.6.0
jsondiff==1.2.0
jsonpatch==1.16
jsonpointer==1.10
jsonschema==2.6.0
kafka-python==2.0.2
msrest==0.6.19
msrestazure==0.6.4
numpy==1.18.5
oauthlib==3.1.0
pandas==1.1.2
portalocker==1.7.1
PyJWT
pyodbc==4.0.30
pyOpenSSL==17.5.0
pyserial==3.4
python-apt==1.6.5+ubuntu0.3
python-dateutil==2.8.1
python-debian==0.1.32
pytz==2019.1
pyxdg==0.25
PyYAML==3.12
requests
requests-oauthlib==1.3.0
requests-unixsocket==0.1.5
scp==0.13.3
SecretStorage==2.3.1
service-identity==16.0.0
six==1.11.0
sql-metadata==1.10.0
sshtunnel==0.1.5
tabulate==0.8.7
teradata==15.10.0.21
unattended-upgrades==0.1
vsts==0.1.25
vsts-cd-manager==1.0.2
websocket-client==0.56.0
Werkzeug==1.0.1
xmltodict==0.12.0
zipp==3.4.0
zope.event==4.5.0
zope.interface==4.3.2
pymongo==3.11.3
urllib3
snowflake-connector-python==2.4.0
kafka-python==2.0.2

### List of software tools/language/software packages used
|Sr no| Name of Software | Version| A brief description | Used by Microservice  |
| :-- | :----		     | :--   | :----               | :--    |
|     |                  |       |                     |        |


## Usage 
List out the end point  basic GET, POST, PUT and DELETE REQUEST query

curl mservice:5023/idea/services/migrationsf/link-service, methods= [DELETE]
curl mservice:5023/idea/services/migrationsf/link-service, methods= [GET] 
curl mservice:5023/idea/services/migrationsf/link-service, methods= [POST]
curl mservice:5023/idea/services/migrationsf/link-service-edit, methods= [POST]
curl mservice:5023/idea/services/migrationsf/test-connection, methods = [POST]
curl mservice:5023/idea/services/migrationsf/snowflake-integration-service, methods = [GET]
curl mservice:5023/idea/services/migrationsf/link-service-warehouse-type, methods=[GET]
curl mservice:5023/idea/services/migrationsf/link-service-type, methods=[GET]
curl mservice:5023/idea/services/migrationsf/snowflake-subscription-type, methods=[GET]
curl mservice:5023/idea/services/migrationsf/snowflake-authentication-type, methods=[GET]
curl mservice:5023/idea/services/migrationsf/discover/job-register, methods = [POST]
curl mservice:5023/idea/services/migrationsf/discover/job-register, methods = [GET]
curl mservice:5023/idea/services/migrationsf/discover/job-register, methods = [DELETE]
curl mservice:5023/idea/services/migrationsf/discover/run, methods = [POST]
curl mservice:5023/idea/services/migrationsf/discover/status, methods = [POST]
curl mservice:5023/idea/services/migrationsf/discover/list-job-run-id, methods = [POST]
curl mservice:5023/idea/services/migrationsf/discover/recurrence-pattern, methods = [GET]
curl mservice:5023/idea/services/migrationsf/discover/timezones, methods = [GET]
curl mservice:5023/idea/services/migrationsf/overview, methods = [POST]
curl mservice:5023/idea/services/migrationsf/database-list, methods = [POST]
curl mservice:5023/idea/services/migrationsf/schema-list, methods = [POST]
curl mservice:5023/idea/services/migrationsf/macro, methods = [POST]
curl mservice:5023/idea/services/migrationsf/macro/definition, methods = [POST]
curl mservice:5023/idea/services/migrationsf/discovery-list, methods = [GET]
curl mservice:5023/idea/services/migrationsf/table-list, methods = [POST]
curl mservice:5023/idea/services/migrationsf/column-list, methods = [POST]
curl mservice:5023/idea/services/migrationsf/views, methods = [POST]
curl mservice:5023/idea/services/migrationsf/views/definition, methods = [POST]
curl mservice:5023/idea/services/migrationsf/stored-procedure, methods = [POST]
curl mservice:5023/idea/services/migrationsf/stored-procedure/definition, methods = [POST]
curl mservice:5023/idea/services/migrationsf/snowflake-wh-list, methods = [POST]
curl mservice:5023/idea/services/migrationsf/users, methods = [POST]
curl mservice:5023/idea/services/migrationsf/roles, methods = [POST]
curl mservice:5023/idea/services/migrationsf/table/definition, methods = [POST]
curl mservice:5023/idea/services/migrationsf/user-role-list, methods = [POST]
curl mservice:5023/idea/services/migrationsf/secure-object-list, methods = [POST]
curl mservice:5023/idea/services/migrationsf/share-list, methods = [POST]
curl mservice:5023/idea/services/migrationsf/reader-list, methods = [POST]
curl mservice:5023/idea/services/migrationsf/unassigned-shares, methods = [POST]
curl mservice:5023/idea/services/migrationsf/unassigned-readers, methods = [POST]
curl mservice:5023/idea/services/migrationsf/schema/job-register, method=[POST]
curl mservice:5023/idea/services/migrationsf/schema/job-register, method=[GET]
curl mservice:5023/idea/services/migrationsf/schema/job-register, method=[DELETE]
curl mservice:5023/idea/services/migrationsf/schema/run, method = [POST]
curl mservice:5023/idea/services/migrationsf/schema/status, method = [POST]
curl mservice:5023/idea/services/migrationsf/data/status , methods=[POST]
curl mservice:5023/idea/services/migrationsf/data/run , methods=[POST]
curl mservice:5023/idea/services/migrationsf/data/rerun , methods=[POST]
curl mservice:5023/idea/services/migrationsf/data/data_migration_option , methods=[GET]
curl mservice:5023/idea/services/migrationsf/data/load_type , methods=[GET]
curl mservice:5023/idea/services/migrationsf/data/job-register , methods=[GET]
curl mservice:5023/idea/services/migrationsf/data/job-register , methods=[POST]
curl mservice:5023/idea/services/migrationsf/data/job-register , methods=[DELETE]
curl mservice:5023/idea/services/migrationsf/complexityanalyzer/rule , methods=[GET]
curl mservice:5023/idea/services/migrationsf/complexityanalyzer/files , methods=[POST]
curl mservice:5023/idea/services/migrationsf/complexityanalyzer/job-register , methods=[POST]
curl mservice:5023/idea/services/migrationsf/complexityanalyzer/job-register , methods=[GET]
curl mservice:5023/idea/services/migrationsf/complexityanalyzer/run , methods=[POST]
curl mservice:5023/idea/services/migrationsf/complexityanalyzer/status , methods=[POST]
curl mservice:5023/idea/services/migrationsf/complexityanalyzer/view , methods=[POST]
curl mservice:5023/idea/services/migrationsf/complexityanalyzer/read-file , methods=[POST]
curl mservice:5023/idea/services/migrationsf/complexityanalyzer/job-register , methods=[DELETE]
curl mservice:5023/idea/services/migrationsf/etl_td_snowflake/job-register , methods=[POST]
curl mservice:5023/idea/services/migrationsf/etl_td_snowflake/job-register , methods=[GET]
curl mservice:5023/idea/services/migrationsf/etl_td_snowflake/run , methods=[POST]
curl mservice:5023/idea/services/migrationsf/etl_td_snowflake/status , methods=[POST]
curl mservice:5023/idea/services/migrationsf/etl_td_snowflake/path-variables , methods=[GET]
curl mservice:5023/idea/services/migrationsf/etl_td_snowflake/job-variables , methods=[GET]
curl mservice:5023/idea/services/migrationsf/etl_td_snowflake/read-variables , methods=[POST]
curl mservice:5023/idea/services/migrationsf/etl_td_snowflake/write-variables , methods=[POST]
curl mservice:5023/idea/services/migrationsf/etl_td_snowflake/file-type , methods=[GET]
curl mservice:5023/idea/services/migrationsf/etl_td_snowflake/read-file , methods=[POST]
curl mservice:5023/idea/services/migrationsf/etl_td_snowflake/job-register , methods=[DELETE]
curl mservice:5023/idea/services/migrationsf/datasharing/create-share , methods=[POST]
curl mservice:5023/idea/services/migrationsf/datasharing/edit-share , methods=[POST]
curl mservice:5023/idea/services/migrationsf/datasharing/drop-share , methods=[POST]
curl mservice:5023/idea/services/migrationsf/datasharing/create-reader , methods=[POST]
curl mservice:5023/idea/services/migrationsf/datasharing/drop-reader , methods=[POST]
curl mservice:5023/idea/services/migrationsf/datasharing/assign-shares , methods=[POST]
curl mservice:5023/idea/services/migrationsf/datasharing/revoke-shares , methods=[POST]

## Author

##
src
|-- MigrationSF
|    |-- libs
|    |    |
|    |    |-- access_token.py
|    |    |-- data_schema.py
|    |    |-- error.py
|    |    |-- snowflake.py
|    |    |-- util.py
|    |    
|    |-- routes
|    |    |-- __init__.py
|    |    |-- complexity_analyzer.py
|    |    |-- data_migration.py
|    |	  |-- data_sharing.py
|    |    |-- discover.py
|    |    |-- discover_plane.py
|    |    |-- etl_migration.py
|    |    |-- link_service.py
|    |    |-- schema_migration.py
|    | 
|    |-- app.py
|    |-- config.ini
|    |-- config.py
|    |-- config-dev.ini
|    |-- config-prod.ini
|    |-- config-qa.ini
|    |-- README.md
|    |-- requirements.txt
|    |-- values.yaml
|    
|-- sfcomplexityanalyzer
|    |-- libs
|    |    |-- etl_paths
|    |    |   |-- complexity_analyzer_output.log
|    |    |
|    |    |-- complexity_analyzer.py
|    |    |-- complexity_analyzer_util.py
|    |    |-- util.py
|    | 
|    |-- app.py
|    |-- config.ini
|    |-- config.py
|    |-- config-dev.ini
|    |-- config-prod.ini
|    |-- config-qa.ini
|    |-- requirements.txt
|    |-- values.yaml
|
|-- sfdatamigrationtoblob
|    |-- libs
|    |    |-- data_util.py
|    |
|    |-- app.py
|    |-- config.ini
|    |-- config.py
|    |-- config-dev.ini
|    |-- config-prod.ini
|    |-- config-qa.ini
|    |-- requirements.txt
|    |-- values.yaml
|    
|-- sfdatamigrationtosf 
|    |-- libs
|    |    |-- data_util.py
|    |    |-- snowflake.py
|    |    |-- util.py
|    |
|    |-- app.py
|    |-- config.ini
|    |-- config.py
|    |-- config-dev.ini
|    |-- config-prod.ini
|    |-- config-qa.ini
|    |-- requirements.txt
|    |-- values.yaml
|
|-- sfdiscoveryschema
|    |-- libs
|    |    |-- data_schema.py
|    |    |-- util.py
|    |    |-- teradata.py
|    |    |-- snowflake.py
|    |    |-- schema_util.py
|	 |
|    |-- consumers
|    |    |-- discover.py
|    |    |-- schema_migration.py
|    | 
|    |-- app.py
|    |-- config.ini
|    |-- config.py
|    |-- config-dev.ini
|    |-- config-prod.ini
|    |-- config-qa.ini
|    |-- requirements.txt
|    |-- values.yaml
|    
|-- sfetlmigration
|    |-- libs
|    |    |-- etl_util
|    |    |   |-- drop_fix.py
|    |    |   |-- insert_fix.py
|    |    |   |-- interval_fix.py
|    |    |   |-- Tera_python_with_updfix.py
|    |    |   |-- testing_del_fix.py
|    |    |   |-- timestamp_cast_fix2.py
|    |    |   |-- timestamp_hardcode_fix.py
|    |    |   |-- updateFixTdToSf.py
|    |    |
|    |    |-- etl_migration.py
|    |    |-- etl_migration_util.py
|    |    |-- util.py
|    | 
|    |-- app.py
|    |-- config.ini
|    |-- config.py
|    |-- config-dev.ini
|    |-- config-prod.ini
|    |-- config-qa.ini
|    |-- requirements.txt
|    |-- values.yaml
|
|-- sfjobregister
|    |-- libs
|    |    |-- job_register.py
|    | 
|    |-- app.py
|    |-- config.ini
|    |-- config.py
|    |-- config-dev.ini
|    |-- config-prod.ini
|    |-- config-qa.ini
|    |-- requirements.txt
|    |-- values.yaml
|   
|-- sfjobrun
|    |-- libs
|    |    |-- job_run.py
|    | 
|    |-- app.py
|    |-- config.ini
|    |-- config.py
|    |-- config-dev.ini
|    |-- config-prod.ini
|    |-- config-qa.ini
|    |-- requirements.txt
|    |-- values.yaml