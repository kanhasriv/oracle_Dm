"""
This service contains APIs for the data migration
"""
import traceback
import logging
import uuid
import json
import pyodbc
import pandas as pd
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
from flask import request, jsonify
from config import config, db, client, glue_client, send_message
from libs import error, teradata
from libs.util import (validate_json_schema, abcr_job_registry, abcr_job_run, \
                       abcr_job_registry_delete, get_userdata, response, format_json, get_batch_id)
from libs.access_token import validate_access_token
from libs.secret_manager import get_secret
from bson.json_util import dumps
from kafka import KafkaProducer
# Import app
from . import routes as app

log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'
not_started = "Not Started"
source_id_log = "source_link_service_id {}"
insert_query_log = "db.job_run_detail.insert(): insert_data: {}"
table_type = ["Stage", "Permanent"]
refresh_type = ['Full Load', 'Incremental Load','Adhoc']
split_type = ['No', 'Range', 'Duration']
data_migration_option_list = ["Glue","Copy"]
duration_details = ['Day', 'Week', 'Fortnight', "Month", "Quarter", "Halfyear", "Year"]
column_data_type = ['INTEGER','BYTEINT','BIGINT','SMALLINT']

# Dictionary to store the value by which date/timestamp should be incremented in splitting [Y,M,D]
duration_split = {
    "DAY": [0, 0, 1],
    "WEEK": [0, 0, 7],
    "FORTNIGHT": [0, 0, 15],
    "MONTH": [0, 1, 0],
    "QUARTER": [0, 3, 0],
    "HALFYEAR": [0, 6, 0],
    "YEAR": [1, 0, 0]
}


@app.route("/idea/services/migrationsf/data/status", methods=["POST"])
@validate_json_schema
def data_migration_status():
    """
    This API will list all the data from job_run_detail
    for the job_run_id provided
    :return: json data
    """
    log.info("START")
    try:
        access_details = validate_access_token(request.headers.get('Authorization'),
                                               permissions=["data_migration"])
        if not access_details:
            resp = {"status": "Fail",
                    "category": "Snowflake_Migration",
                    "error_code": "IDEA_ERR_051",
                    "message": "Authorization failed",
                    "data": ""}
            return jsonify(resp), 401

        # Get input json
        data = request.get_json()

        user_data = get_userdata(access_details, data['project_id'])

        # Validate Project ID
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Querying the job_run for relevant job_run_id
        project_id = data['project_id']
        job_run_id = data['job_run_id']
        query = {'job_run_id': data["job_run_id"], 'project_id': data['project_id']}
        job_run_info = db.job_run.find_one(query, {"start_time_str": 0,
                                                   "end_time_str": 0, "_id": 0, 'project_id': 0})
        log.info(job_run_info)
        if job_run_info is None:
            return response(dumps(error.err_088), 404)

        # Checking if the record in job_registry is active or not
        if db.job_registry.find_one({"job_id": job_run_info['job_id'],
                                     "job_type": "data_migration",
                                     "active": True,
                                     "project_id": project_id}) is None:
            return response(dumps(error.err_088), 404)

        # Querying the job_run_detail for relevant job_run_id
        result = list(db.job_run_detail.find({"job_run_id": job_run_id}, {"_id": 0,
                                                                          "start_time_str": 0,
                                                                          "end_time_s3_str": 0,
                                                                          "end_time_sf_str": 0,
                                                                          "splits":0,
                                                                          "file_name":0,
                                                                          "column_name":0,
                                                                          "copy_s3":0,
                                                                          "copy_sf":0,
                                                                          "end_time_s3":0,
                                                                          "end_time_sf":0,
                                                                          "glue_job_run_id_s3":0,
                                                                          "glue_job_run_id_sf":0,
                                                                          "max_value":0,
                                                                          "min_value":0,
                                                                          "start_time_s3":0,
                                                                          }))
        log_url = []
        c = 0
        for itm in result:
            if itm["split"]== True:
                c+=1
            if "aws_log_url_s3" in itm.keys():
                log_url = log_url + [itm["aws_log_url_s3"]]
                del itm["aws_log_url_s3"]
            if "aws_log_url_sf" in itm.keys():
                log_url = log_url + [itm["aws_log_url_sf"]]
                del itm["aws_log_url_sf"]
            
        if c>0:
            result_log_splits = list(db.job_run_detail.find({"job_run_id": job_run_id}, {"_id": 0,"splits":1}))
            for items in result_log_splits:
                if len(items)>0:
                    result_log = items["splits"]
                    for i in result_log:
                        if len(i)>0:
                            if "aws_log_url_s3" in i.keys():
                                log_url = log_url + [i["aws_log_url_s3"]]
                            if "aws_log_url_sf" in i.keys():
                                log_url = log_url + [i["aws_log_url_sf"]]
        result[0]["glue_log_url"] = log_url


        resp = {"status": "Success",
                "category": "Snowflake_Migration",
                "error_code": "",
                "message": "Status of the job has been fetched successfully",
                "data": {"job_run": job_run_info,
                         "job_run_detail": result}}

    except Exception:
        log.error(traceback.format_exc())
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/data_oracle/run", methods=["POST"])
@validate_json_schema
def data_migration():
    """
    This API will do the data migration
    :return: json response
    """
    log.info("START")
    try:

        access_details = validate_access_token(request.headers.get('Authorization'),
                                               permissions=["data_migration"])
        if not access_details:
            resp = {"status": "Fail",
                    "category": "Snowflake_Migration",
                    "error_code": "IDEA_ERR_051",
                    "message": "Authorization failed",
                    "data": ""}
            return jsonify(resp), 401
        # Getting input json
        data = request.get_json()

        # Validating project id
        user_data = get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        project_id = data['project_id']
        socket_flag = "socket" in data
        pipeline_run_id = data["socket"] if socket_flag else None
        pipeline_id = db.canvas_pipeline_run.find_one({"pipeline_run_id": pipeline_run_id})['pipeline_id'] if socket_flag else None

        # Connect to MongoDb and validating job_id
        job_id = data['job_id']
        query = {"job_id": job_id, "active": True, "project_id": project_id}
        log.info("db.job_registry.find(): query: {}".format(query))
        result = db.job_registry.find(query, {"_id": 0})
        result = list(result)
        if not result:
            return response(dumps(error.err_078), 404)
        job_name = result[0]['job_name']
        data = result[0]['data']
        log.debug("data {}".format(data))

        # Validating link_service_id
        source_link_service_id = result[0]['source_link_service_id']
        source_link = db.link_service.find_one(
            {"link_service_id": source_link_service_id})
        if source_link is None:
            return response(dumps(error.err_096), 404)
        log.debug(source_id_log.format(source_link_service_id))
        log.info(source_link)
        sink_link_service_id = result[0]['sink_link_service_id']
        sink_link = db.link_service.find_one(
            {"link_service_id": sink_link_service_id, "active": True})
        if sink_link is None:
            return response(dumps(error.err_094), 404)

        user_id = user_data['user_id']
        if socket_flag:
            send_message("sf_data_run_job_status", {"job_id": job_id, "status": "InProgress", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)

        # Checking if we can connect to Teradata or not
        if source_link['link_service_type'].upper() == "ORACLE DWH":
            # Fetching Teradata connection details
            hostname = source_link["db_hostname"]
            port=source_link["port"]
            database=source_link["database"]
            # Getting the secrets from secret manager
            username = get_secret(source_link_service_id + "-username")
            password = get_secret(source_link_service_id + "-password")

            oracle_conn_string=config["oracle"]["conn"].format(hostname=hostname,
                                                        uid=username,
                                                        pwd=password,
                                                        port=port,
                                                        sid=database)
            # Establishing connection to Oracle
            try:
                conn = pyodbc.connect(oracle_conn_string)
                log.info("Oracle Connection Established..")
            except pyodbc.Error as exception:
                if socket_flag:
                    for item in data['database_details']:
                        table_list = item['tables']
                        schema_name = item['database']
                        for table_name in table_list:
                            send_message("sf_data_run_status", {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":0,"sf_duration":0,"mode":result[0]["load_type"],"service":result[0]["data_migration_option"],"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                    send_message("sf_data_run_job_status", {"job_id": job_id, "status": "Fail", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                log.error(traceback.format_exc())
                return response(dumps(error.err_110), 403)

        # Initializing Kafka
        load_type = result[0]["load_type"]
        server = config["kafka"]["host"]
        try:
            producer = KafkaProducer(bootstrap_servers=server,
                                     value_serializer=lambda x: dumps(x).encode('utf-8'))
        except Exception:
            if socket_flag:
                for item in data['database_details']:
                    table_list = item['tables']
                    schema_name = item['database']
                    for table_name in table_list:
                        send_message("sf_data_run_status", {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":0,"sf_duration":0,"mode":result[0]["load_type"],"service":result[0]["data_migration_option"],"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                send_message("sf_data_run_job_status", {"job_id": job_id, "status": "Fail", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
            log.error(traceback.format_exc())
            return response(dumps(error.err_079), 500)

        # Validating for running job
        query = {"job_id": job_id}
        log.info("db.job_run.find(): query: {}".format(query))
        job_run_result = db.job_run.find(query, {"_id": 0}).sort("start_time", -1).limit(1)
        job_run_result = list(job_run_result)
        if len(job_run_result) == 1:
            if job_run_result[0]['status'] == "InProgress":
                return response(dumps(error.err_0109), 409)
            elif job_run_result[0]['re_run_flag'] == True:
                job_run_id_prev = job_run_result[0]["job_run_id"]
                # Update prev_job_run_id flag to disable
                query = {"job_run_id": job_run_id_prev, "project_id": project_id}
                newvalues = {"$set": {"re_run_flag": False}}
                db.job_run.update_one(query, newvalues)

        # Generating job_run_id and start_time
        start_time = int(datetime.utcnow().timestamp())
        start_time_str = datetime.fromtimestamp(start_time).strftime(idea_date_format)
        job_run_id = str(uuid.uuid4())

        # Producing on abcr_job_run topic
        if config["ABCR"]["flag"] == "Y":
            abcr_status = abcr_job_run("", " ",
                                       "", job_id, job_run_id, job_name,
                                       "migrating data from teradata to snowflake", " ",
                                       user_data["name"], start_time, "InProgress",
                                       config['ABCR']['data'], "")
            if abcr_status == "Fail":
                return response(dumps(error.err_064), 500)

        # Producing on job_run_topic and inserting into metadata
        try:
            end_time = ""
            end_time_str = ""
            status = "InProgress"
            insert_val = {
                "job_id": job_id,
                "job_run_id": job_run_id,
                "project_id": project_id,
                "start_time": start_time,
                "start_time_str": start_time_str,
                "end_time": end_time,
                "end_time_str": end_time_str,
                "status": status,
                "run_by": user_data["name"],
                "load_type": load_type,
                "run_type": "job_run",
                "re_run_flag": False
            }
            log.info("db.job_run.insert(): insert_data: {}".format(insert_val))
            db.job_run.insert(insert_val)
            topic = config["kafka"]["topic_sr_s3"]
            for item in data['database_details']:
                table_list = item['tables']
                schema_name = item['database']
                for table_name in table_list:
                    # Inserting table metadata into job_run_detail
                    query = {"job_id": job_id, "object_name": table_name,"object_parent":schema_name}
                    job_run_detail = db.job_detail.find_one(query, {"_id": 0})
                    job_run_detail["job_run_id"] = job_run_id
                    job_run_detail["start_time"] = start_time
                    job_run_detail["start_time_str"] = start_time_str
                    job_run_detail["status_s3"] = not_started
                    job_run_detail["status_sf"] = not_started
                    if source_link['link_service_type'].upper() == "ORACLE DWH":
                        # Fetching table metadata related details from
                        # table_migration_dashboard collection
                        table_metadata = db.table_migration_dashboard.find_one(
                            {"database_nm": schema_name,
                             "table_nm": table_name, "active": True})
                        job_run_detail["split"] = table_metadata["split"]
                    else:
                        job_run_detail["split"] = False
                    log.info(insert_query_log.format(job_run_detail))
                    db.job_run_detail.insert(job_run_detail)

                    # Sending a job start message
                    data_start = {
                        "job_id": job_id,
                        "job_run_id": job_run_id,
                        "start": start_time,
                        "producer":"oracle",
                        "run_by": user_data["name"],
                        "table_name": table_name,
                        "index": "start",
                        "schema_name": schema_name,
                        "sink_link_service_id": sink_link_service_id,
                        "load_type": load_type,
                        "split": job_run_detail["split"],
                        "split_id": None,
                        "user_id": user_id,
                        "socket_flag": socket_flag,
                        "pipeline_id": pipeline_id,
                        "pipeline_run_id": pipeline_run_id
                        
                    }
                    log.info(data_start)
                    producer.send(topic, value=data_start)

                    # Checking for Split and Load tg752ype related values
                    if source_link['link_service_type'].upper() == "ORACLE DWH":
                        # Checking if split is required or not
                        if table_metadata["split"]:
                            # Fetching Min and Max Value from Teradata
                            tera_query = teradata.data_migration["max_query"].format(
                                column_name=table_metadata["column_nm"],
                                schema_name=schema_name,
                                table_name=table_name)
                            log.info("Max Query : " + tera_query)
                            max_value = pd.read_sql_query(tera_query, conn).iloc[0]["max_value"]

                            log.info(max_value)
                            tera_query = teradata.data_migration["min_query"].format(
                                column_name=table_metadata["column_nm"],
                                schema_name=schema_name,
                                table_name=table_name)
                            if table_metadata["load_type"].upper() == "INCREMENTAL LOAD":
                                # Store the max_value in job_run_detail collection to update the
                                # bookmark value in table_migration_dashboard collection after the
                                # successful job run
                                db.job_run_detail.update_one(
                                    {"job_run_id": job_run_id, "object_name": table_name,
                                     "object_parent": schema_name},
                                    {"$set": {"max_value": str(max_value)}})
                            if "bookmark" in table_metadata and table_metadata["load_type"].upper() == "INCREMENTAL LOAD":
                                min_value = table_metadata["bookmark"]
                                # To convert the string value stored in document DB into
                                # respective DATE and TIMESTAMP
                                if table_metadata['column_data_type'].upper() == "DATE":
                                    min_value = date(
                                        *map(int, min_value.split('-'))) + relativedelta(days=1)
                                    log.info(min_value)
                                elif table_metadata['column_data_type'].upper() == "TIMESTAMP":
                                    min_value = pd.to_datetime(min_value) + pd.DateOffset(days=1)
                                elif table_metadata['column_data_type'].upper() in column_data_type:
                                    min_value = int(min_value) + 1
                            else:
                                min_value = pd.read_sql_query(tera_query, conn).iloc[0]['min_value']
                                log.info("Min Query : " + tera_query)
                                log.info(min_value)

                            if table_metadata["split_type"].upper() == "RANGE":
                                # Splitting into equal ranges if split type is Range
                                splits_required = int(table_metadata["value"][0]["value"])
                                split_range = int(
                                    (int(max_value) - int(min_value)) / splits_required)
                                for i in range(splits_required - 1):
                                    split_id = str(uuid.uuid4())
                                    split_from = int(min_value)
                                    split_to = int(int(min_value) + split_range)
                                    min_value = int(min_value) + split_range + 1
                                    split_response = {
                                        "split_id": split_id,
                                        "split_from": str(split_from),
                                        "split_to": str(split_to),
                                        "column_name": table_metadata["column_nm"],
                                        "split_status_s3": "Not Started",
                                        "split_status_sf": "Not Started"
                                    }

                                    # Inserting the split related metadata into job_run_detail
                                    query = {"job_run_id": job_run_id, "object_name": table_name,
                                             "object_parent": schema_name}
                                    params = {"$push": {"splits": split_response}}
                                    db.job_run_detail.update_one(query, params)

                                    # Producing split related information onto consumer
                                    data_split = {
                                        "job_id": job_id,
                                        "job_run_id": job_run_id,
                                        "split_id": split_id,
                                        "producer":"oracle",
                                        "split": table_metadata["split"],
                                        "source_link_service_id": source_link_service_id,
                                        "sink_link_service_id": sink_link_service_id,
                                        "load_type": job_run_detail['load_type'],
                                        "column_name": table_metadata["column_nm"],
                                        "split_from": split_from,
                                        "split_to": split_to,
                                        "start": start_time,
                                        "start_time_str": start_time_str,
                                        "schema_name": schema_name,
                                        "run_by":user_data["name"],
                                        "table_name": table_name,
                                        "project_id": project_id,
                                        "index": "middle",
                                        "user_id": user_id,
                                        "socket_flag": socket_flag,
                                        "pipeline_id": pipeline_id,
                                        "pipeline_run_id": pipeline_run_id
                                    }
                                    log.info("number of iteration" + str(
                                        i) + " data_split = " + json.dumps(split_response))
                                    producer.send(topic, value=data_split)

                                # Generating the last split
                                split_id = str(uuid.uuid4())
                                split_from = int(min_value)
                                split_to = int(max_value)
                                split_response = {
                                    "split_id": split_id,
                                    "split_from": str(split_from),
                                    "split_to": str(split_to),
                                    "column_name": table_metadata["column_nm"],
                                    "split_status_s3": "Not Started",
                                    "split_status_sf": "Not Started"
                                }

                                # Inserting the split related metadata into job_run_detail
                                query = {"job_run_id": job_run_id, "object_name": table_name,
                                         "object_parent": schema_name}
                                params = {"$push": {"splits": split_response}}
                                db.job_run_detail.update_one(query, params)

                                # Producing split related information onto consumer
                                data_split = {
                                    "job_id": job_id,
                                    "job_run_id": job_run_id,
                                    "split_id": split_id,
                                    "producer":"oracle",
                                    "split": table_metadata["split"],
                                    "source_link_service_id": source_link_service_id,
                                    "sink_link_service_id": sink_link_service_id,
                                    "load_type": job_run_detail['load_type'],
                                    "column_name": table_metadata["column_nm"],
                                    "split_from": split_from,
                                    "split_to": split_to,
                                    "start": start_time,
                                    "start_time_str": start_time_str,
                                    "schema_name": schema_name,
                                    "run_by": user_data["name"],
                                    "table_name": table_name,
                                    "project_id": project_id,
                                    "index": "middle",
                                    "user_id": user_id,
                                    "socket_flag": socket_flag,
                                    "pipeline_id": pipeline_id,
                                    "pipeline_run_id": pipeline_run_id
                                }
                                log.info("Last iteration " + " data_split = " + json.dumps(
                                    split_response))
                                producer.send(topic, value=data_split)

                                # Producing split end message to indicate the end of splits
                                split_end = {
                                    "job_id": job_id,
                                    "job_run_id": job_run_id,
                                    "start": start_time,
                                    "producer":"oracle",
                                    "run_by": user_data["name"],
                                    "table_name": table_name,
                                    "index": "split_end",
                                    "load_type": load_type,
                                    "schema_name": schema_name,
                                    "user_id": user_id,
                                    "socket_flag": socket_flag,
                                    "pipeline_id": pipeline_id,
                                    "pipeline_run_id": pipeline_run_id
                                }
                                log.info(split_end)
                                producer.send(topic, value=split_end)

                            elif table_metadata['split_type'] == "Duration":
                                # Splitting into equal ranges if split type is Duration
                                if min_value <= max_value:
                                    while min_value <= max_value:
                                        split_id = str(uuid.uuid4())
                                        split_required = table_metadata['value'][0]['value'].upper()
                                        if table_metadata['column_data_type'].upper() == "DATE":
                                            split_from = str(min_value)
                                            split_to = min_value + relativedelta(
                                                years=duration_split[split_required][0]
                                                , months=duration_split[split_required][1]
                                                , days=duration_split[split_required][2])
                                            min_value = split_to + relativedelta(days=1)
                                        elif table_metadata[
                                            'column_data_type'].upper() == "TIMESTAMP":
                                            split_from = str(min_value)
                                            split_to = min_value + pd.DateOffset(
                                                years=duration_split[split_required][0]
                                                , months=duration_split[split_required][1]
                                                , days=duration_split[split_required][2])
                                            min_value = split_to + pd.DateOffset(days=1)
                                        split_response = {
                                            "split_id": split_id,
                                            "split_from": str(split_from),
                                            "split_to": str(split_to),
                                            "column_name": table_metadata["column_nm"],
                                            "split_status_s3": "Not Started",
                                            "split_status_sf": "Not Started"
                                        }

                                        # Inserting the split related metadata into job_run_detail
                                        query = {"job_run_id": job_run_id,
                                                 "object_name": table_name,
                                                 "object_parent": schema_name}
                                        params = {"$push": {"splits": split_response}}
                                        db.job_run_detail.update_one(query, params)

                                        # Producing split related information onto consumer
                                        data_split = {
                                            "job_id": job_id,
                                            "job_run_id": job_run_id,
                                            "split_id": split_id,
                                            "producer":"oracle",
                                            "split": table_metadata["split"],
                                            "source_link_service_id": source_link_service_id,
                                            "sink_link_service_id": sink_link_service_id,
                                            "load_type": job_run_detail['load_type'],
                                            "column_name": table_metadata["column_nm"],
                                            "split_from": str(split_from),
                                            "split_to": str(split_to),
                                            "start": start_time,
                                            "start_time_str": start_time_str,
                                            "schema_name": schema_name,
                                            "run_by": user_data["name"],
                                            "table_name": table_name,
                                            "project_id": project_id,
                                            "index": "middle",
                                            "user_id": user_id,
                                            "socket_flag": socket_flag,
                                            "pipeline_id": pipeline_id,
                                            "pipeline_run_id": pipeline_run_id
                                        }
                                        producer.send(topic, value=data_split)
                                else:
                                    split_id = str(uuid.uuid4())
                                    split_response = {
                                        "split_id": split_id,
                                        "split_from": str(min_value),
                                        "split_to": str(min_value),
                                        "column_name": table_metadata["column_nm"],
                                        "split_status_s3": "Not Started",
                                        "split_status_sf": "Not Started"
                                    }

                                    # Inserting the split related metadata into job_run_detail
                                    query = {"job_run_id": job_run_id, "object_name": table_name,
                                             "object_parent": schema_name}
                                    params = {"$push": {"splits": split_response}}
                                    db.job_run_detail.update_one(query, params)

                                    # Producing split related information onto consumer
                                    data_split = {
                                        "job_id": job_id,
                                        "job_run_id": job_run_id,
                                        "split_id": split_id,
                                        "producer":"oracle",
                                        "split": table_metadata["split"],
                                        "source_link_service_id": source_link_service_id,
                                        "sink_link_service_id": sink_link_service_id,
                                        "load_type": job_run_detail['load_type'],
                                        "column_name": table_metadata["column_nm"],
                                        "split_from": str(min_value),
                                        "split_to": str(min_value),
                                        "start": start_time,
                                        "start_time_str": start_time_str,
                                        "schema_name": schema_name,
                                        "run_by": user_data["name"],
                                        "table_name": table_name,
                                        "project_id": project_id,
                                        "index": "middle",
                                        "user_id": user_id,
                                        "socket_flag": socket_flag,
                                        "pipeline_id": pipeline_id,
                                        "pipeline_run_id": pipeline_run_id
                                    }
                                    log.info(data_split)
                                    producer.send(topic, value=data_split)

                                # Producing split end message to indicate the end of splits
                                split_end = {
                                    "job_id": job_id,
                                    "job_run_id": job_run_id,
                                    "start": start_time,
                                    "run_by": user_data["name"],
                                    "index": "split_end",
                                    "load_type": load_type,
                                    "schema_name": schema_name,
                                    "table_name": table_name,
                                    "producer":"oracle",
                                    "user_id": user_id,
                                    "socket_flag": socket_flag,
                                    "pipeline_id": pipeline_id,
                                    "pipeline_run_id": pipeline_run_id
                                }
                                producer.send(topic, value=split_end)

                        elif table_metadata["load_type"].upper() == "INCREMENTAL LOAD" and not \
                        table_metadata["split"]:
                            if "bookmark" in table_metadata:
                                min_value = table_metadata["bookmark"]
                                # To convert the string value stored in document DB into
                                # respective DATE and TIMESTAMP
                                if table_metadata['column_data_type'].upper() == "DATE":
                                    min_value = date(
                                        *map(int, min_value.split('-'))) + relativedelta(days=1)
                                elif table_metadata['column_data_type'].upper() == "TIMESTAMP":
                                    min_value = pd.to_datetime(min_value) + pd.DateOffset(days=1)
                                elif table_metadata['column_data_type'].upper() in column_data_type:
                                     min_value = int(min_value) + 1
                            else:
                                min_value = 0
                            tera_query = teradata.data_migration["max_query"].format(
                                column_name=table_metadata["column_nm"],
                                schema_name=schema_name,
                                table_name=table_name)
                            log.info("Max Query : " + tera_query)
                            max_value = pd.read_sql_query(tera_query, conn).iloc[0]["max_value"]
                            conn.close()
                            db.job_run_detail.update_one(
                                {"job_run_id": job_run_id, "object_name": table_name,
                                 "object_parent": schema_name},
                                {"$set": {"max_value": str(max_value),
                                          "column_name": table_metadata["column_nm"],
                                          "min_value": str(min_value)}})
                            data = {
                                "job_id": job_id,
                                "job_run_id": job_run_id,
                                "source_link_service_id": source_link_service_id,
                                "sink_link_service_id": sink_link_service_id,
                                "load_type": job_run_detail['load_type'],
                                "start": start_time,
                                "start_time_str": start_time_str,
                                "schema_name": schema_name,
                                "run_by": user_data["name"],
                                "table_name": table_name,
                                "project_id": project_id,
                                "split": False,
                                "split_id": None,
                                "index": "middle",
                                "split_from": str(min_value),
                                "split_to": None,
                                "column_name": table_metadata["column_nm"],
                                "user_id": user_id,
                                "socket_flag": socket_flag,
                                "pipeline_id": pipeline_id,
                                "pipeline_run_id": pipeline_run_id
                            }
                            log.info(data)
                            producer.send(topic, value=data)

                        elif table_metadata["load_type"].upper() == "ADHOC":
                            db.job_run_detail.update_one(
                                {"job_run_id": job_run_id, "object_name": table_name,
                                 "object_parent": schema_name},
                                {"$set": {"column_name": table_metadata["column_nm"],
                                          "min_value": table_metadata['value'][0]['value'],
                                          "max_value": table_metadata['value'][1]["value"]}})
                            data = {
                                "job_id": job_id,
                                "job_run_id": job_run_id,
                                "source_link_service_id": source_link_service_id,
                                "sink_link_service_id": sink_link_service_id,
                                "load_type": job_run_detail['load_type'],
                                "start": start_time,
                                "start_time_str": start_time_str,
                                "schema_name": schema_name,
                                "run_by": user_data["name"],
                                "table_name": table_name,
                                "project_id": project_id,
                                "split": False,
                                "split_id": None,
                                "index": "middle",
                                "split_from": table_metadata['value'][0]['value'],
                                "split_to": table_metadata['value'][1]["value"],
                                "column_name": table_metadata['column_nm'],
                                "user_id": user_id,
                                "socket_flag": socket_flag,
                                "pipeline_id": pipeline_id,
                                "pipeline_run_id": pipeline_run_id
                            }
                            log.info(data)
                            producer.send(topic, value=data)

                        else:
                            data = {
                                "job_id": job_id,
                                "job_run_id": job_run_id,
                                "source_link_service_id": source_link_service_id,
                                "sink_link_service_id": sink_link_service_id,
                                "producer":"oracle", 
                                "load_type": job_run_detail['load_type'],
                                "start": start_time,
                                "start_time_str": start_time_str,
                                "schema_name": schema_name,
                                "run_by": user_data["name"],
                                "table_name": table_name,
                                "project_id": project_id,
                                "split": False,
                                "split_id": None,
                                "index": "middle",
                                "split_from": None,
                                "split_to": None,
                                "column_name": None,
                                "user_id": user_id,
                                "socket_flag": socket_flag,
                                "pipeline_id": pipeline_id,
                                "pipeline_run_id": pipeline_run_id
                            }
                            log.info(data)
                            producer.send(topic, value=data)

                    elif source_link['link_service_type'].upper() == "TERADATA FTP":
                        data = {
                            "job_id": job_id,
                            "job_run_id": job_run_id,
                            "source_link_service_id": source_link_service_id,
                            "sink_link_service_id": sink_link_service_id,
                            "load_type": job_run_detail['load_type'],
                            "start": start_time,
                            "start_time_str": start_time_str,
                            "schema_name": schema_name,
                            "run_by": user_data['name'],
                            "table_name": table_name,
                            "project_id": project_id,
                            "split": False,
                            "split_id": None,
                            "index": "middle",
                            "user_id": user_id,
                            "socket_flag": socket_flag,
                            "pipeline_id": pipeline_id,
                            "pipeline_run_id": pipeline_run_id
                        }
                        producer.send(topic, value=data)
            data_end = {
                "job_id": job_id,
                "job_run_id": job_run_id,
                "start": start_time,
                "run_by": user_data["name"],
                "table_name": None,
                "index": "job_end",
                "producer":"oracle",
                "load_type": load_type,
                "schema_name": None,
                "user_id": user_id,
                "socket_flag": socket_flag,
                "pipeline_id": pipeline_id,
                "pipeline_run_id": pipeline_run_id
            }
            producer.send(topic, value=data_end)

        except Exception:
            if socket_flag:
                for item in data['database_details']:
                    table_list = item['tables']
                    schema_name = item['database']
                    for table_name in table_list:
                        send_message("sf_data_run_status", {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":0,"sf_duration":0,"mode":result[0]["load_type"],"service":result[0]["data_migration_option"],"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                send_message("sf_data_run_job_status", {"job_id": job_id, "status": "Fail", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
            log.error(traceback.format_exc())
            return response(dumps(error.err_079), 500)

    except Exception:
        if socket_flag:
            for item in data['database_details']:
                table_list = item['tables']
                schema_name = item['database']
                for table_name in table_list:
                    send_message("sf_data_run_status", {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":0,"sf_duration":0,"mode":result[0]["load_type"],"service":result[0]["data_migration_option"],"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
            send_message("sf_data_run_job_status", {"job_id": job_id, "status": "Fail", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
        log.error(traceback.format_exc())
        return response(dumps(error.err_095), 500)

    log.info("END")
    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Data migration job is in progress",
            "data": {"job_id": job_id, "job_run_id": job_run_id}}
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/data/rerun", methods=["POST"])
@validate_json_schema
def data_migration_rerun():
    """
        This API will do the data migration
        :return: json response
        """
    log.info("START")
    try:
        access_details = validate_access_token(request.headers.get('Authorization'),
                                               permissions=["data_migration"])
        if not access_details:
            resp = {"status": "Fail",
                    "category": "Snowflake_Migration",
                    "error_code": "IDEA_ERR_051",
                    "message": "Authorization failed",
                    "data": ""}
            return jsonify(resp), 401

        # Fetching input json
        data = request.get_json()

        # Validating projectid
        user_data = get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        project_id = data['project_id']

        # Validate for active job
        job_run_id = data['job_run_id']
        query = {"job_run_id": job_run_id, "project_id": project_id}
        log.info("db.job_run.find(): query: {}".format(query))
        job_run_result = db.job_run.find(query, {"id": 0})
        job_run_result = list(job_run_result)
        if len(job_run_result) == 0:
            return response(dumps(error.err_078), 404)
        job_id = job_run_result[0]['job_id']
        load_type = job_run_result[0]['load_type']
        query_job = {"job_id": job_id, "active": True, "project_id": project_id,
                     "job_type": "data_migration"}
        result = db.job_registry.find(query_job, {"_id": 0})
        if not result:
            return response(dumps(error.err_078), 404)
        result = list(result)
        job_name = result[0]['job_name']
        data = result[0]['data']
        log.debug("data {}".format(data))

        # Validating flag for rerun
        if not job_run_result[0]['re_run_flag']:
            return response(dumps(error.err_080), 409)

        # Validating link_service_id
        source_link_service_id = result[0]['source_link_service_id']
        link = db.link_service.find_one({"link_service_id": source_link_service_id, "active": True})
        if link is None:
            return response(dumps(error.err_096), 404)
        log.debug(source_id_log.format(source_link_service_id))
        sink_link_service_id = result[0]['sink_link_service_id']
        link = db.link_service.find_one({"link_service_id": sink_link_service_id, "active": True})
        if link is None:
            return response(dumps(error.err_094), 404)

        # Initializing Kafka
        server = config["kafka"]["host"]
        try:
            producer = KafkaProducer(bootstrap_servers=server,
                                     value_serializer=lambda x: dumps(x).encode('utf-8'))
        except Exception:
            log.error(traceback.format_exc())
            return response(dumps(error.err_079), 500)
        job_run_result = list(job_run_result)
        if len(job_run_result) == 1 and job_run_result[0]['status'] == "InProgress":
            return response(dumps(error.err_0109), 409)

        start_time = int(datetime.utcnow().timestamp())
        start_time_str = datetime.fromtimestamp(start_time).strftime(idea_date_format)

        # Producing message on abcr job_run topic
        if config["ABCR"]["flag"] == "Y":
            abcr_status = abcr_job_run("", " ",
                                       "", job_id, job_run_id, job_name,
                                       "migrating data from teradata to snowflake", " ",
                                       "Harsh", start_time, "InProgress",
                                       config['ABCR']['data'], "")
            if abcr_status == "Fail":
                return response(dumps(error.err_079), 500)

        # Rerun job
        if job_run_result[0]['re_run_flag'] == True:
            job_run_id_prev = job_run_result[0]["job_run_id"]
            # update prev_job_run_id flag to disable
            query = {"job_run_id": job_run_id_prev}
            newvalues = {"$set": {"re_run_flag": False}}
            db.job_run.update_one(query, newvalues)
            check_status = db.job_run_detail.find(query, {"_id": 0})
            check_status = list(check_status)
            topic_td_s3 = config["kafka"]["topic_sr_s3"]
            topic_s3_sf = config["kafka"]["topic_s3_sf"]
            job_run_id = str(uuid.uuid4())
            end_time = ""
            end_time_str = ""
            status = "InProgress"
            insert_val = {
                "job_id": job_id,
                "job_run_id": job_run_id,
                "project_id": project_id,
                "start_time": start_time,
                "start_time_str": start_time_str,
                "end_time": end_time,
                "end_time_str": end_time_str,
                "status": status,
                "load_type": load_type,
                "run_type": "job_rerun",
                "run_by": user_data["name"],
                "parent_run_id": job_run_id_prev,
                "re_run_flag": False
            }
            log.info("db.job_run.insert(): insert_data: {}".format(insert_val))
            db.job_run.insert(insert_val)

            # Checking for failed splits or jobs
            for item in check_status:
                if item['status_s3'] == 'Fail':
                    log.info(item)
                    query = {"job_id": job_id, "object_name": item['object_name']}
                    job_run_detail = db.job_detail.find_one(query, {"_id": 0})
                    job_run_detail["job_run_id"] = job_run_id
                    job_run_detail["start_time"] = start_time
                    job_run_detail["start_time_str"] = start_time_str
                    job_run_detail["status_s3"] = not_started
                    job_run_detail["status_sf"] = not_started
                    job_run_detail['split'] = item['split']
                    if load_type.upper() == "INCREMENTAL LOAD":
                        job_run_detail['max_value'] = item['max_value']
                    log.info(
                        insert_query_log.format(job_run_detail))
                    db.job_run_detail.insert(job_run_detail)

                    # Sending a job start message
                    data_start = {
                        "job_id": job_id,
                        "job_run_id": job_run_id,
                        "start": start_time,
                        "run_by": user_data["name"],
                        "table_name": item['object_name'],
                        "index": "start",
                        "schema_name": item["object_parent"],
                        "sink_link_service_id": sink_link_service_id,
                        "load_type": load_type,
                        "split": job_run_detail["split"],
                        "split_id": None,
                        "user_id": None,
                        "socket_flag": False,
                        "pipeline_id": None,
                        "pipeline_run_id": None
                    }
                    log.info(data_start)
                    producer.send(topic_td_s3, value=data_start)

                    # Checking if splits are present
                    if item['split']:
                        for split in item["splits"]:
                            # Checking the status of split_status_s3 and rerunning the split in
                            # case of failure
                            if split['split_status_s3'] == 'Fail':
                                split_id = str(uuid.uuid4())
                                split_response = {
                                    "split_id": split_id,
                                    "split_from": split["split_from"],
                                    "split_to": split["split_to"],
                                    "column_name": split["column_name"],
                                    "split_status_s3": "Not Started",
                                    "split_status_sf": "Not Started"
                                }

                                # Inserting the split related metadata into job_run_detail
                                query = {"job_run_id": job_run_id,
                                         "object_name": item['object_name'],
                                         "object_parent": item["object_parent"]}
                                params = {"$push": {"splits": split_response}}
                                db.job_run_detail.update_one(query, params)
                                data_split = {
                                    "job_id": job_id,
                                    "job_run_id": job_run_id,
                                    "split_id": split_id,
                                    "split": job_run_detail["split"],
                                    "source_link_service_id": source_link_service_id,
                                    "sink_link_service_id": sink_link_service_id,
                                    "load_type": job_run_detail['load_type'],
                                    "column_name": split["column_name"],
                                    "split_from": split["split_from"],
                                    "split_to": split["split_to"],
                                    "start": start_time,
                                    "start_time_str": start_time_str,
                                    "schema_name": item["object_parent"],
                                    "table_name": item['object_name'],
                                    "run_by": user_data["name"],
                                    "project_id": project_id,
                                    "index": "middle",
                                    "user_id": None,
                                    "socket_flag": False,
                                    "pipeline_id": None,
                                    "pipeline_run_id": None
                                }
                                producer.send(topic_td_s3, value=data_split)

                            # Checking the status of split_status_s3 and rerunning the split in
                            # case of failure
                            elif split['split_status_sf'] == 'Fail':
                                split_id = str(uuid.uuid4())
                                split_response = {
                                    "split_id": split_id,
                                    "split_from": split["split_from"],
                                    "split_to": split["split_to"],
                                    "column_name": split["column_name"],
                                    "split_status_s3": "Success",
                                    "split_status_sf": "Not Started",
                                    "file_name": split['file_name']
                                }
                                # Inserting the split related metadata into job_run_detail
                                query = {"job_run_id": job_run_id,
                                         "object_name": item['object_name'],
                                         "object_parent": item["object_parent"]}
                                params = {"$push": {"splits": split_response}}
                                db.job_run_detail.update_one(query, params)

                                data_split = {
                                    "job_id": job_id,
                                    "job_run_id": job_run_id,
                                    "load_type": load_type,
                                    "source_link_service_id": source_link_service_id,
                                    "sink_link_service_id": sink_link_service_id,
                                    "start": start_time,
                                    "start_time_str": start_time_str,
                                    "schema_name": item["object_parent"],
                                    "table_name": item['object_name'],
                                    "file_name": split['file_name'],
                                    "run_by": user_data["name"],
                                    "split": split,
                                    "split_id": split_id,
                                    "index": "middle",
                                    "user_id": None,
                                    "socket_flag": False,
                                    "pipeline_id": None,
                                    "pipeline_run_id": None
                                }
                                producer.send(topic_td_s3, value=data_split)

                        # Sending a split end message
                        split_end = {
                            "job_id": job_id,
                            "job_run_id": job_run_id,
                            "start": start_time,
                            "run_by": user_data["name"],
                            "table_name": item['object_name'],
                            "index": "split_end",
                            "load_type": load_type,
                            "schema_name": item["object_parent"],
                            "user_id": None,
                            "socket_flag": False,
                            "pipeline_id": None,
                            "pipeline_run_id": None
                        }
                        log.info(split_end)
                        producer.send(topic_td_s3, value=split_end)

                    # Checking for the failed incremental load jobs
                    elif load_type.upper() == "INCREMENTAL LOAD" and not item['split']:
                        db.job_run_detail.update_one(
                            {"job_run_id": job_run_id, "object_name": item['object_name'],
                             "object_parent": item["object_parent"]},
                            {"$set": {"column_name": item['column_name'],
                                      "min_value": item["min_value"]}})
                        data = {
                            "job_id": job_id,
                            "job_run_id": job_run_id,
                            "source_link_service_id": source_link_service_id,
                            "sink_link_service_id": sink_link_service_id,
                            "load_type": job_run_detail['load_type'],
                            "start": start_time,
                            "start_time_str": start_time_str,
                            "schema_name": item["object_parent"],
                            "run_by": user_data["name"],
                            "table_name": item['object_name'],
                            "project_id": project_id,
                            "split": False,
                            "split_id": None,
                            "index": "middle",
                            "split_from": item["min_value"],
                            "split_to": None,
                            "column_name": item['column_name'],
                            "user_id": None,
                            "socket_flag": False,
                            "pipeline_id": None,
                            "pipeline_run_id": None
                        }
                        log.info(data)
                        producer.send(topic_td_s3, value=data)

                    # Checking for the failed adhoc load jobs
                    elif load_type.upper() == "ADHOC":
                        db.job_run_detail.update_one(
                            {"job_run_id": job_run_id, "object_name": item['object_name'],
                             "object_parent": item["object_parent"]},
                            {"$set": {"column_name": item["column_name"],
                                      "min_value": item['min_value'],
                                      "max_value": item['max_value']}})
                        data = {
                            "job_id": job_id,
                            "job_run_id": job_run_id,
                            "source_link_service_id": source_link_service_id,
                            "sink_link_service_id": sink_link_service_id,
                            "load_type": job_run_detail['load_type'],
                            "start": start_time,
                            "start_time_str": start_time_str,
                            "schema_name": item["object_parent"],
                            "run_by": user_data["name"],
                            "table_name": item['object_name'],
                            "project_id": project_id,
                            "split": False,
                            "split_id": None,
                            "index": "middle",
                            "split_from": item['min_value'],
                            "split_to": item['max_value'],
                            "column_name": item['column_name'],
                            "user_id": None,
                            "socket_flag": False,
                            "pipeline_id": None,
                            "pipeline_run_id": None
                        }
                        log.info(data)
                        producer.send(topic_td_s3, value=data)

                    # Checking for FullLoad or FTP jobs
                    else:
                        data = {
                            "job_id": job_id,
                            "job_run_id": job_run_id,
                            "source_link_service_id": source_link_service_id,
                            "sink_link_service_id": sink_link_service_id,
                            "load_type": job_run_detail['load_type'],
                            "start": start_time,
                            "start_time_str": start_time_str,
                            "schema_name": item["object_parent"],
                            "table_name": item['object_name'],
                            "run_by": user_data["name"],
                            "project_id": project_id,
                            "split": False,
                            "split_id": None,
                            "index": "middle",
                            "split_from": None,
                            "split_to": None,
                            "column_name": None,
                            "user_id": None,
                            "socket_flag": False,
                            "pipeline_id": None,
                            "pipeline_run_id": None
                        }
                        log.info(data)
                        producer.send(topic_td_s3, value=data)

                elif item['status_sf'] == 'Fail':
                    query = {"job_id": job_id, "object_name": item['object_name']}
                    job_run_detail = db.job_detail.find_one(query, {"_id": 0})
                    job_run_detail["job_run_id"] = job_run_id
                    job_run_detail["start_time"] = start_time
                    job_run_detail["start_time_str"] = start_time_str
                    job_run_detail["status_s3"] = item["status_s3"]
                    job_run_detail["status_sf"] = not_started
                    job_run_detail['split'] = item['split']
                    if not item['split']:
                        job_run_detail["file_name"] = item["file_name"]
                    if load_type.upper() == "INCREMENTAL LOAD":
                        job_run_detail['max_value'] = item['max_value']
                    log.info(
                        insert_query_log.format(job_run_detail))
                    db.job_run_detail.insert(job_run_detail)

                    # Checking if splits are present
                    if item['split']:
                        for split in item["splits"]:
                            # Checking the status of split_status_s3 and rerunning the split in
                            # case of failure
                            if split['split_status_sf'] == 'Fail':
                                split_id = str(uuid.uuid4())
                                split_response = {
                                    "split_id": split_id,
                                    "split_from": split["split_from"],
                                    "split_to": split["split_to"],
                                    "column_name": split["column_name"],
                                    "split_status_s3": "Success",
                                    "split_status_sf": "Not Started",
                                    "file_name": split['file_name']
                                }
                                # Inserting the split related metadata into job_run_detail
                                query = {"job_run_id": job_run_id,
                                         "object_name": item['object_name'],
                                         "object_parent": item["object_parent"]}
                                params = {"$push": {"splits": split_response}}
                                db.job_run_detail.update_one(query, params)

                                data_split = {
                                    "job_id": job_id,
                                    "job_run_id": job_run_id,
                                    "load_type": load_type,
                                    "source_link_service_id": source_link_service_id,
                                    "sink_link_service_id": sink_link_service_id,
                                    "start": start_time,
                                    "start_time_str": start_time_str,
                                    "schema_name": item["object_parent"],
                                    "table_name": item['object_name'],
                                    "file_name": split['file_name'],
                                    "run_by": user_data["name"],
                                    "split": split,
                                    "split_id": split_id,
                                    "index": "middle",
                                    "user_id": None,
                                    "socket_flag": False,
                                    "pipeline_id": None,
                                    "pipeline_run_id": None
                                }
                                producer.send(topic_s3_sf, value=data_split)

                        # Sending a split end message
                        split_end = {
                            "job_id": job_id,
                            "job_run_id": job_run_id,
                            "start": start_time,
                            "run_by": user_data["name"],
                            "table_name": item['object_name'],
                            "index": "split_end",
                            "load_type": load_type,
                            "schema_name": item["object_parent"],
                            "user_id": None,
                            "socket_flag": False,
                            "pipeline_id": None,
                            "pipeline_run_id": None
                        }
                        log.info(split_end)
                        producer.send(topic_s3_sf, value=split_end)

                    # Checking for the failed incremental load jobs
                    elif load_type.upper() == "INCREMENTAL LOAD" and not item['split']:
                        db.job_run_detail.update_one(
                            {"job_run_id": job_run_id, "object_name": item['object_name'],
                             "object_parent": item["object_parent"]},
                            {"$set": {"column_name": item['column_name'],
                                      "min_value": item["min_value"]}})
                        data = {
                            "job_id": job_id,
                            "job_run_id": job_run_id,
                            "source_link_service_id": source_link_service_id,
                            "sink_link_service_id": sink_link_service_id,
                            "load_type": job_run_detail['load_type'],
                            "start": start_time,
                            "start_time_str": start_time_str,
                            "schema_name": item["object_parent"],
                            "file_name": item['file_name'],
                            "run_by": user_data["name"],
                            "table_name": item['object_name'],
                            "project_id": project_id,
                            "split": False,
                            "split_id": None,
                            "index": "middle",
                            "user_id": None,
                            "socket_flag": False,
                            "pipeline_id": None,
                            "pipeline_run_id": None
                        }
                        log.info(data)
                        producer.send(topic_s3_sf, value=data)

                    # Checking for the failed adhoc load jobs
                    elif load_type.upper() == "ADHOC":
                        db.job_run_detail.update_one(
                            {"job_run_id": job_run_id, "object_name": item['object_name'],
                             "object_parent": item["object_parent"]},
                            {"$set": {"column_name": item["column_name"],
                                      "min_value": item['min_value'],
                                      "max_value": item['max_value']}})
                        data = {
                            "job_id": job_id,
                            "job_run_id": job_run_id,
                            "source_link_service_id": source_link_service_id,
                            "sink_link_service_id": sink_link_service_id,
                            "load_type": job_run_detail['load_type'],
                            "start": start_time,
                            "start_time_str": start_time_str,
                            "schema_name": item["object_parent"],
                            "file_name": item['file_name'],
                            "run_by": user_data["name"],
                            "table_name": item['object_name'],
                            "project_id": project_id,
                            "split": False,
                            "split_id": None,
                            "index": "middle",
                            "user_id": None,
                            "socket_flag": False,
                            "pipeline_id": None,
                            "pipeline_run_id": None
                        }
                        log.info(data)
                        producer.send(topic_s3_sf, value=data)

                    # Checking for FullLoad or FTP jobs
                    else:
                        data = {
                            "job_id": job_id,
                            "job_run_id": job_run_id,
                            "load_type": job_run_detail['load_type'],
                            "source_link_service_id": source_link_service_id,
                            "sink_link_service_id": sink_link_service_id,
                            "start": start_time,
                            "start_time_str": start_time_str,
                            "schema_name": item["object_parent"],
                            "table_name": item['object_name'],
                            "file_name": item['file_name'],
                            "run_by": user_data["name"],
                            "project_id": project_id,
                            "split": False,
                            "split_id": None,
                            "index": "middle",
                            "user_id": None,
                            "socket_flag": False,
                            "pipeline_id": None,
                            "pipeline_run_id": None
                        }
                        producer.send(topic_s3_sf, value=data)

            data_end = {
                "job_id": job_id,
                "job_run_id": job_run_id,
                "start": start_time,
                "run_by": user_data["name"],
                "table_name": None,
                "index": "job_end",
                "load_type": load_type,
                "schema_name": None,
                "user_id": None,
                "socket_flag": False,
                "pipeline_id": None,
                "pipeline_run_id": None
            }
            producer.send(topic_s3_sf, value=data_end)

    except Exception:
        log.error(traceback.format_exc())
        return response(dumps(error.err_095), 500)

    log.info("END")
    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Data migration job is in progress",
            "data": {"job_id": job_id, "job_run_id": job_run_id}}
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/data/job-register", methods=["GET"])
@validate_json_schema
def get_data_migration_job():
    """
    This API will list down the schema migration jobs
    :return: json response
    """
    log.info("START")

    try:
        access_details = validate_access_token(request.headers.get('Authorization'),
                                               permissions=["data_migration"])
        if not access_details:
            resp = {"status": "Fail",
                    "category": "Snowflake_Migration",
                    "error_code": "IDEA_ERR_051",
                    "message": "Authorization failed",
                    "data": ""}
            return jsonify(resp), 401

        # Fetching input json
        data = request.args

        # Validating Project ID
        user_data = get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        project_id = data['project_id']

        # Fetching relevant information from metadata
        query = {"job_type": "data_migration", "active": True, "project_id": project_id}
        if "filter" in data:
            filter_param = {"$regex": "(?i)" + data['filter']}
            query['$or'] = [
                {"job_name": filter_param},
                {"load_type": filter_param},
                {"data_migration_option": filter_param},
                {"data.database_details.database": filter_param},
                {"data.database_details.tables": filter_param},
                {"created_by": filter_param}
            ]
        log.info(query)
        result = list(db.job_registry.find(query, {"_id": 0, 'active': 0, "created_at_str": 0,
                                                   "project_id": 0}).sort([("created_at", -1)]))
        log.debug(result)
        if result == []:
            return response(dumps(error.err_088), 404)

        for job in range(len(result)):
            source_link_service_name = db.link_service.find_one(
                {"link_service_id": result[job]['source_link_service_id']},
                {"_id": 0, "link_service_name": 1})
            sink_link_service_name = db.link_service.find_one(
                {"link_service_id": result[job]['sink_link_service_id']},
                {"_id": 0, "link_service_name": 1})
            result[job]['source_link_service_name'] = source_link_service_name['link_service_name']
            result[job]['sink_link_service_name'] = sink_link_service_name['link_service_name']
            result[job]['project_name'] = user_data['project_name']

        resp = {"status": "Success",
                "category": "Snowflake_Migration",
                "error_code": "",
                "message": "Data migration job fetched successfully",
                "data": result}

    except Exception:
        log.error(traceback.format_exc())
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/data_oracle/job-register", methods=["POST"])
@validate_json_schema
def create_data_migration_job():
    """
    This API will insert job details in job registry table
    """
    try:
        
        access_details = validate_access_token(request.headers.get('Authorization'),
                                               permissions=["data_migration"])
        if not access_details:
            resp = {"status": "Fail",
                    "category": "Snowflake_Migration",
                    "error_code": "IDEA_ERR_051",
                    "message": "Authorization failed",
                    "data": ""}
            return jsonify(resp), 401
        
        # Get json data
        data = request.get_json()

        # Validate Project ID
        user_data = get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        project_id = data['project_id']
        project_name = user_data['project_name']

        # Fetching source link service details
        source_link_service_id = data['source_link_service_id']
        source_link_service = db.link_service.find_one(
            {"link_service_id": source_link_service_id})
        if source_link_service is None:
            return response(dumps(error.err_096), 404)
        log.debug(source_id_log.format(source_link_service_id))


        # Fetching sink link service details
        sink_link_service_id = data['sink_link_service_id']
        sink_link_service = db.link_service.find_one(
            {"link_service_id": sink_link_service_id, "active": True})
        if sink_link_service is None:
            return response(dumps(error.err_094), 404)

        # Validate for duplicate name
        job_name = data['job_name']
        job_exist = db.job_registry.find_one({'job_name': job_name, "active": True,
                                              "job_type": "data_migration",
                                              "project_id": project_id})
        if job_exist is not None:
            resp = {"status": "Fail",
                    "category": "Snowflake_Migration",
                    "error_code": "IDEA_ERR_061",
                    "message": "Duplicate entry for 'job_name' : '{}'".format(job_name),
                    "data": ""}
            return jsonify(resp), 400

        # Validate for active integration
        if data['data_migration_option'].upper() == "COPY":
            query = {"link_service_id": sink_link_service_id, "active": True}
            resp = db.link_service.find_one(query, {"is_active": 1})['is_active']
            if resp == 'N':
                return response(dumps(error.err_083), 403)

        # Creating required parameters
        project_id = data['project_id']
        project_name = user_data['project_name']
        job_id = str(uuid.uuid4())
        job_name = data['job_name']
        data["job_id"] = job_id
        created_at = int(datetime.utcnow().timestamp())
        created_at_str = str(datetime.fromtimestamp(created_at).strftime(idea_date_format))
        job_data = data["data"]

        # Validating if given table is present in table migration dashboard
        for item in job_data['database_details']:
            schema = item['database']
            table = item['tables']
            for item_table in table:
                object_name = item_table
                load_type = data['load_type']
                object_parent = schema
                if source_link_service['link_service_type'] == 'oracle DWH':
                    query = {"active": True, "table_nm": object_name, "database_nm": object_parent,
                            "load_type": load_type,"table_type":"permanent"}
                    log.info(query)
                    table_metadata = db.table_migration_dashboard.find_one(query)
                    if not bool(table_metadata):
                        table_error = error.err_091.copy()
                        table_error['message'] = table_error['message'].format(
                            table_nm=object_parent + "." + object_name,
                            load=load_type)
                        return response(dumps(table_error), 409)

        # producing on to job_register topic
        if config["ABCR"]["flag"] == "Y":
            configuration = {
                "endPoint": {"url": "/idea/services/migrationsf/data/run", "method": "POST"},
                "params": {"jobId": job_id}
            }
            parameters = {
                "jobType": "data_migration",
                "jobName": job_name,
                "loadType": data["load_type"],
                "dataMigrationOption": data["data_migration_option"],
                "source": {
                    "type": source_link_service["link_service_type"],
                    "linkServiceID": source_link_service["link_service_id"],
                    "bowID": data["source_link_service_id"]
                },
                "destination": {
                    "type": sink_link_service["link_service_type"],
                    "linkServiceID": sink_link_service["link_service_id"],
                    "bowID": data["source_link_service_id"]
                },
                "data": data["data"],
            }

            job_status = abcr_job_registry(job_id, True, "Other", configuration,
                                           parameters,
                                           created_at,
                                           config['ABCR']['data'], job_name,
                                           "MigrationSF-Data Migration",
                                           " ", " ", " ", " ",
                                           project_id, user_data["name"], " ", " ", project_name)
            if job_status == "Fail":
                return response(dumps(error.err_063), 500)

        # Insert into job_registry table
        job_register_df = {
            "job_type": "data_migration",
            "job_name": data["job_name"],
            "job_id": job_id,
            "load_type": data['load_type'],
            "project_id": project_id,
            "source_link_service_id": data["source_link_service_id"],
            "sink_link_service_id": data["sink_link_service_id"],
            "data_migration_option": data["data_migration_option"],
            "data": data["data"],
            "created_by": user_data["name"],
            "created_at": created_at,
            "created_at_str": created_at_str,
            "active": True
        }
        log.info("db.job_registry.insert(): data: {}".format(data))
        db.job_registry.insert_one(job_register_df)
        resp = {"status": "Success",
                "category": "Snowflake_Migration",
                "error_code": "",
                "message": "Job registered successfully",
                "data": {"job_id": job_id}}

        # Insert into job_detail table
        object_type = "Table"
        for item in job_data['database_details']:
            schema = item['database']
            table = item['tables']
            for item_table in table:
                item_id = str(uuid.uuid4())
                object_name = item_table
                load_type = data['load_type']
                object_parent = schema
                insert_data = {
                    "item_id": item_id,
                    "job_id": job_id,
                    "object_type": object_type,
                    "object_name": object_name,
                    "load_type": load_type,
                    "object_parent": object_parent
                }
                log.info("db.job_detail.insert(): insert_data: {}".format(insert_data))
                db.job_detail.insert(insert_data)


    except Exception as e_error:
        log.error(traceback.format_exc())
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/data/job-register", methods=["DELETE"])
@validate_json_schema
def delete_data_migration_job():
    """
    This API will delete job record from job registry table
    :return: json response
    """
    log.info("START")
    try:
        access_details = validate_access_token(request.headers.get('Authorization'),
                                               permissions=["data_migration"])
        if not access_details:
            resp = {"status": "Fail",
                    "category": "Snowflake_Migration",
                    "error_code": "IDEA_ERR_051",
                    "message": "Authorization failed",
                    "data": ""}
            return jsonify(resp), 401

        # Get json data
        data = request.args

        # Validate Project ID
        user_data = get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        project_id = data['project_id']

        # Validate if the job exists
        job_id = data["job_id"]
        job_register_df = db.job_registry.find_one(
            {"job_id": data['job_id'], "project_id": project_id},
            {'_id': 0, 'execution_schedule': 1,
             'created_at': 1,
             'source_link_service_type': 1,
             'active': 1})
        log.info(job_register_df)
        if not bool(job_register_df):
            return response(dumps(error.err_078), 404)
        if not job_register_df['active']:
            return response(dumps(error.err_085), 404)

        # Produce message onto ABCR
        if config["ABCR"]["flag"] == "Y":
            job_status = abcr_job_registry_delete(job_id, False)
            if job_status == "Fail":
                return response(dumps(error.err_063), 500)

        # Delete from metadata and aws glue job
        db.job_registry.update_one({"job_id": job_id}, {'$set': {'active': False}})
    except Exception:
        log.error(traceback.format_exc())
        return response(dumps(error.err_095), 500)
    log.info("END")
    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Record deleted successfully",
            "data": ""}
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/data/data_migration_option", methods=["GET"])
def data_migration_option():
    """
        This API get the list of data_migration API's
        :return: json response
        """
    log.info("START")
    access_details = validate_access_token(request.headers.get('Authorization'),
                                           permissions=["data_migration"])
    if not access_details:
        resp = {"status": "Fail",
                "category": "Snowflake_Migration",
                "error_code": "IDEA_ERR_051",
                "message": "Authorization failed",
                "data": ""}
        return jsonify(resp), 401
    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Data migration options fetched successfully",
            "data": {"load_type": data_migration_option_list}}

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/data/load_type", methods=["GET"])
def load_type():
    """
        This API get the list of data_migration API's
        :return: json response
        """
    log.info("START")
    access_details = validate_access_token(request.headers.get('Authorization'),
                                           permissions=["data_migration"])
    if not access_details:
        resp = {"status": "Fail",
                "category": "Snowflake_Migration",
                "error_code": "IDEA_ERR_051",
                "message": "Authorization failed",
                "data": ""}
        return jsonify(resp), 401
    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Load type fetched successfully",
            "data": {"load_type": refresh_type}}

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/data/update_incremental", methods=["POST"])
@validate_json_schema
def incremental_table_update():
    """
        This API update the dashboard collection
        :return: json response
        """
    log.info("START")

    # Authorising the user
    access_details = validate_access_token(request.headers.get('Authorization'),
                                           permissions=["data_migration"])
    if not access_details:
        resp = {"status": "Fail",
                "category": "Snowflake_Migration",
                "error_code": "IDEA_ERR_051",
                "message": "Authorization failed",
                "data": ""}
        return jsonify(resp), 401
    try:
        data = request.get_json()
        info_df = pd.json_normalize(data["data"])
        for i in info_df.index:
            database_table = info_df["database_table"][i]
        table_lst = []

        # Creting a list of database and checking the duplicate database name
        database_nm_lst = [i['database'] for i in database_table]
        if sorted(database_nm_lst) != sorted(set(database_nm_lst)):
            return response(dumps(error.err_074), 400)

        # Checking for a valid entry
        database_table_df = pd.DataFrame(database_table)
        for index, row in database_table_df.iterrows():

            # Creating a list of tables and checking the duplicate table in a database
            tbl_lst = list(table_name["table_nm"] for table_name in row["tables"])
            if sorted(tbl_lst) != sorted(set(tbl_lst)):
                return response(dumps(error.err_074), 400)
            table_lst += tbl_lst
            db_nm = row["database"]

            for itms in row["tables"]:
                if (itms["split_type"] in ["Range", "Duration"] or itms[
                    "load_type"] in ['Incremental Load', 'Adhoc']) and (
                        "column_nm" not in itms.keys()):
                    log.info("column_nm key is missing")
                    return response(dumps(error.err_074), 400)
                if (itms["split_type"] == "No" and itms["load_type"] != "Adhoc") and (
                        itms["value"][0] or itms["value"][1]):
                    log.info("Some Values are passed in values for Split type No")
                    return response(dumps(error.err_074), 400)
                if (itms["split_type"] in ["Range", "Duration"] ) and not(itms["value"][0]):
                    log.info("Atleast one value should be passed")
                    return response(dumps(error.err_074), 400)
                if (itms["split_type"] in ["Range","Duration"]) and (itms["value"][1]):
                    log.info("Second Value is passed in values for Split type Range or Duration")
                    return response(dumps(error.err_074), 400)
                if (itms["load_type"] == "Adhoc") and (itms["split_type"]!="No"):
                    log.info("Adhoc doesn't support split")
                    return response(dumps(error.err_074), 400)
                if (itms["load_type"] == "Adhoc") and not (all(var for var in itms['value'])):
                    log.info("For adhoc from and to both are required")
                    return response(dumps(error.err_074), 400)


                # Checking for the supported split type and datatype of the column 
                if "column_nm" in itms.keys():
                    column_detail = [db.idea_column_discovery_attr.find_one(
                        {"database_vendor": "TERADATA", "database_nm": db_nm,
                         "table_nm": itms["table_nm"], "column_nm": itms["column_nm"]},
                        {"_id": 0, "data_type": 1})]
                    if column_detail[0] is None:
                        log.info("column details not found for column {}".format(itms["column_nm"]))
                        column_error = error.err_066.copy()
                        column_error['message'] = column_error['message'].format(
                            column=itms["column_nm"])
                        return response(dumps(column_error), 400)

                    # Checking for the compatibility of column datatype and split type 
                    if (itms["split_type"] == "Range") and (
                            column_detail[0]["data_type"].upper() not in column_data_type):
                        log.info(
                            "column data type is not compatible with split type for column {}".format(
                                itms["column_nm"]))
                        column_error = error.err_090.copy()
                        column_error['message'] = column_error['message'].format(
                            column=itms["column_nm"], split_type=itms["split_type"])
                        return response(dumps(column_error), 400)

                    if (itms["split_type"] == "Duration") and (
                            column_detail[0]["data_type"].lower() not in ["date", "timestamp"]):
                        log.info(
                            "column data type is not compatible with split type for column {}".format(
                                itms["column_nm"]))
                        column_error = error.err_090.copy()
                        column_error['message'] = column_error['message'].format(
                            column=itms["column_nm"], split_type=itms["split_type"])
                        return response(dumps(column_error), 400)

                    # Adding the datatype of the column
                    itms["column_data_type"] = column_detail[0]["data_type"]
                if itms["split_type"] in ["Range", "Duration"]:
                    itms["split"] = True
                else:
                    itms["split"] = False

        log.info("Detials validated successfully")
        log.info("Updating collection started")

        # Updating the dashboard collection
        try:
            for index, row in database_table_df.iterrows():
                db_nm = row["database"]
                for itms in row["tables"]:
                    itms['table_type'] = "permanent"
                    db.table_migration_dashboard.update_one(
                        {"database_nm": db_nm, "table_nm": itms["table_nm"]}, {"$set": itms})
        except Exception:
            log.error(traceback.format_exc())
            return response(dumps(error.err_067), 400)
        log.info("collection updated successfully")
    except Exception:
        log.info("failed to update")
        log.error(traceback.format_exc())
        return response(dumps(error.err_095), 500)
    log.info("END")
    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Records updated succcessfully",
            "data": ""}
    return jsonify(resp)


@app.route("/idea/services/migrationsf/data/migration_split_type", methods=["GET"])
def split_type_details():
    """
        This API get the list of split type
        :return: json response
        """
    log.info("START")
    access_details = validate_access_token(request.headers.get('Authorization'),
                                           permissions=["data_migration"])
    if not access_details:
        resp = error.err_051
        return jsonify(resp), 401

    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Split type fetched successfully",
            "data": {"split_type": split_type}}

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/data/migration_split_duration", methods=["GET"])
def split_duration_details():
    """
        This API get the list of split duration
        :return: json response
        """
    log.info("START")
    access_details = validate_access_token(request.headers.get('Authorization'),
                                           permissions=["data_migration"])
    if not access_details:
        resp = error.err_051
        return jsonify(resp), 401

    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Duration type fetched successfully",
            "data": {"duration": duration_details}}

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/data/table_type", methods=["GET"])
def get_table_type():
    """
        This API get the list of table_type
        :return: json response
        """
    log.info("START")
    access_details = validate_access_token(request.headers.get('Authorization'),
                                           permissions=["data_migration"])
    if not access_details:
        resp = error.err_051
        return jsonify(resp), 401

    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Table type fetched successfully",
            "data": {"table_type": table_type}}

    log.info("END")
    return jsonify(resp), 200

@app.route("/idea/services/migrationsf/data/dashboard_tables", methods=["POST"])
@validate_json_schema
def list_dashboard_table():
    """
        This API get the list of table_type
        :return: json response
        """
    log.info("START")
    try:
        data = request.get_json()
        access_details = validate_access_token(request.headers.get('Authorization'),
                                            permissions=["data_migration"])
        if not access_details:
            resp = error.err_051
            return jsonify(resp), 401
        result = pd.DataFrame(
            db.table_migration_dashboard.find({"database_nm":data["database_nm"],"active": True},
                                    {"_id":0,"batch_id":0,"table_type":0}))
        if result.empty:
            return response(dumps(error.err_088), 404)
        result = result.to_json()
        result = format_json(json.loads(result))

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095),500
    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Get table details executed successfully",
        "data": result}), 200


@app.route("/idea/services/migrationsf/data/col_list", methods=["POST"])
@validate_json_schema
def col_list():
    """
        This API get the list of table_type
        :return: json response
        """
    log.info("START")
    try:
        # Authenticate the user
        access_details = validate_access_token(request.headers.get('Authorization'),
                                               permissions=["data_migration"])
        if not access_details:
            resp = error.err_051
            return jsonify(resp), 401

        data = request.get_json()

        # Validate Project ID
        user_data = get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Validate the link_service_id
        link_service_id = data['link_service_id']
        link_service = db.link_service.find_one(
            {"link_service_id": link_service_id, "active": True})
        if link_service is None:
            return response(dumps(error.err_081), 404)
        elif link_service['link_service_type'].upper() != "TERADATA DWH":
            api_error = error.err_102.copy()
            api_error['message'] = api_error['message'].format(link_service['link_service_type'])
            return response(dumps(api_error), 400)

        # Fetch the  batch_id
        batch_id = get_batch_id(data['link_service_id'], data['project_id'])
        log.info(f'batch_id: {batch_id}')
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        # Fetch the column_list and data_type
        col_data_list = list(db.idea_column_discovery_attr.find(
            {"batch_id": batch_id, "database_nm": data['database_nm'],
             "table_nm": data['table_nm']}, {"_id": 0, "column_nm": 1, "data_type": 1}).sort(
            [("column_nm", 1)]))
        if not col_data_list:
            api_error = error.err_103.copy()
            api_error['message'] = api_error['message'].format(database=data['database_nm'],
                                                               table = data['table_nm'])
            return response(dumps(api_error), 400)

        # Filter the above col_data_list and populate col_list
        col_list = {"No": [], "Range": [], "Duration": []}
        for column in col_data_list:
            if column["data_type"] in column_data_type:
                col_list["Range"].append(column['column_nm'])
                col_list["No"].append(column['column_nm'])
            elif column['data_type'] == "TIMESTAMP" or column["data_type"] == 'DATE':
                col_list['Duration'].append(column['column_nm'])
                col_list['No'].append(column['column_nm'])
        col_list['No'] = sorted(col_list['No'])
        col_list['Range'] = sorted(col_list['Range'])
        col_list['Duration'] = sorted(col_list['Duration'])

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), 500
    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Column_list fetched successfully",
                    "data": col_list}), 200
