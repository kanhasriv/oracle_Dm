"""
This service contains APIs for the data discover
"""

import traceback
import logging
import sys
import json
import uuid
from datetime import datetime
import flask_api
import pandas as pd
from flask import request, jsonify
from kafka import KafkaProducer
from config import config, db, send_message
from libs.util import (format_json, validate_json_schema, abcr_job_registry, abcr_job_run,
                       abcr_job_registry_delete, get_userdata, get_batch_id
                       )
from libs.access_token import validate_access_token
from libs import error
from bson.json_util import dumps
# Import app
from . import routes as app

log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'


@app.route("/idea/services/migrationsf/discover/run", methods=["POST"])
@validate_json_schema
def discover():
    """
    Data Discover for teradata and snowflake
    """
    log.info("START")
    resp_dict = {"status": "Fail", "category": "Snowflake_Migration", "error_code": "",
                 "message": "", "data": ""}
    try:
        access_details = validate_access_token(request.headers.get('Authorization'), permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051),401
        # Get json data
        data = request.get_json()

        socket_flag = 'socket' in data
        pipeline_id = data['socket'] if socket_flag else None
        job_run_id = str(uuid.uuid4())
        creation_time = int(datetime.utcnow().timestamp())
        creation_time_str = datetime.fromtimestamp(creation_time).strftime(idea_date_format)

        # Checking for active job
        job_register_df = db.job_registry.find_one({"job_id": data['job_id'],
                                                    "job_type": "discovery"}, {'_id': 0})
        if not bool(job_register_df):
            return jsonify(error.err_078),404
        active = job_register_df['active']
        job_name = job_register_df["job_name"]
        if not active:
            return jsonify(error.err_078),404

        # Checking for active link service
        link_service_id = job_register_df["link_service_id"]
        query = {"link_service_id": link_service_id, "active": True}
        log.info("db.link_service.find_one():query: {query}".format(query=query))
        resp = db.link_service.find_one(query, {'_id': 0})
        if not bool(resp):
            return jsonify(error.err_081), flask_api.status.HTTP_404_NOT_FOUND
        
        # Checking if the a job is already in progress
        job_in_progress = pd.DataFrame(db.job_run.find({'job_id': data["job_id"],
                                                        'status': 'InProgress'}, {'_id': 0})
                                       .sort([("start_time", -1)]).limit(1))
        if not job_in_progress.empty:
            return jsonify(error.err_0109),409

        job_status = "InProgress"

        # Getting user data
        user_data = get_userdata(access_details, data['project_id'])
        if user_data == False:
            return jsonify(error.err_089), 400
        project_id = data['project_id']
        created_by = user_data["name"]

        # Checking for ABCR flag and passing the required parameter to ABCR
        if config["ABCR"]["flag"] == "Y":
            abcr_status = abcr_job_run("", '', "Other", job_register_df['job_id'],
                                       job_run_id, job_name, "MigrationSF-discovery",
                                       {"job_id": job_register_df['job_id']}, created_by,
                                       creation_time, job_status, config['ABCR']['discover'], "")
            if abcr_status == "Fail":
                end_time = int(datetime.utcnow().timestamp())
                end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
                db.job_run.insert_one(
                    {"job_id": data['job_id'], "job_run_id": job_run_id, "start_time": creation_time
                        , "start_time_str": creation_time_str,
                     "status": job_status, "end_time": end_time, "end_time_str": end_time_str})
                return jsonify(error.err_064),500

        # Storing job run details
        db.job_run.insert_one({"job_id": data['job_id'], "job_run_id": job_run_id,"project_id" : project_id,
                               "start_time": creation_time, "start_time_str": creation_time_str,
                               "status": job_status, "run_by": created_by})
        data["type"] = "DISCOVER"
        data["discover_creation_time"] = creation_time
        data["job_run_id"] = job_run_id
        data["job_name"] = job_name
        data["run_by"] = created_by
        data["user_id"] = user_data["user_id"]
        data["socket_flag"] = socket_flag
        data["pipeline_id"] = pipeline_id
        server = config["kafka"]["host"]

        if socket_flag:
            send_message("sf_discover_run", {"status": "Discovery in progress!", "pipeline_id": pipeline_id}, data["user_id"])

        # Producing message for Kafka consumer
        try:
            producer = KafkaProducer(bootstrap_servers=server,
                                     value_serializer=lambda x: dumps(x).encode('utf-8'))
            topic_discovery = config["kafka"]["topic_discovery_schema"]
            producer.send(topic_discovery, value=data)
        except Exception:
            if socket_flag:
                send_message("sf_discover_run", {"status": "Discovery failed!", "link_service_id": link_service_id, "pipeline_id": pipeline_id}, data["user_id"])
            log.error(traceback.format_exc())
            status = {"message": "Internal server error"}
            job_status = "Fail"
            end_time = int(datetime.utcnow().timestamp())
            end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)

            # Populating details on ABCR
            if config["ABCR"]["flag"] == "Y":
                abcr_status = abcr_job_run("", end_time, status,
                                           job_register_df['job_id'], job_run_id, job_name,
                                           "MigrationSF-discovery", {"message": "Job failed"},
                                           created_by, creation_time, job_status, config['ABCR']['discover'], "")
                if abcr_status == "Fail":
                    db.job_run.update_one({"job_id": data["job_id"], "job_run_id": job_run_id},
                                          {"$set": {"status": job_status,
                                                    "start_time": creation_time,
                                                    "start_time_str": creation_time_str,
                                                    "end_time": end_time,
                                                    "end_time_str": end_time_str}})
                    return jsonify(error.err_064),500

            db.job_run.update_one({"job_id": data["job_id"], "job_run_id": job_run_id},
                                  {"$set": {"status": job_status, "start_time": creation_time,
                                            "start_time_str": creation_time_str,
                                            "end_time": end_time, "end_time_str": end_time_str}})
            return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    except Exception:
        if socket_flag:
            send_message("sf_discover_run", {"status": "Discovery failed!", "link_service_id": link_service_id, "pipeline_id": pipeline_id}, data["user_id"])
        log.error(traceback.format_exc())
        status = {"message": "Internal server error"}
        job_status = "Fail"
        end_time = int(datetime.utcnow().timestamp())
        end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
        user_data = get_userdata(request.headers.get('Authorization'))
        created_by = user_data["name"]

        # Populating details on ABCR
        if config["ABCR"]["flag"] == "Y":
            abcr_status = abcr_job_run("", end_time, status,
                                       job_register_df['job_id'], job_run_id, job_name,
                                       "MigrationSF-discovery",
                                       {"message": "Job failed"}, created_by, creation_time,
                                       job_status, config['ABCR']['discover'], "")
            if abcr_status == "Fail":
                db.job_run.insert_one({"job_id": data['job_id'], "job_run_id": job_run_id,
                                       "start_time": creation_time,
                                       "start_time_str": creation_time_str,
                                       "status": job_status, "end_time": end_time,
                                       "end_time_str": end_time_str})
                return jsonify(error.err_064),500

        db.job_run.insert_one({"job_id": data['job_id'], "job_run_id": job_run_id,
                               "start_time": creation_time, "start_time_str": creation_time_str,
                               "status": job_status, "end_time": end_time,
                               "end_time_str": end_time_str})
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    resp_dict.update(
        {"status": "Success", "message": "Data discovery is in progress",
         "data": {"job_run_id": job_run_id}})
    return jsonify(resp_dict), 200


@app.route("/idea/services/migrationsf/discover/job-register", methods=["POST"])
@validate_json_schema
def create_discover_job_register():
    """
    This API will insert job details in job register table
    """
    log.info("START")
    resp_dict = {"status": "Fail", "category": "Snowflake_Migration", "error_code": "",
                 "message": "", "data": ""}

    try:

        access_details=validate_access_token(request.headers.get('Authorization'), permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051), 401
			
        data = request.get_json()
        
        job_id = str(uuid.uuid4())
        job_name = data['job_name']

        # Checking unique job name
        job_exist = db.job_registry.find_one({'job_name': job_name, 'job_type': 'discovery',
                                              'active': True, "project_id":data['project_id']})
        if bool(job_exist):
            return jsonify(error.err_061), 409
        link_service_id = data['link_service_id']

        created_at = int(datetime.utcnow().timestamp())
        created_at_str = datetime.fromtimestamp(created_at).strftime(idea_date_format)
        link_service_type = db.link_service.find_one({'link_service_id': link_service_id,
                                                      "active": True},
                                                     {'_id': 0, 'link_service_type': 1,
                                                      'link_service_name': 1})
        if not bool(link_service_type):
            return jsonify(error.err_081), flask_api.status.HTTP_404_NOT_FOUND
        link_service_type = link_service_type['link_service_type']

        data["source"] = {
            "type": link_service_type,
            "linkServiceID": data["link_service_id"],
            "bowID": data["link_service_id"]
        }
        del data["link_service_id"]

        # Getting user data
        user_data = get_userdata(access_details, data['project_id'])
        if user_data == False:
            return jsonify(error.err_089), 400
        project_id = data['project_id']
        project_name = user_data['project_name']
        created_by = user_data["name"]

        job_register_df = {'job_type': "discovery",
                           'job_name': job_name,
                           'link_service_id': link_service_id,
                           'link_service_type': link_service_type,
                           'job_id': job_id,
                           'active': True,
                           'created_at': created_at,
                           'created_at_str': created_at_str,
                           'created_by': created_by,
                           'project_id': project_id
                           }

        # Populating details on ABCR
        if config["ABCR"]["flag"] == "Y":
            configuration = {
                "endPoint": {"url": "/idea/services/migrationsf/discover/run", "method": "POST"},
                "params": {"jobId": job_id}
            }
            job_status = abcr_job_registry(job_id, True, "Other", configuration, data,
                                            created_at, config['ABCR']['discover'], job_name,
                                           "MigrationSF-discovery", "", "", "", "", project_id,
                                           created_by, "", "", project_name)
            if job_status == "Fail":
                return jsonify(error.err_063),500
        db.job_registry.insert_one(job_register_df)
    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    resp_dict.update({"status": "Success", "message": "Job registered successfully",
                      "data": {"job_id": job_id}})
    return jsonify(resp_dict), 200


@app.route("/idea/services/migrationsf/discover/job-register", methods=["GET"])
@validate_json_schema
def get_discover_job():
    """
       This API will list down the discover jobs
       :return: json response
    """
    log.info("START")
    resp_dict = {"status": "Fail", "category": "Snowflake_Migration", "error_code": "",
                 "message": "", "data": ""}
    try:

        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051), 401

        data = request.args

        user_data = get_userdata(access_details, data['project_id'])

        if user_data == False:
            return jsonify(error.err_089), 400
        project_id = data['project_id']

        # Fetching active jobs
        query = {'job_type': "discovery", 'active': True,'project_id':project_id}
        if "filter" in data:
            filter_param = {"$regex": "(?i)" + data['filter']}
            query['$or'] = [
                {"job_name": filter_param},
                {"link_service_type": filter_param},
                {"created_by": filter_param}
            ]
        jobs = list(db.job_registry.find(query,
                                               {'_id': 0, 'active': 0, 'created_at_str': 0,
                                                'project_id': 0}).sort([("created_at", -1)]))
        if jobs == []:
            return jsonify(error.err_088), flask_api.status.HTTP_404_NOT_FOUND
        
        for job in range(len(jobs)):
            link_service_name = db.link_service.find_one({"link_service_id": jobs[job]['link_service_id']},
                                                                    {"_id": 0, "link_service_name": 1})
            jobs[job]['link_service_name'] = link_service_name['link_service_name']
            jobs[job]['project_name'] = user_data['project_name']

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    resp_dict.update({"status": "Success", "message": "Job fetched successfully", "data": jobs})
    return jsonify(resp_dict), 200


@app.route("/idea/services/migrationsf/discover/job-register", methods=["DELETE"])
@validate_json_schema
def delete_discover_job():
    """
    This API will delete job record from job register table
    :return: json response
    """
    log.info("START")
    resp_dict = {"status": "Fail", "category": "Snowflake_Migration", "error_code": "",
                 "message": "", "data": ""}
    try:

        access_details=validate_access_token(request.headers.get('Authorization'), permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051), 401
        # Get json data
        data = request.args

        user_data = get_userdata(access_details, data['project_id'])

        if user_data == False:
            return jsonify(error.err_089), 400
        project_id = data['project_id']
        job_id = data["job_id"]

        # Checking for active job
        job_register_df = db.job_registry.find_one(
            {"job_id": data['job_id'], "job_type": "discovery","project_id" : project_id},
            {'_id': 0, 'execution_schedule': 1, 'created_at': 1, 'link_service_type': 1,
             'active': 1, 'job_name': 1})
        if not bool(job_register_df):
            return jsonify(error.err_088), flask_api.status.HTTP_404_NOT_FOUND
        if not job_register_df['active']:
            return jsonify(error.err_085), flask_api.status.HTTP_404_NOT_FOUND

        # Populating details on ABCR to delete the job
        if config["ABCR"]["flag"] == "Y":
            job_status = abcr_job_registry_delete(job_id, False)
            if job_status == "Fail":
                db.job_registry.update_one({"job_id": job_id}, {'$set': {'active': False}})
                return jsonify(error.err_063),500
        db.job_registry.update_one({"job_id": job_id}, {'$set': {'active': False}})

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    resp_dict.update({"status": "Success", "message": "Record deleted successfully",
                      "data": ""})
    return jsonify(resp_dict), 200


@app.route("/idea/services/migrationsf/discover/status", methods=["POST"])
@validate_json_schema
def discovery_status():
    """
    This API will provide the status for discovery
    """
    log.info("START")
    resp_dict = {"status": "Fail", "category": "Snowflake_Migration", "error_code": "",
                 "message": "", "data": ""}
    try:

        access_details=validate_access_token(request.headers.get('Authorization'), permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051), 401

        data = request.get_json()

        user_data = get_userdata(access_details, data['project_id'])

        if user_data == False:
            return jsonify(error.err_089), 400
        project_id = data['project_id']
        job_run_id = data['job_run_id']

        # Checking for job run details
        query = {"job_run_id": job_run_id,"project_id" : project_id}
        resp = db.job_run.find_one(query, {"_id": 0,"project_id" : 0})
        if resp is None:
            resp_dict.update(
                {"error_code": "IDEA_ERR_088", "message": "Record not found or deleted"})
            return jsonify(resp_dict),404
        job_type = db.job_registry.find_one({"job_id": resp["job_id"], "active": True,
                                             "job_type": "discovery"},
                                            {"_id": 0, "created_at_str": 0, "project_id": 0})
        if job_type is None:
            return jsonify(error.err_078), flask_api.status.HTTP_404_NOT_FOUND
        log.info(resp)
    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR
    log.info("END")
    resp_dict.update({"status": "Success", "message": "Status fetched successfully", "data": resp})
    return jsonify(resp_dict), 200


@app.route("/idea/services/migrationsf/discover/list-job-run-id", methods=["POST"])
def get_job_run_id():
    """
    This API will fetch job run id details
    """
    log.info("START")
    resp_dict = {"status": "Fail", "category": "Snowflake_Migration", "error_code": "",
                 "message": "", "data": ""}
    try:

        access_details=validate_access_token(request.headers.get('Authorization'), permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051), 401
        data = request.get_json()

        user_data = get_userdata(access_details, data['project_id'])

        if user_data == False:
            return jsonify(error.err_098), 400
        project_id = data['project_id']
        job_id = data["job_id"]

        # Checking for active jobs
        job_register_df = db.job_registry.find_one({"job_id": job_id,"project_id" : project_id}, {'_id': 0})
        if not bool(job_register_df):
            return jsonify(error.err_078),404
        active = job_register_df['active']
        if not active:
            return jsonify(error.err_078),404
        # Fetching the job run details
        list_job_run_ids = list(db.job_run.find({'job_id': job_id,"project_id" : project_id},
                                                {"_id": 0, "job_run_id": 1, "start_time": 1,
                                                 "end_time": 1,
                                                 "status": 1, "link_service_id": 1,
                                                 "link_service_type": 1,
                                                 "run_by": 1, "re_run_flag": 1, "run_type": 1,
                                                 "parent_run_id": 1}).sort([("start_time", -1)]))
        if len(list_job_run_ids) == 0:
            return jsonify(error.err_088), flask_api.status.HTTP_404_NOT_FOUND

        resp = {"data": []}
        for item in list_job_run_ids:
            resp["data"].append(item)

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    resp_dict.update({"status": "Success", "message": "Job run ids fetched successfully"})
    resp_dict.update(resp)
    return jsonify(resp_dict), 200


@app.route("/idea/services/migrationsf/discover/latest", methods=["POST"])
@validate_json_schema
def get_latest_discovery():
    """
    This API will fetch latest discovery details
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'), permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051), 401

        data = request.get_json()

        # Project validation
        user_data = get_userdata(access_details, data['project_id'])
        if user_data == False:
            return jsonify(error.err_089), 400

        # Fetch latest discovery
        batch_id = get_batch_id(data['link_service_id'], data['project_id'])
        if batch_id:
            end_time = db.job_run.find_one({"batch_id":batch_id},{"_id":0, "end_time": 1})['end_time']
        else:
            return jsonify(error.err_060), 404

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    return jsonify({
        "status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Latest discovery fetched successfully",
        "data": end_time
    }), 200


@app.route("/idea/services/migrationsf/link-service-stats", methods=["GET"])
def link_service_stats():
    """
    This API will fetch link service stats
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'), permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051), 401

        result = {
            "total": db.link_service.count_documents({"active": True}),
            "source": db.link_service.count_documents({"active": True, "link_service_type": {"$in": ["teradata DWH", "teradata FTP"]}}),
            "sink": db.link_service.count_documents({"active": True, "link_service_type": {"$in": ["snowflake DWH", "S3"]}}),
            "active": db.link_service.count_documents({"active": True})
        }

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    return jsonify({
        "status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Link service stats fetched successfully",
        "data": result
    }), 200


@app.route("/idea/services/migrationsf/job-stats", methods=["GET"])
@validate_json_schema
def job_stats():
    """
    This API will fetch job details for a job type
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'), permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051), 401

        data = request.args
        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, project_id)
        if user_data == False:
            return jsonify(error.err_089), 400

        job_type = data['job_type']

        result = {
            "job": 0,
            "run": 0,
            "success": 0,
            "fail": 0
        }

        active_jobs = list(db.job_registry.find({"job_type": job_type, "project_id": project_id, "active": True}, {"_id": 0, "job_id": 1}))
        if bool(active_jobs):
            active_jobs = [job['job_id'] for job in active_jobs]
            result['job'] = len(active_jobs)
            result['run'] = db.job_run.count_documents({"job_id": {"$in": active_jobs}})
            success = db.job_run.count_documents({"job_id": {"$in": active_jobs}, "status": "Success"})
            fail = db.job_run.count_documents({"job_id": {"$in": active_jobs}, "status": "Fail"})
            if result['run']:
                result['success'] = round((success/result['run'])*100, 2)
                result['fail'] = round((fail/result['run'])*100, 2)

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    return jsonify({
        "status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Job stats fetched successfully",
        "data": result
    }), 200


@app.route("/idea/services/migrationsf/job-run-stats", methods=["GET"])
@validate_json_schema
def job_run_stats():
    """
    This API will fetch job run details for a job type
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'), permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051), 401

        data = request.args
        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, project_id)
        if user_data == False:
            return jsonify(error.err_089), 400

        job_id = data['job_id']

        result = {
            "run": 0,
            "success": 0,
            "fail": 0,
            "progress": 0
        }

        if bool(db.job_registry.find_one({"job_id": job_id, "project_id": project_id, "active": True})):
            result['run'] = db.job_run.count_documents({"job_id": job_id})
            result['success'] = db.job_run.count_documents({"job_id": job_id, "status": "Success"})
            result['fail'] = db.job_run.count_documents({"job_id": job_id, "status": "Fail"})
            result['progress'] = db.job_run.count_documents({"job_id": job_id, "status": "InProgress"})

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    return jsonify({
        "status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Job run stats fetched successfully",
        "data": result
    }), 200


@app.route("/idea/services/migrationsf/object-stats", methods=["GET"])
@validate_json_schema
def object_stats():
    """
    This service will get the object stats
    :return: json data
    """
    log.info("START")
    
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'), permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051), 401
        
        # Get json data
        data = request.args

        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, project_id)
        if user_data == False:
            return jsonify(error.err_089), 400

        link_service_id = data['link_service_id']

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(link_service_id, project_id, data["job_run_id"])
        else:
            batch_id = get_batch_id(link_service_id, project_id)

        if not bool(batch_id):
            return jsonify(error.err_060), 404

        # Objects details
        objects = db.idea_object_details_discovery_attr.find({"batch_id": batch_id}, {"_id": 0, "object_kind": 1, "object_count": 1})
        objects = pd.DataFrame(objects)
        if objects.empty:
            log.info({"message": "Record not found or deleted"})
            return jsonify(error.err_088), 404
        objects[['object_count']] = objects[['object_count']].fillna(value=0)
        objects['object_count'] = objects['object_count'].apply(float).apply(int)
        object_result = objects.to_json()
        object_result = format_json(json.loads(object_result))

    except Exception as e_error:
        log.error(e_error)
        return jsonify(error.err_095), 500

    log.info("END")
    return jsonify({
        "status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Object stats fetched successfully",
        "data": object_result
    }), 200


@app.route("/idea/services/migrationsf/search", methods=["GET"])
def search():
    """
    This API will fetch job details for a search
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'), permissions=["discovery"])
        if not access_details:
            return jsonify(error.err_051), 401

        data = request.args
        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, project_id)
        if user_data == False:
            return jsonify(error.err_089), 400

        job_type = data['job_type']
        job_name = "(?i)" + data['job_name']

        result = list(db.job_registry.find({"job_name": {"$regex": job_name}, "job_type": job_type, "project_id": project_id, "active": True}, {"_id": 0}).sort([("created_at", -1)]))
        if not bool(result):
            return jsonify(error.err_088), 404
        
        for job in range(len(result)):
            link_service_name = db.link_service.find_one({"link_service_id": result[job]['link_service_id']},
                                                                    {"_id": 0, "link_service_name": 1})
            result[job]['link_service_name'] = link_service_name['link_service_name']
            result[job]['project_name'] = user_data['project_name']
            if job_type in ["schema_migration", "data_migration"]:
                sink_link_service_name = db.link_service.find_one({"link_service_id": result[job]['sink_link_service_id']},
                                                                        {"_id": 0, "link_service_name": 1})
                result[job]['sink_link_service_name'] = sink_link_service_name['link_service_name']
        if job_type == "schema_migration":
            for item in result:
                if 'data' in item and item["data"] is not None:
                    item["data"] = str(item["data"])
                    item["data"] = json.loads(
                        item["data"].replace('True', 'true').replace('False', 'false').replace('\'',
                                                                                            '"'))

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    return jsonify({
        "status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Search results fetched successfully",
        "data": result
    }), 200