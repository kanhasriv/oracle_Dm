"""
This file contains utility functions
"""
import logging
from flask import request, Response
from datetime import datetime
from dateutil import parser
import requests
import traceback
import jwt
import botocore
import ftplib
import pyodbc
import json
from kafka import KafkaProducer
from bson.json_util import dumps
from libs import error
from libs.data_schema import schema
from jsonschema import validate
from config import (config, glue_client,iam_client, client, s3_client)
from config import config, db
from functools import wraps
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y/%m/%d %H:%M:%S'
abcr_error = "Error while producing "
status_message = "status: {}, message: {}"

def format_json(json):
    """
    format json
    """
    
    data = []
    max_len = -999
    for item in json.keys():
        if max_len < len(json[item]):
            max_len = len(json[item])

    for index in range(0, max_len):
        temp_data = {}
        for item in json.keys():
            try:
                temp_data[item] = json[item][str(index)]
            except Exception as e_error:
                log.error(e_error)
                return False
        data.append(temp_data)

    return data


def get_batch_id(link_service_id, project_id, job_run_id=''):
    """
    returns batch_id
    """

    if job_run_id == '':
        batch = list(db.job_run.find({"link_service_id": link_service_id, "project_id": project_id, 
                "status": "Success"},{'_id': 0, 'batch_id': 1}).sort([("start_time", -1)]).limit(1))
        batch = list(filter(None, batch))
        if batch != []:
            batch = batch[0]
    else:
        batch = db.job_run.find_one({"job_run_id": job_run_id, "project_id": project_id,
                "link_service_id": link_service_id}, {'_id': 0, 'batch_id': 1})
    
    if bool(batch):
            return batch['batch_id']
    else:
        return None


def validate_json_schema(f):
    """
    Validate the schema and the datatype of the
    request json payload
    :param name:
    :return: boolean
    """

    # log.info("START name: {}" . format(f.__name__))

    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Validate schema
        try:
            # Get the data from the request params
            if request.method in ["GET", "DELETE"]:
                data = request.args
            else:
                data = request.get_json()
            log.info("Request data: {}".format(data))

            # Load schema based on the function name
            _schema = schema[f.__name__]

            # Validate Json schema
            validate(instance=data, schema=_schema)

        except Exception as e:
            log.error("JSON Schema Validation FAILED for {}".format(_schema))
            return response(dumps(error.err_074), 400)

        log.info("END JSON Schema Validation SUCCESS")
        return f(*args, **kwargs)

    return decorated_function


def date_to_timestamp(date):
    """
    Convert UTC Date to Timestamp
    :param data:
    "return date in secs:
    """
    return int(parser.parse(str(date)).strftime('%s'))


def response(data, status, mimetype="application/json"):
    """
    Return the reponse with mimetype application/json
    """
    log.info("body: {}, status: {}".format(data, status))
    return Response(data, status=status, mimetype=mimetype)


def requests_retry_session(
        retries=3,
        backoff_factor=0.3,
        status_forcelist=(500, 502, 504),
        session=None,
):
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('https://', adapter)
    return session


def abcr_job_registry(jobregister_id, active, hydrationtype, configuration, parameters,
                      creationdate,job_type, job_name, job_description, version, workflow, batch_id, sequence_number,
                      project_id, created_by, modified_by, modification_date,project_name
                      ):
    """
    populate ABCR if enabled
    """
    
    status = "Fail"
    try:
        job_register_topic = config["kafka"]["topic_job_register"]
        abcr_json = {'jobRegisterID': jobregister_id,
                     'active': active,
                     'category': config['ABCR']['category'],
                     'config': configuration,
                     'creationDate': datetime.fromtimestamp(creationdate).strftime(idea_date_format),
                     'creationDateTimestamp': creationdate,
                     'createdBy': created_by,
                     'modificationDate': modification_date,
                     'modifiedBy': modified_by,
                     'projectID': project_id,
                     'projectName': project_name,
                     'hydrationType': hydrationtype,
                     'jobDescription': job_description,
                     'jobName': job_name,
                     'parameters': parameters,
                     'type': job_type,
                     'sbowID' : "",
                     "uowID": jobregister_id
                     }
        
        # produce message in kafka topic
        producer = KafkaProducer(bootstrap_servers=[config["kafka"]["host"]],
                                 value_serializer=lambda x: dumps(x).encode('utf-8'))
        producer.send(job_register_topic, value=abcr_json)
        status = "Success"
        message = jobregister_id + " Produced Successfully on job register topic"
    except Exception:
        log.error(traceback.format_exc())
        message = abcr_error + jobregister_id + " on job register topic"
        log.info(status_message.format(status, message))
        return status
    log.info(status_message.format(status, message))
    return status


def abcr_job_run(configuration, end, execution_log, job_register_id, job_run_id, job_name, job_description, output,
                 run_by, start,
                 job_status, job_type, batch_run_id):
    """
    populate ABCR if enabled
    """
    
    status = "Fail"
    try:
        job_run_topic = config["kafka"]["topic_job_run"]
        abcr_json = {
            'runBy': run_by,
            'status': job_status,
            'type': job_type,
            'category': config['ABCR']['category'],
            'config': configuration,
            'executionLog': execution_log,
            'jobRegisterID': job_register_id,
            'jobRunID': job_run_id,
            'jobName': job_name,
            'jobDescription': job_description,
            'start': datetime.fromtimestamp(start).strftime(idea_date_format),
            'startTimestamp': start,
            'parameters': ""

        }
        if job_status == "Success" or job_status == "Fail":
            if end != "":
                abcr_json['end'] = datetime.fromtimestamp(end).strftime(idea_date_format)
            abcr_json['endTimestamp'] = end
            abcr_json['output'] = output
        if job_type == "discover":
            abcr_json['batchRunId'] = batch_run_id

        # produce message in kafka topic
        producer = KafkaProducer(bootstrap_servers=[config["kafka"]["host"]],
                                 value_serializer=lambda x: dumps(x).encode('utf-8'))
        producer.send(job_run_topic, value=abcr_json)
        status = "Success"
        message = job_run_id + " Produced Successfully on job run topic"
    except Exception:
        log.error(traceback.format_exc())
        message = abcr_error + job_run_id + " on job run topic"
        log.info(status_message.format(status, message))
        return status
    log.info(status_message.format(status, message))
    return status


def abcr_job_registry_delete(jobregister_id, active):
    """
    populate ABCR if enabled
    """

    status = "Fail"
    try:
        job_register_topic = config["kafka"]["topic_job_register"]
        abcr_json = {'jobRegisterID': jobregister_id,
                     'active': active
                     }
        producer = KafkaProducer(bootstrap_servers=[config["kafka"]["host"]],
                                 value_serializer=lambda x: dumps(x).encode('utf-8'))
        
        # produce message in kafka topic
        producer.send(job_register_topic, value=abcr_json)
        status = "Success"
        message = jobregister_id + " Produced Successfully on job register topic"
    except Exception:
        message = abcr_error + jobregister_id + " on job register topic"
        log.info(status_message.format(status, message))
        return status
    log.info(status_message.format(status, message))
    return status


def get_userdata(data, project_id=''):
    """
    Fetch the user data from access token
    """
    log.info("START accessing user data : {}".format(data))

    # Check the none type before log as the none variable can not be appended as a string to log
    # If appended it throws NoneType exception


    # Checking if given project_id is assigned to the user
    project_name = ""
    if project_id !='':
        for project_info in data[0]["projects"]:
            if project_info["project_id"] == project_id:
                project_name = project_info["project_name"]

        # Given project_id has no corresponding project for this user
        if project_name == "":
            log.error("Project details not found for the user!")
            return False
    data = {
        "user_id": data[0]["user_id"],
        "name": data[0]["name"],
        "email": data[0]["email"],
        "user_type": data[0]["user_type"]
    }
    if project_id != '':
        data.update({"project_name": project_name})
    log.info("END")
    return data

def update_role_policy(integration_data):
    try:
        attach_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {
                    "Service": "glue.amazonaws.com"
                },
                "Action": "sts:AssumeRole"
            },
            {
                "Effect": "Allow",
                "Principal": {
                    "AWS": integration_data["aws_consent"]["STORAGE_AWS_ROLE_ARN"]
                },
                "Action": "sts:AssumeRole",
                "Condition": {
                    "StringEquals": {
                        "sts:ExternalId": integration_data["aws_consent"]["STORAGE_AWS_EXTERNAL_ID"]
                        }
                    }
                }
            ]
        }
        policy_attach_res = iam_client.update_assume_role_policy(RoleName=config['aws']['role_name'],
                                                            PolicyDocument=json.dumps(attach_policy))
    except Exception as e_error:
        log.info("Issue while updadating the role policy")
        log.error(traceback.format_exc())
        return False
    return True


def link_service_status(link_services, index):
    link_service = link_services[index]
    status = "Fail"
    try:
        if link_service['link_service_type'] == 'teradata DWH':
            conn = pyodbc.connect(config['teradata']["conn"].format(hostname=link_service['db_hostname'], uid=link_service['db_user'], pwd=client.get_secret_value(SecretId=link_service["link_service_id"]+'-password')["SecretString"]))
            conn.close()
            status = "Success"
        elif link_service['link_service_type'] == 'S3':
            s3_client.list_objects_v2(Bucket=link_service['s3_bucket_name'])
            status = "Success"
        elif link_service['link_service_type'] == 'teradata FTP':
            ftp = ftplib.FTP()
            ftp.connect(link_service['db_hostname'], link_service['port'])
            ftp.login(link_service['db_user'], client.get_secret_value(SecretId=link_service["link_service_id"]+'-password')["SecretString"])
            status = "Success"
        else:
            conn = pyodbc.connect(config['snowflake']["conn"].format(hostname=link_service['db_hostname'], uid=link_service['db_user'], pwd=client.get_secret_value(SecretId=link_service["link_service_id"]+'-password')["SecretString"], warehouse='COMPUTE_WH'))
            conn.close()
            status = "Success"
    except:
        log.error(traceback.format_exc())
        status = "Fail"
    link_services[index] = {
        "link_service_id": link_service['link_service_id'],
        "status": status
    }