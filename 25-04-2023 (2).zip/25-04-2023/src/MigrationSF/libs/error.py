# error codes
err_051 = {
    "status": "Fail",
    "message": "Authorization failed",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_051",
    "data": ""
}

err_054 = {
    "status": "Fail",
    "message": "Consumer {full_account} cannot be assigned",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_054",
    "data": ""
}

err_095 = {
    "status": "Fail",
    "message": "Internal server error",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_095",
    "data": ""
}

err_074 = {
    "status": "Fail",
    "message": "Invalid payload",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_074",
    "data": ""
}

err_052 = {
    "status": "Fail",
    "message": "Can not connect to FTP server",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_052",
    "data": ""
}

err_053 = {
    "status": "Fail",
    "message": "Can not find the path in FTP server",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_053",
    "data": ""
}

err_055 = {
    "status": "Fail",
    "message": "Snowflake object creation failed",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_055",
    "data": ""
}

err_056 = {
    "status": "Fail",
    "message": "Db_hostname and shared path already exists",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_056",
    "data": ""
}

err_057 = {
    "status": "Fail",
    "message": "Invalid entry for snowflake subscription type",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_057",
    "data": ""
}

err_058 = {
    "status": "Fail",
    "message": "DB_hostname already exists",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_058",
    "data": ""
}

err_060 = {
    "status": "Fail",
    "message": "Discovery details not found",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_060",
    "data": ""
}

err_061 = {
    "status": "Fail",
    "message": "Duplicate entry for job_name",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_061",
    "data": ""
}

err_062 = {
    "status": "Fail",
    "message": "Invalid entry for link service",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_062",
    "data": ""
}

err_063 = {
    "status": "Fail",
    "message": "Error while producing message on job register topic",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_063",
    "data": ""
}

err_064 = {
    "status": "Fail",
    "message": "Error while producing message on job run topic",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_064",
    "data": ""
}

err_065 = {
    "status": "Fail",
    "message": "User does not have access",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_065",
    "data": ""
}

err_068 = {
    "status": "Fail",
    "message": "Failed to update data_migration-wh",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_068",
    "data": ""
}

err_069 = {
    "status": "Fail",
    "message": "Duplicate link service name",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_069",
    "data": ""
}

err_070 = {
    "status": "Fail",
    "message": "Failed to update FTP path details",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_070",
    "data": ""
}

err_071 = {
    "status": "Fail",
    "message": "Invalid Rule",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_071",
    "data": ""
}

err_072 = {
    "status": "Fail",
    "message": "Failed to update discovery-wh",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_072",
    "data": ""
}

err_073 = {
    "status": "Fail",
    "message": "Failed to update schema_migration-wh",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_073"
}

err_075 = {
    "status": "Fail",
    "message": "Share {share} already exists",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_075",
    "data": ""
}

err_076 = {
    "status": "Fail",
    "message": "Invalid Link Service",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_076",
    "data": ""
}

err_077 = {
    "status": "Fail",
    "message": "Job already exists",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_077",
    "data": ""
}

err_078 = {
    "status": "Fail",
    "message": "Job id not found or deleted",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_078",
    "data": ""
}

err_079 = {
    "status": "Fail",
    "message": "Error while producing message on sf-dm-source-blob topic",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_079",
    "data": ""
}

err_080 = {
    "status": "Fail",
    "message": "Job has been successful or already been rerun",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_080",
    "data": ""
}

err_081 = {
    "status": "Fail",
    "message": "Link service id is not found or deleted",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_081",
    "data": ""
}

err_082 = {
    "status": "Fail",
    "message": "Reader {reader} already exists",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_082",
    "data": ""
}

err_083 = {
    "status": "Fail",
    "message": "Permission has not been given for created IntegrationID",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_083",
    "data": ""
}
err_084 = {
    "status": "Fail",
    "message": "Please provide Schema Name",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_084",
    "data": ""
}
err_085 = {
    "status": "Fail",
    "message": "Record already deleted",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_085",
    "data": ""
}
err_086 = {
    "status": "Fail",
    "message": "Not a snowflake link service",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_086",
    "data": ""
}

err_087 = {
    "status": "Fail",
    "message": "Record not deleted",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_087",
    "data": ""
}

err_088 = {
    "status": "Fail",
    "message": "Record not found or deleted",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_088",
    "data": ""
}

err_089 = {
    "status": "Fail",
    "message": "Invalid project ID",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_089",
    "data": ""
}

err_091 = {
    "status": "Fail",
    "message": "Given table {table_nm} does not exist for load_type {load}",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_091",
    "data": ""
}

err_092 = {
    "status": "Fail",
    "message": "FTP does not support ADHOC",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_092",
    "data": ""
}

err_094 = {
    "status": "Fail",
    "message": "Sink_link_service not found or deleted",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_094",
    "data": ""
}

err_096 = {
    "status": "Fail",
    "message": "Source_link_service not found or deleted",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_096",
    "data": ""
}

err_098 = {
    "status": "Fail",
    "message": "Test Connection Failed",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_098",
    "data": ""
}

err_0100 = {
    "status": "Fail",
    "message": "Unsupported link_service_type",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_100",
    "data": ""
}

err_0104 = {
    "status": "Fail",
    "message": "Can not update these fields for this link service",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_104",
    "data": ""
}

err_0105 = {
    "status": "Fail",
    "message": "Failed to update FTP details",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_105",
    "data": ""
}

err_0106 = {
    "status": "Fail",
    "message": "Provided path does not exist",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_106",
    "data": ""
}

err_0109 = {
    "status": "Fail",
    "message": "Job is already in progress",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_109",
    "data": ""
}

err_059 = {
    "status": "Fail",
    "message": "AWS s3 bucket  already exist",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_059",
    "data": ""
}

err_110 = {
    "status": "Fail",
    "message": "Cannot connect to Teradata",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_110",
    "data": ""
}

err_066 = {
    "status": "Fail",
    "message": "Column {column} details are not present",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_066",
    "data": ""
}

err_067 = {
    "status": "Fail",
    "message": "Failed to update dashboard collection",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_067",
    "data": ""
}

err_090 = {
    "status": "Fail",
    "message": "Unsupported split_type {split_type} for column {column}",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_090",
    "data": ""
}

err_093 = {
    "status": "Fail",
    "message": "Failed to update the role policy",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_093",
    "data": ""
}

err_097 = {
    "status": "Fail",
    "message": "Pipeline already exists",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_097",
    "data": ""
}

err_099 = {
    "status": "Fail",
    "message": "Pipeline not found or deleted",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_099",
    "data": ""
}

err_107 = {
    "status": "Fail",
    "message": "Pipeline is already in progress",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_107",
    "data": ""
}

err_108 = {
    "status": "Fail",
    "message": "Pipeline cannot be deleted while in progress",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_108",
    "data": ""
}

err_101 = {
    "status": "Fail",
    "message": "Can not register a link service for this user",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_101",
    "data": ""
}

err_102 = {
    "status": "Fail",
    "message": "API not supported for {}",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_102",
    "data": ""
}

err_103 = {
    "status": "Fail",
    "message": "The table {database}.{table} is not present in the discovery.",
    "category": "Snowflake_Migration",
    "error_code": "IDEA_ERR_103",
    "data": ""
}