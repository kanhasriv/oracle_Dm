data_migration = {
    "max_query": "SELECT max({column_name}) as max_value from {schema_name}.{table_name}",
    "min_query": "SELECT min({column_name}) as min_value from {schema_name}.{table_name}"
}