"""
This service populates discovery tables
"""
import logging
from kafka import KafkaProducer
from bson.json_util import dumps
from config import config
import traceback
from datetime import datetime

log = logging.getLogger(config["logging"]["name"])

def abcr_job_run(configuration, end, execution_log, job_register_id, job_run_id, job_name, job_description, output,
                 run_by, start,
                 job_status, job_type, batch_run_id):
    """
    populate ABCR if enabled
    """
    status = "Fail"
    try:
        job_run_topic = config["kafka"]["topic_job_run"]
        abcr_json = {
            'runBy': run_by,
            'status': job_status,
            'type': job_type,
            'category': config['ABCR']['category'],
            'config': configuration,
            'executionLog': execution_log,
            'jobRegisterID': job_register_id,
            'jobRunID': job_run_id,
            'jobName': job_name,
            'jobDescription': job_description,
            'start': datetime.fromtimestamp(start).strftime('%Y/%m/%d %H:%M:%S'),
            'startTimestamp': start

        }
        if job_status == "Success" or job_status == "Fail":
            if end != "":
                abcr_json['end'] = datetime.fromtimestamp(end).strftime('%Y/%m/%d %H:%M:%S')
            abcr_json['endTimestamp'] = end
            abcr_json['output'] = output
        if job_type == "discover":
            abcr_json['batchRunId'] = batch_run_id

        # produce message in kafka topic
        producer = KafkaProducer(bootstrap_servers=[config["kafka"]["host"]],
                                 value_serializer=lambda x: dumps(x).encode('utf-8'))
        producer.send(job_run_topic, value=abcr_json)
        status = "Success"
        message = job_run_id + " Produced Successfully on job run topic"
    except Exception:
        log.error(traceback.format_exc())
        message = "Error while producing " + job_run_id + " on job run topic"
        log.info("status: {}, message: {}".format(status, message))
        return status
    log.info("status: {}, message: {}".format(status, message))
    return status