import os
import configparser
import pymongo
import boto3
from client import send_message

config = configparser.ConfigParser()
if "FLASK_ENV" in os.environ and os.environ["FLASK_ENV"] == "development":
    config.read("dev-config.ini")
    mongo_client = pymongo.MongoClient(config["mongodb"]["host"])
else:
    config.read("config.ini")

session = boto3.session.Session()

# Creating AWS Secret Manager Client
client = session.client(
    service_name='secretsmanager',
    region_name=config['aws']['region_name'],
    aws_access_key_id="AKIAWSJ3O4ZMD22ZOZLW",
    aws_secret_access_key="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")

# Creating AWS Glue Client
glue_client = session.client(
    service_name='glue',
    region_name=config['aws']['region_name'],
    aws_access_key_id="AKIAWSJ3O4ZMD22ZOZLW",
    aws_secret_access_key="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")

if "FLASK_ENV" in os.environ and os.environ["FLASK_ENV"] == "development":
    config.read("dev-config.ini")
    # localhost
else:
    config.read("config.ini")


    config.update({
        "documentdb": {
            "hostname": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_hostname"])["SecretString"],
            "username": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_user"])["SecretString"],
            "password": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_password"])["SecretString"]
                    },
        "kafka": {
            "host":"20.172.185.47:9092",
            "topic_sr_s3": config['kafkatopics']['topic_sr_s3'],
            "topic_s3_sf": config['kafkatopics']['topic_s3_sf'],
        }
    })

# Connecting to DocumentDB Server
db_client = pymongo.MongoClient("mongodb://ideatfdocdb:ideatfdocdb%21%23@localhost:27017/?authSource=admin&readPreference=primary&directConnection=true&ssl=true&tlsAllowInvalidCertificates=true&tlsAllowInvalidHostnames=true&retryWrites=false")
db = db_client[config["database"]["dbname"]]

def update_dashboard(job_run_id, table, database):
    rows = 0
    s3_duration = 0
    sf_duration = 0
    run_data = db.job_run_detail.find_one({"job_run_id": job_run_id, "object_name": table, "object_parent": database})
    for split in run_data['splits']:
        if split['split_status_sf'] in ["Success", "Fail"]:
            rows += split.get('noofrows_written_sf', 0) or 0
            s3_duration = max(s3_duration, split.get('copy_s3', 0) or 0)
            sf_duration = max(sf_duration, split.get('copy_sf', 0) or 0)
    return rows, s3_duration, sf_duration