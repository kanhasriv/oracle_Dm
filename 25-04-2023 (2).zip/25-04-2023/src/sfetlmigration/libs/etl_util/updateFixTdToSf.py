import re

test_string = """

update wrk
from ${WORK_DB}.s_DNTM_TBL_VST_HIST_VSTQT     wrk,
    (select SITEUID,TableVisitTableID,VISITUID,
           etl_row_id,
           rank() over (partition by SITEUID,TableVisitTableID,VISITUID,
                                     vrsn_strt_dts,
                                     etl_chksum_am
                        order by etl_row_id desc from sometable) AS rk
    from ${WORK_DB}.s_DNTM_TBL_VST_HIST_VSTQT) dups
set instnc_st_nm = 'dup1'
where wrk.etl_row_id = dups.etl_row_id
AND wrk.SITEUID = dups.SITEUID
AND wrk.TableVisitTableID = dups.TableVisitTableID
AND wrk.VISITUID = dups.VISITUID
  and dups.rk        > 1;
;"""

text2 = """update wrk
from  ${WORK_DB}.D_DNG_SRVC_PRD       wrk,
      ${TARGET_DB}.D_DNG_SRVC_PRD   tgt
set instnc_st_nm = 'UPDATE_' || wrk.instnc_st_nm
WHERE wrk.instnc_st_nm  in ('Standard')
  AND wrk.etl_chksum_am <> tgt.etl_chksum_am AND     tgt.dng_srvc_prd_nm=wrk.dng_srvc_prd_nm
AND tgt.dng_srvc_prd_strt_dt=wrk.dng_srvc_prd_strt_dt
AND tgt.fac_id=wrk.fac_id
;"""
 
text1 = """update tgt
from  ${WORK_DB}.D_DNG_SRVC_PRD       wrk,
      ${TARGET_DB}.D_DNG_SRVC_PRD   tgt
set instnc_st_nm = 'Standard',
  dng_srvc_prd_strt_dt      = wrk.dng_srvc_prd_strt_dt,
  dng_srvc_prd_end_dt  = wrk.dng_srvc_prd_end_dt,
  dng_srvc_prd_strt_tm           = wrk.dng_srvc_prd_strt_tm,
dng_srvc_prd_end_tm           = wrk.dng_srvc_prd_end_tm,
sts_nm           = wrk.sts_nm,
dng_srvc_prd_id           = wrk.dng_srvc_prd_id,
etl_chksum_am           = wrk.etl_chksum_am,
etl_proc_nm           = wrk.etl_proc_nm,
etl_proc_run_id           = wrk.etl_proc_run_id,
etl_src_rec_set_id           = wrk.etl_src_rec_set_id,
etl_targ_rec_set_id           = wrk.etl_targ_rec_set_id,
insert_dts           = wrk.insert_dts,
src_sys_nm           = wrk.src_sys_nm
where wrk.instnc_st_nm like 'UPDATE%'
AND tgt.dng_srvc_prd_nm=wrk.dng_srvc_prd_nm
AND tgt.fac_id=wrk.fac_id
AND tgt.dng_srvc_prd_strt_dt=wrk.dng_srvc_prd_strt_dt
;"""

dict_re = {
    "UPDATE_1": re.compile(
        r"(?i)update\s+(?P<update_table>[\S]+)\s+from\b(?P<tables>[\s\S]*)(?:\bset\b)((("
        r"?P<set_till_where>[\s\S]*?)(?:\bwhere\b)(?P<where>[^;]*;))|(?P<set_without_where>["
        r"^;]*;))"),
}

placeholder_cnt = 1
placeholder = "+++PLACEHOLDER{}+++"
placeholderDict = {}


def encode(string):
    global placeholder_cnt, placeholder, placeholderDict
    match = re.search(r"\(([^\)\(]*)\)", string)
    while match is not None:
        start = match.start()
        end = match.end()
        val = string[start:end]
        string = string[:start] + placeholder.format(str(placeholder_cnt)) + string[end:]
        placeholderDict[placeholder.format(str(placeholder_cnt))] = val
        placeholder_cnt += 1
        match = re.search(r"\(([^\)\(]*)\)", string)
    return string


def decode(txt):
    match = re.search(r"(?i)\+\+\+PLACEHOLDER(\d)+\+\+\+", txt)
    while match is not None:
        start = match.start()
        end = match.end()
        val = txt[start:end]
        txt = txt[:start] + placeholderDict[val] + txt[end:]
        match = re.search(r"(?i)\+\+\+PLACEHOLDER(\d)+\+\+\+", txt)
    return txt


def beautify(ip):
    if type(ip) == "list":
        return "\n".join([re.sub(r"[\s]+", " ", line.strip()) for line in ip if line.strip()])
    return "\n".join(
        [re.sub(r"[\s]+", " ", line.strip()) for line in ip.split("\n") if line.strip()])


def scrub_sql(sql):
    # assumption : no commented words that mess with the regex
    sql = sql.strip()
    if not sql.endswith(";"):
        sql += ";"
    return sql


def find_actual_table_name(tgt_tbl, tables):
    tgt_tbl = tgt_tbl.strip()
    list_tables = tables.split(",")
    updated_list_tables = []
    found = False
    for table in list_tables:
        table = table.strip()
        table_and_alias = [token.strip() for token in table.split(" ") if
                           len(token.strip()) > 0 and (token.strip().lower() != "as")]
        if len(table_and_alias) <= 2:
            if not found:
                for index, token in enumerate(table_and_alias):
                    if token == tgt_tbl:
                        if index > 0:
                            tgt_tbl = table_and_alias[0] + " " + tgt_tbl
                        found = True
                        break
                if not found:
                    updated_list_tables.append(table)
            else:
                updated_list_tables.append(table)
    return tgt_tbl, ",".join(updated_list_tables)


def final_upd(sql):
    sql = scrub_sql(sql)
    sql = encode(sql)
    re_match = dict_re["UPDATE_1"].match(sql)
    if re_match:
        target_table_or_alias = re_match.group("update_table")
        tables_used = re_match.group("tables")
        target_table_or_alias, tables_used = find_actual_table_name(target_table_or_alias, tables_used)

        where_clause = re_match.group("where")
        if not where_clause:
            set_clause = re_match.group("set_without_where").strip(";")
            res = f"UPDATE {target_table_or_alias}\nSET {set_clause}\nFROM {tables_used};"
            return beautify(decode(res))
        else:
            set_clause = re_match.group("set_till_where")
            res = f"UPDATE {target_table_or_alias}\nSET {set_clause}\nFROM {tables_used}\nWHERE {where_clause}"
            return beautify(decode(res))
    else:
        return beautify(decode(sql))

