import re
import pandas as pd
from config import config, db, client, s3
from libs.etl_util.updateFixTdToSf import final_upd
from libs.etl_util.testing_del_fix import delete_fix
from libs.etl_util.timestamp_hardcode_fix import ts_hardcode_fix
from libs.etl_util.interval_fix import interval_fix
from libs.etl_util.drop_fix import get_drop_list
from libs.etl_util.timestamp_cast_fix2 import timestamp_cast_fix
from libs.etl_util.insert_fix import insert_fix


class Counter:
    def __init__(self):
        self.count = 100
        self.temp_name = ''
        self.temp_name1 = ''
    def increment(self, match_object):
        self.temp_name = ''
        self.temp_name1= '!!!!capgeminiiiiii '
        self.count += 1
        self.temp_name = self.temp_name1+ str(self.count)+self.temp_name
        return str(self.temp_name)


class Counter1:
    def __init__(self):
        self.count = 100
        self.temp_name = ''
        self.temp_name1 = ''
    def increment1(self, match_object):
        self.temp_name = ''
        self.temp_name1= '----capgemini_universe '
        self.count += 1
        self.temp_name = self.temp_name1+ str(self.count)+self.temp_name
        return str(self.temp_name)


class SnowflakeCon:
    drop_list = []
    tab_char = "  "

    def indent_it(self,string, num_indents):
        # indents string with 'num_indents'
        tres = "\n".join([self.tab_char*(num_indents)+line if len(line.strip())> 0 else line for line in string.split("\n")])
        return tres


    def deindent_it(self, string):
        tres = "\n".join([line.strip() for line in string.split("\n") if line.strip()])
        return tres + '\n'


    def bteq_to_snowflake(self, filename, file, link_service_id, job_id, job_run_id, path):
        self.filename=filename

        #add header for output python file
        header = """import re
import pymongo
import snowflake.connector
import boto3

def substitute_vars(query):
    variables = db.idea_etl_variables.find_one({'""" + path + """' + "." + '""" + filename + """': {"$exists": True}},
                                                {"_id": 0, '""" + path + """' + "." + '""" + filename + """': 1})
    if bool(variables):
        for variable in variables['""" + path + """']['""" + filename + """'].keys():
            query = re.sub(r"\$\s*" + variable,
                    variables['""" + path + """']['""" + filename + """'][variable],
                    query)
    return query


def exec(query):
    substituted_query = substitute_vars(query)
    cur.execute(substituted_query)


def disconnect():
    cur.execute('ALTER SESSION UNSET QUERY_TAG')
    cur.close()


try:
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name='us-east-1',
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key)
    snow_cred = json.loads(client.get_secret_value(SecretId = "etl-snowflake-cred")['SecretString'].replace("'", '"')),
    conn = snowflake.connector.connect(
            user = snow_cred["snowflake_username"],
            password = snow_cred["snowflake_password"],
            account = snow_cred["snowflake_hostname"].split(".snowflake")[0]
        )
    db = pymongo.MongoClient("mongodb://{username}:{password}@{url}/?ssl=true&"
            "ssl_ca_certs=rds-combined-ca-bundle.pem&"
            "tlsAllowInvalidHostnames=true&retryWrites=false".
            format(username=config['documentdb']['username'],
                    password=config['documentdb']['password'],
                    url=config['documentdb']['hostname'])).""" + config["database"]["dbname"] + """
    try:
        cur = conn.cursor()
        cur.execute("ALTER SESSION SET QUERY_TAG = " + '""" + filename + """')"""

        #add footer for output python file
        footer = '{0}{0}except Exception as e:\n{0}{0}{0}{0}print(e)\n{0}{0}finally:\n{0}{0}{0}{0}disconnect()\nexcept Exception as e:\n{0}{0}print(e)'.format(self.tab_char)
        sql_final_final_op = ""
        keywords = pd.DataFrame(db.idea_etl_td_keywords.find())
        td_keywords_list = keywords['td_keywords_list'][0]
        td_keywords_check = re.compile(r"\b(?:%s)\b" % "|".join(td_keywords_list))
        sql_keywords_list = keywords['sql_keywords_list'][0]
        sql_keywords_check = re.compile(r"\b(?:%s)\b" % "|".join(sql_keywords_list))
        sql_keywords_list1 = keywords['sql_keywords_list1'][0]
        sql_keywords_list2 = keywords['sql_keywords_list2'][0]
        sql_keywords_list3 = keywords['sql_keywords_list3'][0]

        comments = ''
        final_final_op = ''
        sql_lines = file
        data=convert_bteq(sql_lines)
        find_it = re.compile(r"/\*[^*]*\*+(?:[^/*][^*]*\*+)*/",re.MULTILINE | re.IGNORECASE)

        b={}
        key=101
        for match in re.finditer(find_it,data):
            a = match.group()
            if len(a.strip())>0:
                b[key]=a
                key+=1
        c = Counter()
        data121 = find_it.sub(c.increment,data)
        find_it1 = re.compile(r"(--.*)",re.MULTILINE | re.IGNORECASE)

        o={}
        key=101
        for match in re.finditer(find_it1,data121):
            op= match.group()
            if len(op.strip())>0:
                o[key]=op
                key+=1
        k = Counter1()
        data122=find_it1.sub(k.increment1,data121)
        ab=data122.splitlines()
        res = ab
        res2=''
        for res1 in res:
            res2+=str(res1)+'\n'

        abc=''
        for awq in res2.split('\n'):
            abc += awq
            if td_keywords_check.search(awq.upper()) and awq.strip()[-1] != ';':
                abc+=';'
            abc += '\n'

        data1 = abc.split(';')
        zaa=0

        for z in b.keys():
            ppa=''
            for pqa in str(b[z]).split('\n'):
                if len(pqa.strip())>0:
                    pqa=re.sub(r"[\t\s]+", " ",pqa)
                    ppa+= "{}#".format(self.tab_char) + pqa.strip() +'\n'
            b[z]=ppa

        for z in o.keys():
            ppa=''
            for pqa in str(o[z]).split('\n'):
                if len(pqa.strip())>0:
                    pqa=re.sub(r"[\t\s]+", " ",pqa)
                    ppa+= self.tab_char+'#' + pqa.strip() +'\n'
            o[z]=ppa

        self.drop_list = get_drop_list(data1)
        exec = 'exec("""'
        exec_end = ';""")'
        regex_1 = r"(\s)+"
        regex_2 = "(!!!!.*)|(--.*)"
        etl_path = "/ETL_Migration/"
        found_first_sql = False
        for index in range(len(data1)):
            line = data1[index]
            if len(line.strip(' \n'))==0:
                continue
            converted_line1=''
            converted_line=''
            trimmer2 = ''
            if re.sub(r"[\n\t\s]*", "",line).startswith(('--','!!!!')):
                for trimmer1 in line.splitlines():
                    if len(trimmer1.strip())==0:
                        continue
                    if re.search(r"(^--.*)", trimmer1):
                        trimmer2+=trimmer1
                        continue
                    if re.search(r"(^!!!!.*)", trimmer1):
                        trimmer2+=trimmer1
                        continue
                    if len(trimmer2) > 0 :
                        break
                converted_line1= trimmer2.strip()
            if (len(converted_line1.strip()) > 0):
                converted_line1 += '\n'
            else:
                converted_line1 = ""

            #find and comment teradata specific non-sql statements
            if td_keywords_check.search(line.upper()):
                mnap = (re.sub("(!!!!.*)|(--.*)|(#.*)", "", line)).strip(" \t")
                if index not in self.drop_list:
                    converted_line = self.tab_char + '#' + re.sub(r"[\n\t]+", r" ", mnap) +'\n'
                else:
                    converted_line = self.tab_char+exec+ mnap.strip('\n\t ').upper().replace("DROP TABLE","DROP TABLE IF EXISTS") +exec_end+"\n"
            elif re.sub(r"[\n\t\s]*", "",line).startswith('database') :
                zaa+=1
                line=line.replace('database ${','USE SCHEMA ${')
                converted_line = self.tab_char+exec+line.lstrip('\n\t ').rstrip('\n\t ')+exec_end+"\n"

            #find and comment teradata specific sql statements. These needs to be converted to Snowflake specific
            elif sql_keywords_check.search(line.upper()):
                zaq =(sql_keywords_check.search(line.upper()).group(0))
                if zaq in sql_keywords_list1:
                    zaa+=1
                    data202 = re.sub("(!!!!.*)|(--.*)|(#.*)", "", line)
                    ress1 = [row.strip() for row in data202.splitlines()]
                    gg1=re.compile(regex_1)
                    aa1=[re.sub(gg1,' ',str(row12)) for row12 in ress1 ]
                    bbbb1=[ii for ii in aa1 if len(ii)>0]
                    ress2=('\n{}'.format(self.tab_char).join(bbbb1))
                    ress3 = final_upd(ress2).rstrip("; ")
                    converted_line = self.tab_char+exec+ress3.lstrip('\n\t ').rstrip('\n\t ')+exec_end+"\n"
                elif zaq in sql_keywords_list2:
                    zaa+=1
                    data201 = re.sub(regex_2, "", line)
                    ress11 = [row.strip() for row in data201.splitlines()]
                    gg11=re.compile(regex_1)
                    aa11=[re.sub(gg11,' ',str(row122)) for row122 in ress11 ]
                    bbbb11=[ii11 for ii11 in aa11 if len(ii11)>0]
                    ress22=('\n{}'.format(self.tab_char).join(bbbb11))
                    if zaq.upper() == 'DELETE':
                        ress22 = delete_fix(ress22)
                    if zaq.upper() == 'INSERT':
                        try:
                            ress22 = insert_fix(ress22)
                        except Exception:
                            pass
                    converted_line= self.tab_char+exec+ress22.lstrip('\n\t ').rstrip('\n\t ')+exec_end+"\n"
                elif zaq in sql_keywords_list3:
                    no_comments = re.sub(regex_2, "", line)
                    whitespace_regex =re.compile(regex_1)
                    cleaned_txt_lst =[re.sub(whitespace_regex,' ',row.strip()) for row in no_comments.split("\n") if len(row.strip("\n "))>0]
                    cleaned_txt =('\n{}'.format(self.tab_char).join(cleaned_txt_lst))
                    # if next block contains an activitycount check, then keep it, else comment it.
                    to_comment = False if (index < len(data1)-1 and data1[index+1].lower().find(' activitycount ') >= 0) else True
                    # update : keep all selects
                    to_comment = False
                    if to_comment:
                        converted_line = '{}# '.format(self.tab_char)+ re.sub(r"[\n\t]*", "",cleaned_txt) + "\n"
                    else :
                        # an uncommented statement is a new statement
                        zaa += 1
                        converted_line = self.tab_char+exec+cleaned_txt.lstrip('\n\t ').rstrip('\n\t ')+exec_end+"\n"
                # added fix for create table with no data clause
                else:
                    zaa+=1
                    data200 = re.sub(regex_2, "", line)
                    res = [row.strip() for row in data200.splitlines()]
                    g=re.compile(regex_1)
                    a=[re.sub(g,' ',str(row1)) for row1 in res ]
                    bbb=[i for i in a if len(i)>0]
                    res1=('\n{}'.format(self.tab_char).join(bbb))
                    res1=res1.replace('database ${','USE SCHEMA ${')
                    result=res1.replace('clndr_dt = date','clndr_dt = CURRENT_DATE')
                    if zaq.upper() == 'CREATE':
                        result = create_with_no_data_fix(result)
                    converted_line= self.tab_char+exec+result.lstrip('\n\t ').rstrip('\n\t ')+exec_end+"\n"
            else:
                data200 = re.sub(regex_2, "", line)
                converted_line= '{}# '.format(self.tab_char)+ re.sub(r"[\n\t]*", "",data200)+'\n'
            if not found_first_sql and converted_line1:
                comments = converted_line1
                converted_line1 = ''

            found_first_sql = True
            qa = converted_line1 + converted_line

            bb=100
            for z in range(len(b)):
                ba='!!!!capgeminiiiiii '
                bb=bb+1
                bd=ba+str(bb)
                qa=qa.replace(bd,b[bb])
                comments = comments.replace(bd, b[bb])

            qaa=qa
            bbb=100
            for zz in range(len(o)):
                baa='----capgemini_universe '
                bbb=bbb+1
                bdd=baa+str(bbb)
                qaa=qaa.replace(bdd,o[bbb])
                comments = comments.replace(bdd, o[bbb])

            qaa = interval_fix(qaa)
            qaa = self.indent_it(qaa, 3)

            final_final_op += qaa

        sql_final_final_op = final_final_op.replace('        ', "").replace(exec,"").replace('""")',"")
        final_final_op = self.deindent_it(comments) + header+'\n\n' + final_final_op + '\n'+ footer
        final_final_op = implicit_truncate_during_cast_fix(final_final_op)
        s3.Object(config['aws']['bucket'], "sfmigration/"+link_service_id+"/ETL_Migration/"+job_run_id+"/"+filename+".btq").put(Body=file)
        s3.Object(config['aws']['bucket'], "sfmigration/"+link_service_id+"/ETL_Migration/"+job_run_id+"/SF_"+filename+".sql").put(Body=sql_final_final_op)
        s3.Object(config['aws']['bucket'], "sfmigration/"+link_service_id+"/ETL_Migration/"+job_run_id+"/SF_"+filename+".py").put(Body=final_final_op)
        variables = list(set(re.findall('\$\s*(\w+)',sql_final_final_op)))
        if variables != []:
            db.job_registry.update_one({"job_id":job_id},{"$set":{"variables":True}})
            for variable in variables:
	            db.idea_etl_variables.update_one({},{"$set":{path+"."+filename+"."+variable:"$"+variable, path+"."+filename+".job_id":job_id}})


def implicit_truncate_during_cast_fix(string):
    string = re.sub(r'(?i)(as[\s]+)(varchar|char)(\([\d]+\))', r'\g<1> varchar', string)
    return string


def create_with_no_data_fix(s):
    if(re.search(r'(?i)with\s*no\s*data',s)):
        s = s.lower().replace('with no data','')
        s = s.lower().replace(' as ',' like ', 1)
        return s
    return s


def convert_bteq(data):
	
    # removing date/time/timestamp format '' when not preceded by as
    regex3 = re.compile(r"(?i)(date|time|timestamp)\s+format([\s])+['\"]([^'\"]+)['\"]")
    res = ''
    end = 0
    for match_obj in re.finditer(regex3, data):
        # check if not preceded by 'as'
        start = match_obj.start()-1
        # ignore whitespace
        while start > 0:
            if data[start] not in ['\n',' ', '\t']:
                break
            start -= 1
        # scan this word
        word = ''
        while start > 0:
            if data[start] in ['\n',' ', '\t', ',']:
                break
            word = data[start] + word
            start -=1
        if word.lower() != 'as':
            res += data[end:match_obj.start()]+match_obj.group(1)
            end = match_obj.end()
    res += data[end:]   
    data = res

    for pair in db.idea_etl_td_snow.find({},{"_id":0, "teradata_keyword":0}):
        data = re.sub(pair['detect_regex'], pair['snowflake_replacement'], data)

    #TIMESTAMP HARDCODE FIX
    result29 = ts_hardcode_fix(data)
    
    #TIMESTAMP CAST FIX
    result30 = timestamp_cast_fix(result29)
    
    return result30


def main(filename, file, link_service_id, job_id, job_run_id, path):
    th=SnowflakeCon()
    th.bteq_to_snowflake(filename, file, link_service_id, job_id, job_run_id, path)
