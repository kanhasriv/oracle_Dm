import re

text = """
UPDATE ${WORK_DB}.f_dng_res_tbl
SET etl_chksum_am = hash_md5(
coalesce(dng_srvc_prd_nm ,'')||'|'||
coalesce(comctn_chan_nm ,'')||'|'||
coalesce(res_sts_nm ,'')||'|'||
coalesce(fac_shft_nm ,'')||'|'||
coalesce(fac_stn_nm ,'')||'|'||
coalesce(fac_flr_plan_nm ,'')||'|'||
coalesce(cast(cast(snap_dt as date format 'yyyy-mm-dd') as VARCHAR(25)),'')||'|'||
coalesce(cast(cast(snap_utc_dts AS timestamp(6) format 'mm/dd/yyyybhh:mi:ss')  as varchar(25)),'')	||'|'||
coalesce(tbl_preasgn_in ,'')||'|'||
coalesce(tbl_seat_in ,'')||'|'||
coalesce(cast(cast(tbl_preasgn_strt_dt as date format 'yyyy-mm-dd') as VARCHAR(25)),'')||'|'||
coalesce(cast(cast(tbl_preasgn_strt_dts AS timestamp(6) format 'mm/dd/yyyybhh:mi:ss')  as varchar(25)),'')	||'|'||
coalesce(cast(cast(tbl_preasgn_end_dt as date format 'yyyy-mm-dd') as VARCHAR(25)),'')||'|'||
coalesce(cast(cast(tbl_preasgn_end_dts AS timestamp(6) format 'mm/dd/yyyybhh:mi:ss')  as varchar(25)),'')	||'|'||
coalesce(cast(cast(tbl_seat_strt_dt as date format 'yyyy-mm-dd') as VARCHAR(25)),'')||'|'||
coalesce(cast(cast(tbl_seat_strt_dts AS timestamp(6) format 'mm/dd/yyyybhh:mi:ss')  as varchar(25)),'')	||'|'||
coalesce(cast(cast(tbl_seat_end_dt as date format 'yyyy-mm-dd') as VARCHAR(25)),'')||'|'||
coalesce(cast(cast(tbl_seat_end_dts AS timestamp(6) format 'mm/dd/yyyybhh:mi:ss')  as varchar(25)),'')	||'|'||
coalesce(cast(cast(tbl_dirty_dt as date format 'yyyy-mm-dd') as VARCHAR(25)),'')||'|'||
coalesce(cast(cast(tbl_dirty_dts AS timestamp(6) format 'mm/dd/yyyybhh:mi:ss')  as varchar(25)),'')	||'|'||
coalesce(cast(cast(tbl_cln_dt as date format 'yyyy-mm-dd') as VARCHAR(25)),'')||'|'||
coalesce(cast(cast(tbl_cln_dts AS timestamp(6) format 'mm/dd/yyyybhh:mi:ss')  as varchar(25)),'')	||'|'||
coalesce(cast(cast(next_seat_dts AS timestamp(6) format 'mm/dd/yyyybhh:mi:ss')  as varchar(25)),'')
);
AS entprs_sch_id,

"""

reDict = {
    "PLACEHOLDER" : r"(?i)\+\+\+PLACEHOLDER(\d)+\+\+\+",
    "WITHIN_PARENS" : r"\(([^\)\(]*)\)",
    "SINGLE_CAST" : r"(?i)([\s\S]+?(?=\s+as\s+))\s+as\s+(time|date|timestamp)\s*(&&&\d+)*\s+format\s+['\"]{1}([^'\"]+)['\"]{1}"
}

# placeholder vars
placeholder_cnt = 1
placeholder = "+++PLACEHOLDER{}+++"
placeholderDict = {}

aandDict = {}

def and_add(string):
    and_cnt = 0
    match = re.search(r"(\(\d\))",string)
    while match is not None :
        start = match.start()
        end = match.end()
        val = '&&&{}'.format(str(and_cnt))
        string = string[:start] + val + string[end:]
        aandDict[val] = match.group(0)
        and_cnt += 1
        match = re.search(r"(\(\d\))",string)
    return string
        
def remove_and(string):
    match = re.search(r"(&&&\d+)", string)
    while match is not None :
        start = match.start()
        end = match.end()
        val = aandDict[match.group(0)]
        string = string[:start] + val + string[end:]
        match = re.search(r"&&&\d+", string)
    return string

def find_cast(string, end):
    while end >= 4:
        if string[end-4:end].lower() == "cast":
            return (end-4)
        end-=1
    return -1
    
def encode(string):
    string = and_add(string)
    global placeholder_cnt, placeholder
    match = re.search(reDict["WITHIN_PARENS"], string)
    while match is not None :
        start = match.start()
        end = match.end()
        val = match.group(0)
        # if val is of type : something as time/date/timestamp format 'format', then capture
        single_cast_match = re.search(reDict["SINGLE_CAST"], match.group(1))
        if single_cast_match:
            something = single_cast_match.group(1)
            dt_type = single_cast_match.group(2)
            precision = single_cast_match.group(3)
            if precision:
                aandDict[precision] = aandDict[precision].strip('()')
                precision = '.FF'+precision
            else:
                precision = ''
            format_val = single_cast_match.group(4)
            start = find_cast(string, start)
            val = "to_{0}({1},'{2}{3}')".format(dt_type, something, format_val, precision)
        string = (string[:start] if start > 0 else '') + placeholder.format(str(placeholder_cnt)) + string[end:]
        placeholderDict[placeholder.format(str(placeholder_cnt))] = val
        placeholder_cnt += 1
        match = re.search(reDict["WITHIN_PARENS"], string)
    return string
   
# decoding    
def decode(txt):
    match = re.search(reDict["PLACEHOLDER"], txt)
    while match is not None :
        start = match.start()
        end = match.end()
        val = txt[start:end]
        txt = txt[:start] + placeholderDict[val] + txt[end:]
        match = re.search(reDict["PLACEHOLDER"], txt)
    return remove_and(txt)
    
def timestamp_cast_fix2(s):
    s = encode(s)
    return decode(s)

def timestamp_cast_fix(s):
    s1 = ''
    s2 =''
    s3=''
    s4 = ''
    s5 = ''
    s6='\''
    a = s.count('format')
    s=s.replace('\n',' &$& ')
    spre = ''
    for i in range(0,a):
        if(re.search('(?i)cast(\s*\&\$\&\s*)*\((\s*\&\$\&\s*)*cast.*?format.*?char.*?\)',s)):
            x = re.search('(?i)cast(\s*\&\$\&\s*)*\((\s*\&\$\&\s*)*cast.*?format.*?char.*?\)',s)
            j,k = x.span()
            s1 = s[j:k+1]
            if(re.search('(?i)([\s]timestamp(\(\d*\))*(\s*\&\$\&\s*)*\sformat.*?)|([\s]time(\(\d*\))*(\s*\&\$\&\s*)*\sformat.*?)',s1)):
                a1 = re.search('(?i)([\s]timestamp(\(\d*\))*(\s*\&\$\&\s*)*\sformat.*?)|([\s]time(\(\d*\))*(\s*\&\$\&\s*)*\sformat.*?)',s1)
                a2,a3 = a1.span()
                s5 = s1[a2+1:a3-6]
                if(re.search('[?\d]',s1)):
                    y = re.search('[?\d]',s1)
                    l,m = y.span()
                    s6 = '\''
                z = re.search('format\s*(\s*\&\$\&\s*)*\'.*?\'',s1)
                n,o = z.span()
                s2 = s1[n+6:o-1] + s6
                s2 = s2.replace('b',' ')
                s1 = s1.replace('(','|',1)
                q = re.search('(?i)\(.*?format',s1)
                p,r = q.span()
                s3 = s1[p+1:r-3-len(s5)-6]
                s4 = 'TO_VARCHAR({col}::{type1},{form})'.format(col = s3,type1=s5, form=s2)
                s = s.replace(s[j:k+1],s4)
                k = j + len(s4)
            elif(re.search('(?i)([\s]date(\s*\&\$\&\s*)*\sformat.*?)',s1)):
                a1 = re.search('(?i)([\s]date(\s*\&\$\&\s*)*\sformat.*?)',s1)
                a2,a3 = a1.span()
                s5 = s1[a2+1:a3-6]
                z = re.search('(?i)format\s*(\s*\&\$\&\s*)*\'.*?\'',s1)
                n,o = z.span()
                s2 = s1[n+6:o]
                s2 = s2.replace('b',' ')
                s1 = s1.replace('(','|',1) 
                q = re.search('(?i)\(.*?format',s1)
                p,r = q.span()
                s3 = s1[p+1:r-3-len(s5)-6]
                s4 = 'TO_VARCHAR({col}::{type1},{form})'.format(col = s3,type1=s5, form=s2)
                s = s.replace(s[j:k+1],s4)
                k = j + len(s4)
            spre += s[:k]
            s = s[k:]
    s = spre+s
    return timestamp_cast_fix3(timestamp_cast_fix2(s))


def timestamp_cast_fix3(s):
    # for scenario like : "cast(\ncast(current_timestamp(6) \nas\n\n format \n'YYYY-MM-DD hh:mi:ss.s(6)'))as varcharugj,hwgjhdgshdshbvchar) \n cast(cast(current_time(6) as format 'YYYY-MM-DD hh:mi:ss.s(6)') as varchar(26)) \n cast(cast(current_date as format 'YYYY-MM-DD hh:mi:ss.s(6)') as varchar(26))"
    s1=''
    s12=''
    s2=''

    a=s.count('format')
    for i in range(0,a+1):
        if(re.search("cast(\s*\&\$\&\s*)*\((\s*\&\$\&\s*)*cast.*?char?(\(\d*\))*",s)):
            x=re.search("cast(\s*\&\$\&\s*)*\((\s*\&\$\&\s*)*cast.*?char?(\(\d*\))*",s)
            j,k=x.span()
            s12=s[j:k]
            if(re.search(".*(timestamp|time|date)(\(\d\))*(\s*\&\$\&\s*)*\s*as\s*(\s*\&\$\&\s*)*format.*?(\'\))",s12)):
                z=re.search(".*(timestamp|time|date)(\(\d\))*(\s*\&\$\&\s*)*\s*as\s*(\s*\&\$\&\s*)*format.*?(\'\))",s12)
                n,o=z.span()
                s1=s12[n:o]
                s1=re.sub('as\s*(\s*\&\$\&\s*)*format',',',s1)
                y=re.search("\'.*\'",s1)
                l,m=y.span()
                s2=s1[l:m]
                s2=s2.upper().replace('B',' ')
                s2=re.sub("(?i)\.s\(\d*\)",'',s2)
                s1=re.sub("\'.*\'",s2,s1)
                s1=re.sub('cast(\s*\&\$\&\s*)*\((\s*\&\$\&\s*)*cast','TO_VARCHAR',s1)
                s=s.replace(s[j:k+1],s1)
    s=s.replace(' &$& ','\n')
    return s