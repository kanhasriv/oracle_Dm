import os
import configparser
import pymongo
import boto3
from client import send_message

config = configparser.ConfigParser()
if "FLASK_ENV" in os.environ and os.environ["FLASK_ENV"] == "development":
    config.read("dev-config.ini")
else:
    config.read("config.ini")

session = boto3.session.Session()

# Creating AWS Secret Manager Client
client = session.client(
    service_name='secretsmanager',
    region_name=config['aws']['region'])

# Creating the s3 Client
s3 = boto3.resource(
    service_name='s3',
    region_name=config['aws']['region']
)

config.update({
    "documentdb": {
            "hostname": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_hostname"])["SecretString"],
            "username": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_user"])["SecretString"],
            "password": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_password"])["SecretString"]
                    },
    "kafka": {
        "host": client.get_secret_value(SecretId = "kafka-host")['SecretString'],
        "topic_job_register": config['kafkatopics']['topic_job_register'],
        "topic_job_run": config['kafkatopics']['topic_job_run'],
        "topic_etl_migration": config['kafkatopics']['topic_etl_migration'],
    }
})

# Connecting to DocumentDB Server
db_client = pymongo.MongoClient("mongodb://{username}:{password}@{url}/?ssl=true&"
                                "ssl_ca_certs=rds-combined-ca-bundle.pem&"
                                "tlsAllowInvalidHostnames=true&retryWrites=false&replicaSet=rs0&readPreference=primary".
                                format(username=config['documentdb']['username'],
                                       password=config['documentdb']['password'],
                                       url=config['documentdb']['hostname']))

db = db_client[config["database"]["dbname"]]
