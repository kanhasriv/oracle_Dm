#!/bin/bash
filename=Dockerfile
svc=${PWD##*/}
echo $svc
if [ ! -f $filename ]
then
    echo $svc

       echo -e "FROM nexus.idea.xpaas.io/repository/docker-dev/ubuntuodbcoraclehivev1:latest \nRUN apt-get update && apt-get install -y --no-install-recommends \\ \n unixodbc \\ \n unixodbc-dev \\ \n libpq-dev \nRUN python3 -m pip install  --upgrade pip \nWORKDIR /${svc,,}\nCOPY requirements.txt ./\n RUN pwd \n RUN python3 --version \nRUN pip3 install --no-cache-dir -r requirements.txt \nRUN mkdir -p /var/log/migrationsf\nCOPY . .\nCMD [ \"sh\", \"./${svc,,}.sh\" ]" > $filename;
fi
echo -e "mkdir -p /data \n python3 ./app.py" > ${svc,,}.sh
ls -ltr
