import os
import configparser
import pymongo
import boto3
from client import send_message

config = configparser.ConfigParser()
if "FLASK_ENV" in os.environ and os.environ["FLASK_ENV"] == "development":
    config.read("dev-config.ini")
else:
    config.read("config.ini")

session = boto3.session.Session()

# Creating AWS Secret Manager Client
client = session.client(
    service_name='secretsmanager',
    region_name=config['aws']['region_name'])

# Creating AWS Glue Client
glue_client = session.client(
    service_name='glue',
    region_name=config['aws']['region_name'])

config.update(
    {
        "documentdb": {
            "hostname": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_hostname"])["SecretString"],
            "username": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_user"])["SecretString"],
            "password": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_password"])["SecretString"]
                    },
        "kafka": {
            "host": client.get_secret_value(SecretId = "kafka-host")['SecretString'],
            "topic_s3_sf": config['kafkatopics']['topic_s3_sf'],
            "topic_job_run": config['kafkatopics']['topic_job_run'],
        }
    })

# Connecting to DocumentDB Server
db_client = pymongo.MongoClient("mongodb://{username}:{password}@{url}/?ssl=true&"
                                "ssl_ca_certs=rds-combined-ca-bundle.pem&"
                                "tlsAllowInvalidHostnames=true&retryWrites=false&replicaSet=rs0&readPreference=secondaryPreferred".
                                format(username=config['documentdb']['username'],
                                       password=config['documentdb']['password'],
                                       url=config['documentdb']['hostname']))

db = db_client[config["database"]["dbname"]]

def update_dashboard(job_run_id, table, database):
    rows = 0
    s3_duration = 0
    sf_duration = 0
    run_data = db.job_run_detail.find_one({"job_run_id": job_run_id, "object_name": table, "object_parent": database})
    for split in run_data['splits']:
        if split['split_status_sf'] in ["Success", "Fail"]:
            rows += split.get('noofrows_written_sf', 0) or 0
            s3_duration = max(s3_duration, split.get('copy_s3', 0) or 0)
            sf_duration = max(sf_duration, split.get('copy_sf', 0) or 0)
    return rows, s3_duration, sf_duration