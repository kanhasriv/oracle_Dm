import re

text = """

delete from ${WORK_DB}.tms_raw_archive
where RECEIVED_DT < date - ${ARCHIVE_DATE};

"""

# regex dict
reDict = {
    "AS_CHECK" : r"(?i)[\s]+as[\s]+",\
    "FROM_CHECK" : r"(?i)[\s]+from[\s]+",\
    "WHERE_CHECK" : r"(?i)[\s]+where[\s]+",\
    "PLACEHOLDER" : r"(?i)\+\+\+PLACEHOLDER(\d)+\+\+\+",\
    "WITHIN_PARENS" : r"\(([^\)\(]*)\)",\
    "WORDS_NO_PUNC" : r"([\w]+)"
}

# placeholder vars
placeholder_cnt = 1
placeholder = "+++PLACEHOLDER{}+++"
placeholderDict = {}
regex_3 = "[\s]+"
tab_char = "    "

# beautifies the string with proper indentation and stripping extra spaces
def beautify(ip):
	if type(ip) == "list":
		return tab_char + "\n{}".format(tab_char).join([re.sub(r"(?i)([\s]+)|\ball\b"," ",line.strip()) for line in ip])
	return tab_char + "\n{}".format(tab_char).join([re.sub(r"(?i)([\s]+)|\ball\b"," ",line.strip()) for line in ip.split("\n") if line.strip()])

# remove all gibberish whitespace and new lines
def preprocess(string):
    # replace all multiple new lines and whitespace with single occurrences
    #print([line for line in string.split("\n") if line.strip()])
    string = "\n".join([re.sub(regex_3, " ", line).lstrip() for line in string.split("\n") if line.strip()])
    # remove "AS" keyword
    return string
    
# encoding
def encode(string):
    global placeholder_cnt, placeholder, placeholderDict
    match = re.search(reDict["WITHIN_PARENS"], string)
    while match is not None :
        start = match.start()
        end = match.end()
        val = string[start:end]
        string = string[:start] + placeholder.format(str(placeholder_cnt)) + string[end:]
        placeholderDict[placeholder.format(str(placeholder_cnt))] = val
        placeholder_cnt += 1
        match = re.search(reDict["WITHIN_PARENS"], string)
    return string
   
# decoding    
def decode(txt):
    match = re.search(reDict["PLACEHOLDER"], txt)
    while match is not None :
        start = match.start()
        end = match.end()
        val = txt[start:end]
        txt = txt[:start] + placeholderDict[val] + txt[end:]
        match = re.search(reDict["PLACEHOLDER"], txt)
    return txt
    
# get the type of delete statement
def get_type(string):
    # assumption : string is encoded so no nested stuffs
    # type a = delete without any from clause
    # type b = delete from table1 [alias1], table2 [alias2], etc
    # type c = delete table1/alias1 from table2 [alias2], table1 [alias1], etc
    match = re.search(reDict["FROM_CHECK"], string)
    delete_type = 'a'
    if match is not None :
        delete_type = 'c'
        # delete_type is either 'b' or 'c'
        # check if table_name is present between 'delete' and 'from'
        bw_del_and_from = string[len("delete"):match.start()]
        # if len of the substring between 'delete' and 'from' <= 2, it's type 'b'
        if len(bw_del_and_from) <= 2:
            delete_type = 'b'
        return delete_type,match
    return delete_type, -1


def type_a_fix(string):
    # unimplemented as of now
    pass

def type_b_fix(string, from_match):
    # since no table_name between 'delete' and 'from', the first table is target table
    # rest are additional tables and must be separated with a 'using' keyword
    where_match = re.search(reDict["WHERE_CHECK"], string)
    end_pos = len(string)
    if where_match is not None :
        end_pos = where_match.start()
    tables = string[from_match.end():end_pos]
    
    tables = [re.sub(regex_3," ",table.strip()) for table in tables.split(",")]
    res = "delete from " + tables[0]
    
    # check if one table or many
    if len(tables) > 1 : 
        # need for 'using' clause
        res += " using\n" + (",\n".join(tables[1:]))
            
    # append the where clause/rest of block
    res += "\n" + string[end_pos:]
    return res
    
def type_c_fix(string, from_match):
    # delete is followed by either a table name or an alias name
    # first extract all the tables along with their aliases if any from the 'from' clause
    target_tbl = string[len("delete"):from_match.start()].strip()
    where_match = re.search(reDict["WHERE_CHECK"], string)
    end_pos = len(string)
    if where_match is not None :
        end_pos = where_match.start()
    tables = string[from_match.end():end_pos]
    
    tables = [re.sub(regex_3," ",table.strip()) for table in tables.split(",")]
    # alias_dict stores (key, value) pair as (alias_name, table_name)
    # if no alias_name for a table, then the table_name is kept as the alias_name
    alias_dict = {}
    for table in tables:
        splitted = table.split(" ")
        alias_dict[splitted[-1]] = splitted[0]
        
    # check which table_name the target table belonged to
    aux_tables = []
    for alias in alias_dict.keys():
        table_name = alias_dict[alias]
        if table_name != alias : 
                table_name += " " + alias
        if target_tbl.lower() == alias.lower():
            # found target table
            target_tbl = table_name
        else :
            aux_tables.append(table_name)
            
    res = "delete from " + target_tbl
    # check if any additional table
    if len(aux_tables) > 0 : 
        # need for 'using' clause
        res += " using\n" + (",\n".join(aux_tables))
            
    # append the where clause/rest of block
    res += "\n" + string[end_pos:]
    return res
    
    
# fix the del statement
def delete_fix(string):
    nice_code = encode(preprocess(string))
    # fix for "AS" keyword issue
    nice_code = re.sub(reDict["AS_CHECK"], " ", nice_code)
    (del_type,match) = get_type(nice_code)
    res = string
    if del_type == 'a':
        res = string
    elif del_type == 'b':
        res = type_b_fix(nice_code, match)
    elif del_type == 'c':
        res = type_c_fix(nice_code, match)
    return beautify(decode(res))


# tests
#print(delete_fix(text))
    
    