"""
Contains supporting functions for complexity analyzer
"""

import re
import os
import sys
import uuid
import time
import logging
import tempfile
import datetime
import concurrent.futures
from ftplib import FTP
from multiprocessing import cpu_count
import traceback
import pandas as pd
import sql_metadata
from config import config, db, send_message

# Log reference
log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'
complex_not_determined = "Not Determined"
query_band = "SELECT GETQUERYBAND()"

def compare_rules_with_script(val, job_id, job_run_id):
    """
    Compares rules with script
    """

    # Fetch script stats and job rules
    script_stat_list = pd.DataFrame(db.idea_complexity_analyzer_stats.find(
        {"script_name": val, "job_run_id": job_run_id}, {"_id": 0})).values.tolist()[0][2:20]
    rules = pd.DataFrame(db.job_registry.find({"job_id":job_id},{"_id":0,'rule':1}))['rule'][0]
    rules_dict={}
    for i in list(rules):
        rules_dict[i] = list(rules[i].values())
    
    # Calculate complexity paramters
    simple = 0
    medium = 0
    complx = 0
    for i in range(18):
        if script_stat_list[i] <= rules_dict["simple"][i]:
            simple += 1
        elif script_stat_list[i] <= rules_dict["medium"][i]:
            medium += 1
        else:
            complx += 1
    
    # Decide and return analyzed complexity
    if complx != 0:
        complexity = "complex"
    elif medium >= simple:
        complexity = "medium"
    else:
        complexity = "simple"
    return complexity


def get_count(list_of_words,query):
    """
    get keywords count
    """
    count = 0
    for i in list_of_words:
        x = len(re.findall(r'\b'+ i + r'\b', query.upper(), re.IGNORECASE))
        count += x
    return count


def get_sub_queries_count(query):
    """
    get subquery count
    """
    cond = "(SEL"
    reg_delete_where = re.findall(r"(DELETE)\s*(.*)\s*(WHERE)", query,re.MULTILINE|re.IGNORECASE)
    #Subquery_in_delete
    x = re.findall(r"(DELETE\s*.*)([^;]*)", query, re.MULTILINE|re.IGNORECASE)
    line=str(x)
    res_delete = line.count(cond)
    #Subquery_in_update
    x = re.findall(r"(UPDATE\s*.*)([^;]*)", query, re.MULTILINE|re.IGNORECASE)
    line=str(x)
    res_update = line.count(cond)
    return len(reg_delete_where),res_delete,res_update


def bteq_classification(filepath, name, script_type, job_id, job_run_id):
    """
    Categorize complexity for script
    """
    num_of_lines = len(filepath)
    complexity = complex_not_determined
    pref_list = [".", "BTEQ", "bteq", "EOF"]
    temp_file_name = tempfile.NamedTemporaryFile().name + ".txt"
    with open(temp_file_name, "w+") as temp_file_obj:
        for line in filepath:
            if not line.strip().startswith(tuple(pref_list)):
                temp_file_obj.write(line.upper())
                temp_file_obj.write("\n")
    with open(temp_file_name, "r") as temp_file_obj2:
        query_lines = temp_file_obj2.read()
        query_lines = re.sub(r'(/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+/)'
                             r'|(#=([^#]|[\r\n]|(#+([^#=]|[\r\n])))*#=*)|(-.*|[\r\n])',
                             '',query_lines)
    if os.path.exists(temp_file_name):
        os.remove(temp_file_name)
    my_result = pd.DataFrame(db.idea_complexity_analyzer_dimension.find({},
            {"_id":0,"function_type":1,"function_name":1})).values.tolist()
    key_list = []
    val_list = []
    func_dict = {}
    for x in my_result:
        if x[0] not in key_list:
            val_list = []
            key_list.append(x[0])
            val_list.append(x[1])
        else:
            val_list.append(x[1])
        func_dict[x[0]] = val_list
    aggregate_list = func_dict.get("Aggregate_functions")
    analytical_list = func_dict.get("Analytical_functions")
    distinct_list = ['DISTINCT']
    special_char = 0
    if "$" in query_lines:
        special_char = 1
    aggregate_functions = get_count(aggregate_list, query_lines)
    analytical_functions = get_count(analytical_list, query_lines)
    distinct_function = get_count(distinct_list, query_lines)
    where_in_del, subquery_in_del, subquery_in_upd = get_sub_queries_count(query_lines)
    dml_statements = func_dict.get("DML_statements")
    ddl_statements = func_dict.get("DDL_statements")
    query_splits = query_lines.split(';')[:-1]
    query_list = []
    for i in query_splits:
        pref_list = ddl_statements + dml_statements
        if any(word in i.strip().split(" ") for word in pref_list):
            if i.strip() != "SELECT SESSION" and i.strip() != query_band:
                query_list.append(i)
    num_of_queries = len(query_list)
    num_of_ddl = 0
    num_of_dml = 0
    join_count = 0
    count = 0
    subquery_count = 0
    table_list = []
    table_result_list = []
    column_list = []
    column_result_list = []
    upd_columns = 0
    groupby_count = 0
    ins_sel_count = 0
    qualify_count = 0
    for i in query_splits:
        if any(word in i.strip().split(" ") for word in dml_statements):
            if i != query_band:
                num_of_dml = num_of_dml + 1
                pref_list = ["UPD", "UPDATE"]
                if any(word in i.strip().split(" ") for word in pref_list):
                    if "FROM" in i:
                        dct = {}
                        from_pos = i.find('SET')
                        if i.find("WHERE") != -1:
                            set_pos1 = i.find('WHERE')
                            dct['WHERE'] = set_pos1
                        if i.find("JOIN") != -1:
                            set_pos2 = i.find('JOIN')
                            dct['JOIN'] = set_pos2
                        if i.find("INNER JOIN") != -1:
                            set_pos3 = i.find('INNER JOIN')
                            dct['INNER JOIN'] = set_pos3
                        if i.find("LEFT JOIN") != -1:
                            set_pos4 = i.find('LEFT JOIN')
                            dct['LEFT JOIN'] = set_pos4
                        if i.find("RIGHT JOIN") != -1:
                            set_pos5 = i.find('RIGHT JOIN')
                            dct['RIGHT JOIN'] = set_pos5
                        if dct:
                            set_pos = next(iter(dct))
                            to_pos = i.find(set_pos)
                            sub_string = i[from_pos:to_pos]
                            sub_string = sub_string.split('=')
                            upd_columns = upd_columns + (len(sub_string) - 1)
        if any(word in i.strip().split(" ") for word in ddl_statements):
            num_of_ddl = num_of_ddl + 1
        j_count = i.count("JOIN")
        join_count = join_count + j_count
        pref_list = ["SEL", "SELECT"]
        if any(word in i.strip().split(" ") for word in pref_list):
            if i != query_band:
                count = count + 1
        if re.findall(r"INSERT\s*INTO.*SELECT", i):
            ins_sel_count = ins_sel_count + 1
        s_count = i.count("SELECT")
        s_count1 = i.count("SEL ")
        subquery_count = subquery_count + s_count + s_count1
        table_result = sql_metadata.get_query_tables(i)
        table_result_list = table_list + table_result
        column_result = sql_metadata.get_query_columns(i)
        column_result_list = column_list + column_result
        groupby_count1 = len(re.findall(r'GROUP\s*BY\s*\d+', i)) +\
                         len(re.findall(r'GROUP\s*BY\s*[A-Za-z_,]+\d+', i))
        groupby_count = groupby_count + groupby_count1
        qualify_count = len(re.findall(r'QUALIFY', i))
        qualify_count = qualify_count + qualify_count
    insert_dttm = int(datetime.datetime.utcnow().timestamp())
    insert_dttm_str = datetime.datetime.fromtimestamp(insert_dttm).strftime(idea_date_format)
    db.idea_complexity_analyzer_stats.insert_one({"script_name": name, "script_type": script_type,
                                                  "aggregate_functions":aggregate_functions,
                                                  "analytical_functions":analytical_functions,
                                                  "distinct_function":distinct_function,
                                                  "groupby_count":groupby_count,
                                                  "number_of_columns":len(column_result_list),
                                                  "number_of_columns_updated":upd_columns,
                                                  "number_of_ddl_statements":num_of_ddl,
                                                  "number_of_dml_statements": num_of_dml,
                                                  "number_of_joins": join_count,
                                                  "number_of_lines": num_of_lines,
                                                  "number_of_queries": num_of_queries,
                                                  "number_of_subqueries": (subquery_count - count - ins_sel_count),
                                                  "number_of_tables":len(table_result_list),
                                                  "parameters_in_script":special_char,
                                                  "qualify_count":qualify_count,
                                                  "subquery_in_delete":subquery_in_del,
                                                  "subquery_in_update":subquery_in_upd,
                                                  "where_in_delete":where_in_del,
                                                  "job_run_id":job_run_id,
                                                  "insert_dttm":insert_dttm,
                                                  "insert_dttm_str": insert_dttm_str})
    try:
        complexity = compare_rules_with_script(name, job_id, job_run_id)
        status = "Success"
    except Exception as e_error:
        status = "Fail"
        log.error(e_error)
        process_complexity_analyzer.FAIL_FLAG = 1
    insert_dttm = int(datetime.datetime.utcnow().timestamp())
    insert_dttm_str = datetime.datetime.fromtimestamp(insert_dttm).strftime(idea_date_format)
    db.idea_complexity_analyzer_summary.insert_one(
        {"script_name":name+".btq","script_type":script_type,
         "complexity":complexity,"insert_dttm":insert_dttm, "insert_dttm_str":insert_dttm_str,
         "status":status, "job_run_id":job_run_id, "message":"Complexity analyzed successfully"})
    return complexity


def parallel_process_complexity_analyzer(file_name, file,
                                         script_type, log_file_object,
                                         job_id, job_run_id, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
    parallel process for complexity analyzer
    """
    item_id = str(uuid.uuid4())
    complexity = complex_not_determined
    try:
        # Classification function call
        start_time = int(datetime.datetime.utcnow().timestamp())
        start_time_str = datetime.datetime.fromtimestamp(start_time).strftime(idea_date_format)
        db.job_run_detail.insert_one({"item_id":item_id, "job_id":job_id,
                                      "job_run_id":job_run_id, "object_type": script_type,
                                      "object_name": file_name, "status":"InProgress",
                                      "start_time": start_time,"start_time_str":start_time_str})
        complexity = bteq_classification(file,file_name,script_type,job_id,job_run_id)
        log_file_object.write(get_current_time() + "  " +
                              file_name+" and Status is " + complexity + '\n\n')

        # Update IDEA metadata
        if complexity != complex_not_determined:
            if socket_flag:
                send_message("sf_complexity_run_status", {file_name:{"status":"Success","complexity":complexity}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
            end_time = int(datetime.datetime.utcnow().timestamp())
            end_time_str = datetime.datetime.fromtimestamp(end_time).strftime(idea_date_format)
            db.job_run_detail.update_one({"item_id": item_id},
                                         {"$set": {"status": "Success",
                                                   "end_time": end_time,
                                                   "end_time_str": end_time_str}})
        else:
            if socket_flag:
                send_message("sf_complexity_run_status", {file_name:{"status":"Fail","complexity":complex_not_determined}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
            end_time = int(datetime.datetime.utcnow().timestamp())
            end_time_str = datetime.datetime.fromtimestamp(end_time).strftime(idea_date_format)
            db.job_run_detail.update_one({"item_id": item_id},
                                         {"$set": {"status": "Fail",
                                                   "end_time": end_time,
                                                   "end_time_str": end_time_str}})
            log.error(traceback.format_exc())
            process_complexity_analyzer.FAIL_FLAG = 1
    except Exception as e_error:
        if socket_flag:
            send_message("sf_complexity_run_status", {file_name:{"status":"Fail","complexity":complex_not_determined}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
        end_time = int(datetime.datetime.utcnow().timestamp())
        end_time_str = datetime.datetime.fromtimestamp(end_time).strftime(idea_date_format)
        insert_dttm = int(datetime.datetime.utcnow().timestamp())
        insert_dttm_str = datetime.datetime.fromtimestamp(insert_dttm).strftime(idea_date_format)
        db.job_run_detail.update_one({"item_id": item_id},
                                     {"$set": {"status": "Fail",
                                               "end_time": end_time, "end_time_str": end_time_str}})
        db.idea_complexity_analyzer_summary.insert_one(
            {"script_name":file_name+".btq","script_type":script_type,
            "complexity":complex_not_determined,
             "insert_dttm":insert_dttm,
             "insert_dttm_str":insert_dttm_str,
            "status":"Fail", "job_run_id":job_run_id,
            "message":"Error while analyzing script statements"})
        log.error(e_error)
        process_complexity_analyzer.FAIL_FLAG = 1
    return complexity


def handle_binary(more_data):
    """
    handle binary
    """
    data.append(more_data)
    return data


def get_error_info():
    """
    Get error info
    """
    exc_type, exc_obj, exc_tb = sys.exc_info()
    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
    error_string = "FileName : " + fname + "," \
                                           " LineNumber : " \
                   + str(exc_tb.tb_lineno) + ", ExceptionType : " + str(
        exc_type) + ", Exception : " + str(exc_obj)
    return error_string


def get_current_time():
    """
    get current time
    """
    return datetime.datetime.fromtimestamp(time.time()).strftime(idea_date_format)


def connect_ftp(host, user, pwd, path, file_list, job_id, job_run_id,port, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
    Connect ftp
    """
    files = []
    file_names=[]
    global data
    script_type_list=[]
    log_file_path = "libs/etl_paths/complexity_analyzer_output.log"
    with open(log_file_path, "w+") as log_file_object:
        try:
            # Connecting FTP server
            global ftp
            ftp = FTP()
            ftp.connect(host,port)
            ftp.login(user,pwd)
            ftp.cwd(path)
            # ftp.set_pasv(False)

            # File validation
            files_list = ftp.nlst()
            for file_name in file_list:
                if file_name in files_list:
                    ftp.retrlines("RETR "+path+file_name, callback=handle_binary)
                    script_type_list.append("btq")
                    files.append(data)
                    file_names.append(file_name.split(".")[0])
                    data = []
                else:
                    if socket_flag:
                        send_message("sf_complexity_run_status", {file_name.split(".")[0]:{"status":"Fail","complexity":complex_not_determined}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                    log.error(traceback.format_exc())
                    start_time = int(datetime.datetime.utcnow().timestamp())
                    start_time_str = datetime.datetime.fromtimestamp(
                        start_time).strftime(idea_date_format)
                    end_time = int(datetime.datetime.utcnow().timestamp())
                    end_time_str = datetime.datetime.fromtimestamp(
                        end_time).strftime(idea_date_format)
                    db.job_run_detail.insert_one({"item_id":str(uuid.uuid4()), "job_id":job_id,
                                      "job_run_id":job_run_id, "object_type": "btq",
                                      "object_name": file_name.split(".")[0], "status":"Fail",
                                      "start_time": start_time,"start_time_str":start_time_str,
                                      "end_time": end_time, "end_time_str": end_time_str,
                                      "message":"File does not exist at provided path"})
                    
                    # Updating IDEA metadata if file is missing in FTP server
                    db.idea_complexity_analyzer_summary.insert_one(
                    {"script_name":file_name.split(".")[0]+".btq","script_type":"btq",
                    "complexity":complex_not_determined,
                     "insert_dttm":end_time, "insert_dttm_str":end_time_str,
                    "status":"Fail", "job_run_id":job_run_id,
                    "message":"File does not exist at provided path"})
                    process_complexity_analyzer.FAIL_FLAG = 1
            ftp.quit()
        except Exception:
            start_time = int(datetime.datetime.utcnow().timestamp())
            for file in file_list:
                if socket_flag:
                    send_message("sf_complexity_run_status", {file.split(".")[0]:{"status":"Fail", "complexity":complex_not_determined}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                db.job_run_detail.insert_one({"item_id": str(uuid.uuid4()), "job_id": job_id,
                                              "job_run_id": job_run_id, "object_type": "btq",
                                              "object_name": file.split(".")[0], "status": "Fail",
                                              "start_time": start_time,
                                              "start_time_str": datetime.datetime.fromtimestamp(start_time).strftime(idea_date_format),
                                              "end_time": start_time,
                                              "end_time_str": datetime.datetime.fromtimestamp(start_time).strftime(idea_date_format),
                                              "message":"Error connecting FTP server"})
                db.idea_complexity_analyzer_summary.insert_one(
                    {"script_name":file.split(".")[0]+".btq","script_type":"btq",
                    "complexity":complex_not_determined,
                     "insert_dttm":start_time, "insert_dttm_str":datetime.datetime.fromtimestamp(start_time).strftime(idea_date_format),
                    "status":"Fail", "job_run_id":job_run_id,
                    "message":"Error connecting FTP server"})
            log.info(get_error_info())
            log_file_object.write(get_current_time() + " :: ERROR :: " + get_error_info() + '\n\n')
            return {"message":"Error connecting FTP server"}
        return files, script_type_list, file_names


def process_complexity_analyzer(host, user, pwd, path, file_list, job_id, job_run_id,port, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
    process complexity analyzer
    """

    process_complexity_analyzer.FAIL_FLAG = 0
    try:
        files, script_type_list, file_names = connect_ftp(host, user,
                                                          pwd, path, file_list,
                                                          job_id, job_run_id,port, user_id, socket_flag, pipeline_id, pipeline_run_id)
        global log_file_path
        log_file_path = "libs/etl_paths/complexity_analyzer_output.log"
        try:
            with open(log_file_path, "w+") as log_file_object:
                try:
                    the_futures = []
                    with concurrent.futures.ThreadPoolExecutor(max_workers=cpu_count()) as executor:
                        for i, v in enumerate(files):
                            try:
                                the_futures.append(
                                    executor.submit(
                                        parallel_process_complexity_analyzer,
                                        file_names[i],v,script_type_list[i],
                                        log_file_object,job_id, job_run_id, user_id, socket_flag, pipeline_id, pipeline_run_id))
                            except Exception as e_error:
                                log.error(e_error)
                                process_complexity_analyzer.FAIL_FLAG = 1
                                continue
                    for future in the_futures:
                        try:
                            future.result()
                        except Exception as exception:
                            process_complexity_analyzer.FAIL_FLAG = 1
                            log.info(exception)
                            log.error(traceback.format_exc())
                            return False
                except Exception as e_error:
                    process_complexity_analyzer.FAIL_FLAG = 1
                    log_file_object.write(get_current_time()
                                          + " :: ERROR :: " +
                                          get_error_info() + '\n\n')
                    log.error(e_error)
                    return False
        except IOError:
            process_complexity_analyzer.FAIL_FLAG = 1
            log.error(traceback.format_exc())
            return False
        except Exception as e_error:
            process_complexity_analyzer.FAIL_FLAG = 1
            log_file_object.write(get_current_time() + " :: ERROR :: " + get_error_info() + '\n\n')
            log.error(e_error)
            return False
        return process_complexity_analyzer.FAIL_FLAG == 0
    except Exception as e_error:
        log.error(e_error)
        return False


data = []
files = []
file_names = []
all_files = []
