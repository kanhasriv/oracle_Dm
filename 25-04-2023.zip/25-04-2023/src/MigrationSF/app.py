"""
This service populates discovery tables
"""
import logging.handlers
from flask import Flask, request, g
from flask_cors import CORS
import time
from config import config

# Routes for migration APIs
from routes import *


## Author: Suvarna Fernandes
#####################################################################
__author__ = 'Suvarna Fernandes'
__version__ = '1.1'

app = Flask(__name__)

# Enable cors to access our API's from other domains
CORS(app, resources = { r"/idea/services/*": { "origins": "*" } })

# Init Host and post
host = config["service"]["host"]
port = int(config["service"]["port"])

# Log
log = logging.getLogger(config["logging"]["name"])
log.setLevel(int(config["logging"]["logging_level"]))
handler = logging.handlers.RotatingFileHandler(
            config["logging"]["filename"],
            maxBytes = int(config["logging"]["logging_maxBytes"]),
            backupCount = int(config["logging"]["logging_backup_count"]))

# Set the log format
handler.setFormatter(
        logging.Formatter("%(asctime)s|%(levelname)-5.5s|[%(filename)s:%(lineno)s-%(funcName)20s()]|%(message)s"))
log.addHandler(handler)
 


# BLUEPRINT
# This will register the app for all other APIs
# which includes device, home
app.register_blueprint(routes)

# Log Request and Response
# Initialize the start time and log the request
@app.before_request
def log_request():
    g.start = time.time()
    ip = request.remote_addr
    log.info("================== API REQUEST [{}] {} {} Params: {}" . \
            format(ip, request.method, request.path, request.data))


# Log Response with Time taken for completion of the request
@app.after_request
def log_response(response):

    now = time.time()
    duration = round(now - g.start, 4)
    log.info("++++++++++++++++++ API RESPONSE [{}] {}, {} {}, Time Taken: {}" . \
            format(request.remote_addr, response, request.method, request.path, duration))
    return response

if __name__ == "__main__":
    log.info("Snowflake Migration Service initialized Successfully")
    app.run(host=host, port=port, debug=True)
