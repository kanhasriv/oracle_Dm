"""
This service contains APIs for the data sharing
"""

import sys
import pyodbc
import traceback
import logging
import pandas as pd
from deepdiff import DeepDiff
from bson.json_util import dumps
from flask import request, jsonify
from config import (config, db)
from libs import snowflake, error
from libs.access_token import validate_access_token
from libs.secret_manager import get_secret
from libs.util import (validate_json_schema, response, get_userdata, get_batch_id)

# Import app
from . import routes as app

# Log reference
log = logging.getLogger(config["logging"]["name"])
snowflake_dwh = "snowflake DWH"
share_exists = "Share "


@app.route("/idea/services/migrationsf/datasharing/create-share", methods=["POST"])
@validate_json_schema
def datasharing_create_share():
    """
    data sharing create share
    """

    log.info("START")
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["data_sharing"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # # Validate Json Schema and Data
        # if not validate_json_schema(sys._getframe().f_code.co_name, data):
        #     return response(dumps(error.err_074), 400)
        
        # Check if provided either tables or secure views provided
        for share_data in data['data']:
            if share_data['tables'] == [] and share_data['secure_views'] == []:
                return response(dumps(error.err_074), 400)
        
        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Fetch link service details
        link_service_id = data['link_service_id']
        link_service = db.link_service.find_one({"link_service_id":link_service_id, "active":True,
                "link_service_type":snowflake_dwh}, {"_id":0, "db_hostname":1, "db_user": 1})
        
        # Check if share is already present
        shares = list(db.idea_data_sharing_shares.find({"link_service_id": link_service_id, "active": True},
                                                                    {"_id": 0, "share_name": 1, "data": 1}))
        if data['share_name'] in [share['share_name'] for share in shares]:
            share_error = error.err_075.copy()
            share_error['message'] = share_error['message'].format(share=data['share_name'])
            return response(dumps(share_error), 409)

        # Link service validation
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Discovery validation
        batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        # Connecting to snowflake instance
        password = get_secret(data["link_service_id"] + "-password")
        sf_conn_string = config["snowflake"]["conn"].format(hostname=link_service['db_hostname'],
                                                            uid=link_service['db_user'],
                                                            pwd=password, warehouse="COMPUTE_WH")
        conn = pyodbc.connect(sf_conn_string)

        # Database validation
        databases = list(db.idea_database_discovery_attr.find({"batch_id": batch_id}, {"_id": 0, "database_nm": 1}))
        if databases == []:
            return response(dumps(error.err_060), 404)
        databases = [database['database_nm'] for database in databases]
        if data['database'] not in databases:
            return response(dumps(error.err_074), 400)

        # Schemas validation
        schemas = list(db.idea_schema_discovery_attr.find({"batch_id": batch_id,
                                                        "database_name": data['database']},
                                                        {"_id": 0, "schema_name": 1}))
        schemas = [schema['schema_name'] for schema in schemas]
        for share_data in data['data']:
            if share_data['schema'] not in schemas:
                return response(dumps(error.err_074), 400)

        # Validating tables & secure views
        for share_data in data['data']:
            if sorted(share_data['tables']) != sorted(set(share_data['tables'])):
                return response(dumps(error.err_074), 400)
            if sorted(share_data['secure_views']) != sorted(set(share_data['secure_views'])):
                return response(dumps(error.err_074), 400)
            tables = list(db.idea_table_discovery_attr.find(
                {'batch_id': batch_id, 'database_nm': data['database'],
                 'tbl_schema_nm': share_data['schema']}, {"_id": 0, "table_nm": 1}))
            if tables != []:
                tables = [table['table_nm'] for table in tables]
            for table in share_data['tables']:
                if table not in tables:
                    return response(dumps(error.err_074), 400)
            secure_views = list(db.idea_view_discovery_attr.find(
                {'batch_id': batch_id, 'database_nm': data['database'],
                 'schema_nm': share_data['schema'], 'is_secure': 'YES'},
                 {"_id": 0, "view_nm": 1})) + list(db.idea_materialized_view_discovery_attr.find(
                {"batch_id": batch_id, "database_nm": data['database'], "schema_nm": share_data['schema']},
                 {"_id": 0, "view_nm": 1}))
            if secure_views != []:
                secure_views = [secure_view['view_nm'] for secure_view in secure_views]
            for secure_view in share_data['secure_views']:
                if secure_view not in secure_views:
                    return response(dumps(error.err_074), 400)
        
        # Duplicate schema validation
        for share_data in range(len(data['data'])):
            for schema_data in range(share_data+1, len(data['data'])):
                if DeepDiff(data['data'][share_data], data['data'][schema_data], ignore_string_case=True, ignore_order=True) == {}:
                    return response(dumps(error.err_074), 400)

        # Duplicate share validation
        for current_share in shares:
            if DeepDiff(current_share['data'], data['data'], ignore_string_case=True, ignore_order=True) == {}:
                share_error = error.err_075.copy()
                share_error['message'] = share_error['message'].format(share=current_share['share_name'])
                return response(dumps(share_error), 409)

        # Granting database access to share
        cursor = conn.cursor()
        cursor.execute(snowflake.data_sharing["create_share"].format(share=data['share_name']))
        cursor.execute(snowflake.data_sharing["database_grant"].format(database=data['database'], share=data['share_name']))

        # Granting tables & secure views access to share
        for share_data in data['data']:
            cursor.execute(snowflake.data_sharing["schema_grant"].format(database=data['database'], 
                                            schema=share_data['schema'], share=data['share_name']))
            for table in share_data['tables']:
                cursor.execute(snowflake.data_sharing["table_grant"].format(database=data['database'], 
                                schema=share_data['schema'], table=table, share=data['share_name']))
            for secure_view in share_data['secure_views']:
                cursor.execute(snowflake.data_sharing["secure_view_grant"].format(database=data['database'], 
                    schema=share_data['schema'], secure_view=secure_view, share=data['share_name']))

        # Fetching created share details & storing in IDEA metadata
        share_df = pd.read_sql_query(snowflake.data_sharing["share_discover_1"], conn)
        conn.close()
        share_df = share_df[share_df['kind']=='OUTBOUND']
        share_name = link_service['db_hostname'].split(".")[0].upper()+"."+data['share_name']
        share_index = share_df[share_df['name']==share_name].index.tolist()[0]
        created_at_str = share_df[share_df['name']==share_name]['created_on'][share_index]
        share_data = {
            "share_name": data['share_name'],
            "database": data['database'],
            "data": data['data'],
            "active": True,
            "link_service_id": link_service_id,
            "created_by": user_data['name'],
            "modified_by": "",
            "created_at": int(created_at_str.timestamp()),
            "created_at_str": created_at_str,
            "creator": "IDEA"
        }
        db.idea_data_sharing_shares.insert_one(share_data)
    except Exception as e_error:
        log.error(traceback.format_exc())
        return response(dumps(error.err_095), 500)
    
    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": share_exists + share_data['share_name'] + " created successfully",
          "data": ""}), 200


@app.route("/idea/services/migrationsf/datasharing/edit-share", methods=["POST"])
@validate_json_schema
def datasharing_edit_share():
    """
    data sharing edit share
    """

    log.info("START")
    try:
        # # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["data_sharing"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # # Validate Json Schema and Data
        # if not validate_json_schema(sys._getframe().f_code.co_name, data):
        #     return response(dumps(error.err_074), 400)
        
        # Share validation
        for share_data in data['data']:
            if share_data['tables'] == [] and share_data['secure_views'] == []:
                return response(dumps(error.err_074), 400)

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Fetching link service details
        link_service_id = data['link_service_id']
        link_service = db.link_service.find_one({"link_service_id":link_service_id, "active":True,
                "link_service_type":snowflake_dwh}, {"_id":0, "db_hostname":1, "db_user": 1})

        # Fetching shares & validating link service
        shares = list(db.idea_data_sharing_shares.find({"link_service_id": link_service_id, "active": True},
                                                                    {"_id": 0, "share_name": 1, "data": 1}))
        share = db.idea_data_sharing_shares.find_one({"link_service_id": link_service_id, "active": True,
                                                        "share_name": data['share_name']},{"_id": 0})
        if not bool(share):
            return response(dumps(error.err_088), 404)
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Discovery validation
        batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        # Connecting snowflake instance
        password = get_secret(data["link_service_id"] + "-password")
        sf_conn_string = config["snowflake"]["conn"].format(hostname=link_service['db_hostname'],
                                                            uid=link_service['db_user'],
                                                            pwd=password, warehouse="COMPUTE_WH")
        conn = pyodbc.connect(sf_conn_string)

        # Database validation
        databases = list(db.idea_database_discovery_attr.find({"batch_id": batch_id}, {"_id": 0, "database_nm": 1}))
        if databases == []:
            return response(dumps(error.err_060), 404)
        databases = [database['database_nm'] for database in databases]
        if data['database'] not in databases:
            return response(dumps(error.err_074), 400)

        # Schemas validation
        schemas = list(db.idea_schema_discovery_attr.find({"batch_id": batch_id,
                                                        "database_name": data['database']},
                                                        {"_id": 0, "schema_name": 1}))
        schemas = [schema['schema_name'] for schema in schemas]
        for share_data in data['data']:
            if share_data['schema'] not in schemas:
                return response(dumps(error.err_074), 400)

        # Tables & secure views validation
        for share_data in data['data']:
            if sorted(share_data['tables']) != sorted(set(share_data['tables'])):
                return response(dumps(error.err_074), 400)
            if sorted(share_data['secure_views']) != sorted(set(share_data['secure_views'])):
                return response(dumps(error.err_074), 400)
            tables = list(db.idea_table_discovery_attr.find(
                {'batch_id': batch_id, 'database_nm': data['database'],
                 'tbl_schema_nm': share_data['schema']}, {"_id": 0, "table_nm": 1}))
            if tables != []:
                tables = [table['table_nm'] for table in tables]
            for table in share_data['tables']:
                if table not in tables:
                    return response(dumps(error.err_074), 400)
            secure_views = list(db.idea_view_discovery_attr.find(
                {'batch_id': batch_id, 'database_nm': data['database'],
                 'schema_nm': share_data['schema'], 'is_secure': 'YES'},
                {"_id": 0, "view_nm": 1})) + list(db.idea_materialized_view_discovery_attr.find(
                {"batch_id": batch_id,"database_nm": data['database'], "schema_nm": share_data['schema']},
                {"_id": 0, "view_nm": 1}))
            if secure_views != []:
                secure_views = [secure_view['view_nm'] for secure_view in secure_views]
            for secure_view in share_data['secure_views']:
                if secure_view not in secure_views:
                    return response(dumps(error.err_074), 400)
        
        # Duplicate schema validation
        for share_data in range(len(data['data'])):
            for schema_data in range(share_data+1, len(data['data'])):
                if DeepDiff(data['data'][share_data], data['data'][schema_data], ignore_string_case=True, ignore_order=True) == {}:
                    return response(dumps(error.err_074), 400)
        
        # Duplicate share validation
        for current_share in shares:
            if DeepDiff(current_share['data'], data['data'], ignore_string_case=True, ignore_order=True) == {}:
                share_error = error.err_075.copy()
                share_error['message'] = share_error['message'].format(share=current_share['share_name'])
                return response(dumps(share_error), 409)

        # Replace share database if applicable
        cursor = conn.cursor()
        if share['database'] != data['database']:
            for share_data in share['data']:
                for table in share_data['tables']:
                    cursor.execute(snowflake.data_sharing["table_revoke"].format(database=share['database'],
                                                                                schema=share_data['schema'],
                                                                                table=table,
                                                                                share=share['share_name']))
                for secure_view in share_data['secure_views']:
                    cursor.execute(snowflake.data_sharing["secure_view_revoke"].format(database=share['database'],
                                                                                schema=share_data['schema'],
                                                                                secure_view=secure_view,
                                                                                share=share['share_name']))
                cursor.execute(snowflake.data_sharing["schema_revoke"].format(database=share['database'],
                                                                                schema=share_data['schema'],
                                                                                share=share['share_name']))
            cursor.execute(snowflake.data_sharing["database_revoke"].format(database=share['database'],
                                                                                share=share['share_name']))
            share['data'] = ""
        
        # Grant database access to share
        cursor.execute(snowflake.data_sharing["database_grant"].format(database=data['database'],
                                                                    share=share['share_name']))

        # Grant/revoke schema access to share
        schemas = [share_data['schema'] for share_data in share['data']]
        for share_data in data['data']:
            if share_data['schema'] in schemas:
                share_table = set(share['data'][schemas.index(share_data['schema'])]['tables'])
                data_table = set(share_data['tables'])
                revoke_tables = list(share_table.difference(data_table))
                grant_tables = list(data_table.difference(share_table))
                share_secure_views = set(share['data'][schemas.index(share_data['schema'])]['secure_views'])
                data_secure_views = set(share_data['secure_views'])
                revoke_secure_views = list(share_secure_views.difference(data_secure_views))
                grant_secure_views = list(data_secure_views.difference(share_secure_views))
                for table in revoke_tables:
                    cursor.execute(snowflake.data_sharing["table_revoke"].format(database=data['database'],
                                                                                schema=share_data['schema'],
                                                                                table=table,
                                                                                share=share['share_name']))
                for table in grant_tables:
                    cursor.execute(snowflake.data_sharing["table_grant"].format(database=data['database'],
                                                                                schema=share_data['schema'],
                                                                                table=table,
                                                                                share=share['share_name']))
                for secure_view in revoke_secure_views:
                    cursor.execute(snowflake.data_sharing["secure_view_revoke"].format(database=data['database'],
                                                                                schema=share_data['schema'],
                                                                                secure_view=secure_view,
                                                                                share=share['share_name']))
                for secure_view in grant_secure_views:
                    cursor.execute(snowflake.data_sharing["secure_view_grant"].format(database=data['database'],
                                                                                schema=share_data['schema'],
                                                                                secure_view=secure_view,
                                                                                share=share['share_name']))
            else:
                cursor.execute(snowflake.data_sharing["schema_grant"].format(database=data['database'],
                                                                                schema=share_data['schema'],
                                                                                share=share['share_name']))
                for table in share_data['tables']:
                    cursor.execute(snowflake.data_sharing["table_grant"].format(database=data['database'],
                                                                                schema=share_data['schema'],
                                                                                table=table,
                                                                                share=share['share_name']))
                for secure_views in share_data['secure_views']:
                    cursor.execute(snowflake.data_sharing["secure_view_grant"].format(database=data['database'],
                                                                                schema=share_data['schema'],
                                                                                secure_view=secure_view,
                                                                                share=share['share_name']))

        # Updating IDEA metadata
        conn.close()
        db.idea_data_sharing_shares.update_one({"link_service_id": link_service_id, "active": True,
        "share_name": data['share_name']}, {"$set": {"data": data['data'], "database": data['database'],
        "modified_by": user_data['name']}})
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)
    
    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": share_exists + data['share_name'] + " edited successfully",
          "data": ""}), 200


@app.route("/idea/services/migrationsf/datasharing/create-reader", methods=["POST"])
@validate_json_schema
def datasharing_create_reader():
    """
    data sharing create reader
    """

    log.info("START")
    try:
        # # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["data_sharing"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # # Validate Json Schema and Data
        # if not validate_json_schema(sys._getframe().f_code.co_name, data):
        #     return response(dumps(error.err_074), 400)
        
        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Fetching link service details
        link_service_id = data['link_service_id']
        link_service = db.link_service.find_one({"link_service_id":link_service_id, "active":True,
                "link_service_type":snowflake_dwh}, {"_id":0, "db_hostname":1, "db_user": 1})

        # Reader validation
        readers = list(db.idea_data_sharing_readers.find({"link_service_id": link_service_id,
                                                        "active": True},{"_id": 0, "reader_name": 1}))
        if readers != [] and data['reader_name'] in [reader['reader_name'] for reader in readers]:
                reader_error = error.err_082.copy()
                reader_error['message'] = reader_error['message'].format(reader=data['reader_name'])
                return response(dumps(reader_error), 409)

        # Link service validation
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Connecting snowflake instance
        password = get_secret(data["link_service_id"] + "-password")
        sf_conn_string = config["snowflake"]["conn"].format(hostname=link_service['db_hostname'],
                                                            uid=link_service['db_user'],
                                                            pwd=password, warehouse="COMPUTE_WH")
        conn = pyodbc.connect(sf_conn_string)

        # Creating reader in snowflake instance
        cursor = conn.cursor()
        cursor.execute(snowflake.data_sharing["create_reader"].format(reader=data['reader_name'],
                                                                        user=data['user'],
                                                                        password=data['password']))

        # Fetching created reader details
        reader_df = pd.read_sql_query(snowflake.data_sharing["reader_discover"], conn)
        conn.close()
        reader_df = reader_df[reader_df['name']==data['reader_name']]
        reader_index = reader_df[reader_df['name']==data['reader_name']].index.tolist()[0]
        reader_data = {
            "reader_name": reader_df['name'][reader_index],
            "cloud": reader_df['cloud'][reader_index],
            "region": reader_df['region'][reader_index],
            "locator": reader_df['locator'][reader_index],
            "url": reader_df['url'][reader_index],
            "active": True,
            "link_service_id": link_service_id,
            "created_by": user_data['name'],
            "created_at": int(reader_df['created_on'][reader_index].timestamp()),
            "created_at_str": reader_df['created_on'][reader_index],
            "creator": "IDEA"
        }

        # Adding details in IDEA metadata
        db.idea_data_sharing_readers.insert_one(reader_data)
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)
    
    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Reader " + data['reader_name'] + " created successfully",
          "data": {"account_url": reader_df['url'][reader_index]}}), 200


@app.route("/idea/services/migrationsf/datasharing/assign-shares", methods=["POST"])
@validate_json_schema
def datasharing_assign_shares():
    """
    data sharing assign shares
    """

    log.info("START")
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["data_sharing"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # # Validate Json Schema and Data
        # if not validate_json_schema(sys._getframe().f_code.co_name, data):
        #     return response(dumps(error.err_074), 400)

        # Input validation
        if data['readers'] == [] and data['full_accounts'] == []:
            return response(dumps(error.err_074), 400)

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Reader validation
        readers = list(db.idea_data_sharing_readers.find({"link_service_id": data['link_service_id'],
                                                    "active": True},{"_id": 0, "reader_name": 1}))
        if not bool(readers):
            return response(dumps(error.err_088), 404)
        for reader in data['readers']:
            if reader not in [reader['reader_name'] for reader in readers]:
                return response(dumps(error.err_088), 404)

        # Share validation
        shares = list(db.idea_data_sharing_shares.find({"link_service_id": data['link_service_id'],
                                    "active": True}, {"_id": 0, "share_name": 1, "database": 1}))
        if not bool(shares):
            return response(dumps(error.err_088), 404)
        for share in data['shares']:
            if share not in [share['share_name'] for share in shares]:
                return response(dumps(error.err_088), 404)
            share_database = list(filter(lambda x: x['share_name'] == share, shares))[0]['database']
            if share_database == "":
                return response(dumps(error.err_074), 400)

        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True,
                            "link_service_type":snowflake_dwh}, {"_id":0, "db_hostname":1, "db_user": 1})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Connecting snowflake instance
        password = get_secret(data["link_service_id"] + "-password")
        sf_conn_string = config["snowflake"]["conn"].format(hostname=link_service['db_hostname'],
                                                            uid=link_service['db_user'],
                                                            pwd=password, warehouse="COMPUTE_WH")
        conn = pyodbc.connect(sf_conn_string)

        # Assigning shares to readers
        cursor = conn.cursor()
        for share in data['shares']:
            for reader in data['readers']:
                locator = db.idea_data_sharing_readers.find_one({"reader_name": reader, "active": True,
                                                                "link_service_id": data['link_service_id']},
                                                                {"_id": 0, "locator": 1})['locator']
                cursor.execute(snowflake.data_sharing["assign_share"].format(share=share, consumer=locator))
                query = {"share_name": share,"reader_locator": locator,"link_service_id": data['link_service_id']}
                linkage = db.idea_data_sharing_linkage.find_one(query)
                if not bool(linkage):
                    query['active'] = True
                    db.idea_data_sharing_linkage.insert_one(query)
                elif not linkage['active']:
                    db.idea_data_sharing_linkage.update_one(query,{"$set": {"active": True}})
        
        # Assigning shares to full accounts
        for share in data['shares']:
            for full_account in data['full_accounts']:
                try:
                    cursor.execute(snowflake.data_sharing["assign_share"].format(share=share, consumer=full_account))
                    query = {"share_name": share,"full_account": full_account,"link_service_id": data['link_service_id']}
                    linkage = db.idea_data_sharing_linkage.find_one(query)
                    if not bool(linkage):
                        query['active'] = True
                        db.idea_data_sharing_linkage.insert_one(query)
                    elif not linkage['active']:
                        db.idea_data_sharing_linkage.update_one(query,{"$set": {"active": True}})
                except Exception as e_error:
                    log.error(e_error)
                    full_account_error = error.err_054.copy()
                    full_account_error['message'] = full_account_error['message'].format(full_account=full_account)
                    return response(dumps(full_account_error), 409)
                
        conn.close()

    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)
    
    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Shares assigned to consumers successfully",
          "data": ""}), 200


@app.route("/idea/services/migrationsf/datasharing/revoke-shares", methods=["POST"])
@validate_json_schema
def datasharing_revoke_shares():
    """
    data sharing revoke shares
    """

    log.info("START")
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["data_sharing"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # # Validate Json Schema and Data
        # if not validate_json_schema(sys._getframe().f_code.co_name, data):
        #     return response(dumps(error.err_074), 400)

        # Input validation
        if data['readers'] == [] and data['full_accounts'] == []:
            return response(dumps(error.err_074), 400)

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Reader validation
        readers = list(db.idea_data_sharing_readers.find({"link_service_id": data['link_service_id'],
                                                    "active": True},{"_id": 0, "reader_name": 1}))
        if not bool(readers):
            return response(dumps(error.err_088), 404)
        for reader in data['readers']:
            if reader not in [reader['reader_name'] for reader in readers]:
                return response(dumps(error.err_088), 404)

        # Share validation
        shares = list(db.idea_data_sharing_shares.find({"link_service_id": data['link_service_id'],
                                                    "active": True}, {"_id": 0, "share_name": 1}))
        if not bool(shares):
            return response(dumps(error.err_088), 404)
        for share in data['shares']:
            if share not in [share['share_name'] for share in shares]:
                return response(dumps(error.err_088), 404)

        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True,
                            "link_service_type":snowflake_dwh}, {"_id":0, "db_hostname":1, "db_user": 1})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Connecting snowflake instance
        password = get_secret(data["link_service_id"] + "-password")
        sf_conn_string = config["snowflake"]["conn"].format(hostname=link_service['db_hostname'],
                                                            uid=link_service['db_user'],
                                                            pwd=password, warehouse="COMPUTE_WH")
        conn = pyodbc.connect(sf_conn_string)

        # Revoking shares from readers
        cursor = conn.cursor()
        for share in data['shares']:
            for reader in data['readers']:
                locator = db.idea_data_sharing_readers.find_one({"reader_name": reader, "active": True,
                                                                "link_service_id": data['link_service_id']},
                                                                {"_id": 0, "locator": 1})['locator']
                cursor.execute(snowflake.data_sharing["revoke_share"].format(share=share, consumer=locator))
                query = {"share_name": share,"reader_locator": locator,"link_service_id": data['link_service_id'],"active": True}
                linkage = db.idea_data_sharing_linkage.find_one(query)
                if bool(linkage):
                    db.idea_data_sharing_linkage.update_one(query,{"$set": {"active": False}})

        # Revoking shares from full accounts
        cursor = conn.cursor()
        for share in data['shares']:
            for full_account in data['full_accounts']:
                cursor.execute(snowflake.data_sharing["revoke_share"].format(share=share, consumer=full_account))
                query = {"share_name": share,"full_account": full_account,"link_service_id": data['link_service_id'],"active": True}
                linkage = db.idea_data_sharing_linkage.find_one(query)
                if bool(linkage):
                    db.idea_data_sharing_linkage.update_one(query,{"$set": {"active": False}})
                    
        conn.close()

    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)
    
    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Shares revoked from consumers successfully",
          "data": ""}), 200


@app.route("/idea/services/migrationsf/datasharing/drop-share", methods=["POST"])
@validate_json_schema
def datasharing_drop_share():
    """
    data sharing drop share
    """

    log.info("START")
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["data_sharing"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # # Validate Json Schema and Data
        # if not validate_json_schema(sys._getframe().f_code.co_name, data):
        #     return response(dumps(error.err_074), 400)

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Share validation
        share = db.idea_data_sharing_shares.find_one({"link_service_id": data['link_service_id'],
                                            "active": True, "share_name": data['share_name']}, {})
        if not bool(share):
            return response(dumps(error.err_088), 404)

        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True,
                            "link_service_type":snowflake_dwh}, {"_id":0, "db_hostname":1, "db_user": 1})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Connecting snowflake instance
        password = get_secret(data["link_service_id"] + "-password")
        sf_conn_string = config["snowflake"]["conn"].format(hostname=link_service['db_hostname'],
                                                            uid=link_service['db_user'],
                                                            pwd=password, warehouse="COMPUTE_WH")
        conn = pyodbc.connect(sf_conn_string)

        # Dropping share
        cursor = conn.cursor()
        cursor.execute(snowflake.data_sharing["drop_share"].format(share=data['share_name']))

        # Updating IDEA metadata
        db.idea_data_sharing_shares.update_one({"share_name": data['share_name'], "active": True,
                                                            "link_service_id": data["link_service_id"]},
                                                            {"$set": {"active": False}})
        db.idea_data_sharing_linkage.update_many({"link_service_id": data['link_service_id'],
                                                    "share_name": data['share_name'], "active": True},
                                                    {"$set": {"active": False}})
        conn.close()
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)
    
    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": share_exists + data['share_name'] + " dropped successfully",
          "data": ""}), 200


@app.route("/idea/services/migrationsf/datasharing/drop-reader", methods=["POST"])
@validate_json_schema
def datasharing_drop_reader():
    """
    data sharing drop reader
    """

    log.info("START")
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["data_sharing"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # # Validate Json Schema and Data
        # if not validate_json_schema(sys._getframe().f_code.co_name, data):
        #     return response(dumps(error.err_074), 400)

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Reader validation
        reader = db.idea_data_sharing_readers.find_one({"link_service_id": data['link_service_id'],
                                            "active": True, "reader_name": data['reader_name']}, {})
        if not bool(reader):
            return response(dumps(error.err_088), 404)

        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True,
                            "link_service_type":snowflake_dwh}, {"_id":0, "db_hostname":1, "db_user": 1})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Connecting snowflake instance
        password = get_secret(data["link_service_id"] + "-password")
        sf_conn_string = config["snowflake"]["conn"].format(hostname=link_service['db_hostname'],
                                                            uid=link_service['db_user'],
                                                            pwd=password, warehouse="COMPUTE_WH")
        conn = pyodbc.connect(sf_conn_string)

        # Dropping reader
        cursor = conn.cursor()
        cursor.execute(snowflake.data_sharing["drop_reader"].format(reader=data['reader_name']))

        # Updating IDEA metadata
        locator = db.idea_data_sharing_readers.find_one({"link_service_id": data['link_service_id'],
                                                        "reader_name": data['reader_name'], "active": True},
                                                        {"_id": 0,"locator": 1})['locator']
        db.idea_data_sharing_readers.update_one({"reader_name": data['reader_name'], "active": True,
                                                "link_service_id": data['link_service_id']},
                                                {"$set": {"active": False}})
        db.idea_data_sharing_linkage.update_many({"link_service_id": data['link_service_id'],
                                                    "reader_locator": locator, "active": True},
                                                    {"$set": {"active": False}})
        conn.close()
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)
    
    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Reader " + data['reader_name'] + " dropped successfully",
          "data": ""}), 200