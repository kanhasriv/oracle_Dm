"""
This service populates discovery tables
"""
import logging
from datetime import datetime
import traceback
from kafka import KafkaProducer
from bson.json_util import dumps
from config import config

log = logging.getLogger(config["logging"]["name"])


def format_json(json):
    data = []
    max_len = -999
    for item in json.keys():
        if max_len < len(json[item]):
            max_len = len(json[item])

    for index in range(0, max_len):
        temp_data = {}
        for item in json.keys():
            try:
                temp_data[item] = json[item][str(index)]
            except Exception as e_error:
                log.error(e_error)
                return False
        data.append(temp_data)

    return data


def abcr_job_run(configuration, end, execution_log, job_register_id, job_run_id, job_name, job_description, output,
                 run_by, start,
                 job_status, job_type, batch_run_id):
    status = "Fail"
    try:
        job_run_topic = config["kafka"]["topic_job_run"]
        abcr_json = {
            'runBy': run_by,
            'status': job_status,
            'type': job_type,
            'category': config['ABCR']['category'],
            'config': configuration,
            'executionLog': execution_log,
            'jobRegisterID': job_register_id,
            'jobRunID': job_run_id,
            'jobName': job_name,
            'jobDescription': job_description,
            'start': datetime.fromtimestamp(start).strftime('%Y/%m/%d %H:%M:%S'),
            'startTimestamp': start

        }
        if job_status == "Success" or job_status == "Fail":
            if end != "":
                abcr_json['end'] = datetime.fromtimestamp(end).strftime('%Y/%m/%d %H:%M:%S')
            abcr_json['endTimestamp'] = end
            abcr_json['output'] = output
        if job_type == "discover":
            abcr_json['batchRunId'] = batch_run_id
        producer = KafkaProducer(bootstrap_servers=[config["kafka"]["host"]],
                                 value_serializer=lambda x: dumps(x).encode('utf-8'))
        producer.send(job_run_topic, value=abcr_json)
        status = "Success"
        message = job_run_id + " Produced Successfully on job run topic"
    except Exception as e_error:
        log.error(e_error)
        message = "Error while producing " + job_run_id + " on job run topic"
        log.info("status: {}, message: {}".format(status, message))
        return status
    log.info("status: {}, message: {}".format(status, message))
    return status
