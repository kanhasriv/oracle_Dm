"""
This service  run consumer for TD to BLOB
"""
import logging.handlers
import json
from datetime import datetime
import time
import _thread
from kafka import KafkaConsumer
from config import config
from libs.data_util import td_s3_migration

# Log
log = logging.getLogger(config["logging"]["name"])
log.setLevel(int(config["logging"]["logging_level"]))
handler = logging.handlers.RotatingFileHandler(
            config["logging"]["filename"],
            maxBytes =int(config["logging"]["logging_maxBytes"]),
            backupCount = int(config["logging"]["logging_backup_count"]))

# Set the log format
handler.setFormatter(
        logging.Formatter("%(asctime)s|%(levelname)-5.5s|[%(filename)s:%(lineno)s-%(funcName)20s()]|%(message)s"))
log.addHandler(handler)

# set consumer for TD to S3
topic = config["kafka"]["topic_sr_s3"]
server = config["kafka"]["host"]
consumer_td_blob = KafkaConsumer(topic, bootstrap_servers=[server])

log.info("Snowflake Data Migration to S3 Service initialized Successfully")

for message in consumer_td_blob:
    time.sleep(5)
    message = message.value
    data = json.loads(message)
    base_timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
    _thread.start_new_thread(td_s3_migration, (data,base_timestamp))
