"""
This file has all supportive functions for data migration
"""

import logging
import traceback
from datetime import datetime
import time
import pyodbc
import ftplib
from kafka import KafkaProducer
from bson.json_util import dumps
from config import (config, db, glue_client, send_message, update_dashboard)
from libs import snowflake
from libs.secret_manager import get_secret

log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'
fail_dict = {"status_s3": "Fail",
             "start_time_s3": int(datetime.utcnow().timestamp()),
             "end_time_s3_str": str(
                 datetime.now().strftime(idea_date_format)),
             "copy_s3": None, "file_name": None,
             "status_sf": "Fail",
             "noofrows_read_sf": 0,
             "noofrows_skipped_sf": 0,
             "noofrows_written_sf": 0,
             }

log_url_aws = "https://console.aws.amazon.com/gluestudio/home?region={region}#/job/{jobName}/run/{jobRunId}"

class TooManyLines(Exception):
    pass

def extract_query(table_name, schema_name, source_link_service_id, job_run_id, project_id,
                  split, column_name, split_from, split_to,load_type,split_id):
    """
    Get the name of all columns  in given table
    :param table_name,schema_name,source_link_service_id,job_run_id,param column_name,load_type,
     check_max_value,project_id
    :return: TD_Query
    """
    log.info("START")
    try:
        batch_id = \
            list(db.job_run.find(
                {"link_service_id": source_link_service_id, "project_id": project_id,
                 "status": "Success"}, {'_id': 0, 'batch_id': 1}).sort(
                [("start_time", -1)]).limit(1))[0]['batch_id']
        log.debug("batch_id {}".format(batch_id))
        data = db.idea_column_discovery_attr.find(
            {"table_nm": table_name.strip(), "database_vendor": "TERADATA",
             "database_nm": schema_name.strip(), "batch_id": batch_id},
            {"column_nm": 1, "_id": 0})
        param = []
        data = list(data)
        if len(data) > 1:
            log.debug("data {}".format(data))
            for item in data:
                item = item['column_nm']
                param.append(item)
            # Check for Split
            if split or load_type.upper() == "ADHOC":
                query = f"SELECT {param} FROM {schema_name}.{table_name} where {column_name} >= #{split_from}# and {column_name} <= #{split_to}#"
            elif load_type.upper() == "INCREMENTAL LOAD" and not split and split_from != "0":
                query = f"SELECT {param} FROM {schema_name}.{table_name} where {column_name} >= #{split_from}#"
            else:
                query = f"SELECT {param} FROM {schema_name}.{table_name}"

            query = query.replace("'", "\"")
            query = query.replace("[", "")
            query = query.replace("]", "")
            query = query.replace("#", "'")
        else:
            return False


    except Exception:
        log.error(traceback.format_exc())
        if split:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            array_filters = [{"stat.split_id": split_id}]
            newvalues = {"$set": {"splits.$[stat].split_status_s3": "Fail",
                                  "splits.$[stat].split_status_sf": "Fail",
                                  "splits.$[stat].noofrows_read_sf": 0,
                                  "splits.$[stat].noofrows_written_sf": 0,
                                  "splits.$[stat].noofrows_skipped_sf": 0,
                                  "splits.$[stat].end_time_s3": int(datetime.utcnow().timestamp()),
                                  "splits.$[stat].copy_s3": None,
                                  "splits.$[stat].message": "Teradata DWH to s3 migration failed"}}
            db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                         array_filters)
        else:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            fail_dict.update({"message": "Discovery not performed. Please perform discovery"})
            db.job_run_detail.update_one(updatequery, {"$set": fail_dict})
        return False

    log.info("END")
    return query


def schema_validation(table_name, source_link_service_id, load_type, schema_name, job_run_id,
                      project_id):
    """
    Validates the schema of FTP file with our metadata
    :param table_name,schema_name,source_link_service_id,load_type,job_run_id,project_id:
    :return: Boolean
    """
    log.info("START")
    try:
        link_service_id = source_link_service_id
        query = {"link_service_id": link_service_id, "active": True}
        log.info("db.link_service.find(): query: {}".format(query))
        link_service_data = db.link_service.find(query, {"_id": 0})
        link_service_data = list(link_service_data)[0]
        batch_id = \
            list(db.job_run.find(
                {"link_service_id": source_link_service_id, "project_id": project_id,
                 "status": "Success"}, {'_id': 0, 'batch_id': 1}).sort(
                [("start_time", -1)]).limit(1))[0]['batch_id']
        log.debug("link_service_data {}".format(link_service_data))
        hostname = link_service_data["db_hostname"]
        username = get_secret(source_link_service_id + "-username")
        password = get_secret(source_link_service_id + "-password")
        shared_path = link_service_data["shared_path"]
        try:
            ftp = ftplib.FTP()
            ftp.connect(hostname, int(link_service_data["port"]))
            ftp.login(username, password)
            log.debug("Connection Established to FTP Server")
            #ftp.set_pasv(False)
            ftp.encoding = "utf-8"
        except Exception:
            log.error(traceback.format_exc())
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            fail_dict.update({"message": "Not able to establish connection to FTP Server during "
                                         "schema_validation "})
            db.job_run_detail.update_one(updatequery, {"$set": fail_dict})
            return
        content = []
        line_no = []

        def collectLines(s):
            content.append(s.split("¬"))
            line_no.append(1)
            if len(line_no) == 5:
                raise TooManyLines()

        data = db.idea_column_discovery_attr.find(
            {"table_nm": table_name, "database_vendor": "TERADATA",
             "database_nm": schema_name, "batch_id": batch_id},
            {"column_nm": 1, "_id": 0}).sort([("column_seq", 1)])
        param = []
        data = list(data)
        log.debug("data {}".format(data))
        if len(data) > 1:
            for item in data:
                item = item['column_nm']
                param.append(item)
        if load_type.upper() == "FULL LOAD":
            ftp_path = "/" + shared_path + "/" + config['ftp']['fullload']
        elif load_type.upper() == "INCREMENTAL LOAD":
            ftp_path = "/" + shared_path + "/" + config['ftp']['incremental']
        try:
            ftp.cwd(ftp_path)
            log.debug("before reading file")
            ftp.retrlines("RETR {schema_name}.{table_name}.txt".format(table_name=table_name,
                                                                       schema_name=schema_name),
                          callback=collectLines)
            log.debug("Read the file")
        except TooManyLines:
            ftp.getmultiline()
        except Exception:
            log.error(traceback.format_exc())
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            fail_dict.update({"message": "Either File does not exist or it is in Invalid Format "})
            db.job_run_detail.update_one(updatequery, {"$set": fail_dict})
            return
        log.info(content)
        columns = content[0][0]
        columns = str(columns).split(',')
        ftp.quit()
        log.debug("param {}".format(param))
        if len(param) == len(columns):
            for item in range(len(columns)):
                if columns[item].strip() != param[item].strip():
                #if item not in param:
                    log.debug("Column mismatch")
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    fail_dict.update({"message": "Column mismatch"})
                    db.job_run_detail.update_one(updatequery, {"$set": fail_dict})
                    return False
        else:
            log.debug("Number of Columns in FTP file is different from that of discovered metadata")
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            fail_dict.update({
                                 "message": "Number of Columns in FTP file is different from that of discovered metadata"})
            db.job_run_detail.update_one(updatequery, {"$set": fail_dict})
            return False
    except Exception:
        log.error(traceback.format_exc())
        updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                       "object_parent": schema_name}
        fail_dict.update({"message": "Teradata FTP to S3 migration failed"})
        db.job_run_detail.update_one(updatequery, {"$set": fail_dict})
        return False

    log.info("END")
    return True


def td_to_s3(table_name, job_run_id, split_id, schema_name, load_type,
             base_timestamp, split, split_from, split_to, column_name,
             source_link_service_id, project_id, service, user_id, socket_flag, pipeline_id,
             pipeline_run_id):
    """
    Executes tdtos3 glue job and migrates data from teradata to s3
    """
    try:
        result = db.link_service.find_one({"link_service_id": source_link_service_id,
                                           "active": True})
        hostname = result["db_hostname"]


        # Fetching details to start glue job
        glue_job_name = config['aws']['glue_job_name_td']

        # Fetching list of columns in the table
        query = extract_query(table_name, schema_name, source_link_service_id, job_run_id,
                              project_id, split, column_name, split_from, split_to, load_type,
                              split_id)

        if not query:
            if split:
                updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                               "object_parent": schema_name}
                array_filters = [{"stat.split_id": split_id}]
                newvalues = {"$set": {"splits.$[stat].split_status_s3": "Fail",
                                      "splits.$[stat].split_status_sf": "Fail",
                                      "splits.$[stat].end_time_s3": int(
                                          datetime.utcnow().timestamp()),
                                      "splits.$[stat].copy_s3": None,
                                      "splits.$[stat].noofrows_read_sf": 0,
                                      "splits.$[stat].noofrows_written_sf": 0,
                                      "splits.$[stat].noofrows_skipped_sf": 0,
                                      "splits.$[stat].message": "Please perform discovery first"}}
                db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                             array_filters)
            else:
                updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                               "object_parent": schema_name}
                fail_dict.update({"message": "Please perform discovery first"})
                db.job_run_detail.update_one(updatequery, {"$set": fail_dict})
            log.error(traceback.format_exc())
            return False, ''


        # Starting the Glue Job
        resp = glue_client.start_job_run(JobName=glue_job_name, Arguments={
            "--db_name": schema_name,
            "--tb_name": table_name,
            "--td_hostname": hostname,
            "--link_service_id": source_link_service_id,
            "--region_name": config['aws']['region_name'],
            "--bucket_name": config["aws"]["bucket_name"],
            "--td_driver_name": config["aws"]["td_driver_name"],
            "--date": base_timestamp[:8],
            "--time": base_timestamp[8:],
            "--query": query
        })
        log.info(resp['JobRunId'])
        glue_run_id = resp['JobRunId']

        # Monitoring the glue job and updating the status
        if split:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            array_filters = [{"stat.split_id": split_id}]
            newvalues = {"$set": {"splits.$[stat].split_status_s3": "InProgress"}}
            db.job_run_detail.update_one(updatequery, newvalues, False, False, None, array_filters)
        else:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            newvalues = {"$set": {"status_s3": "InProgress"}}
            db.job_run_detail.update_one(updatequery, newvalues)
        flag = True
        while flag:
            # Checking after every 60 seconds
            time.sleep(5)
            resp = glue_client.get_job_run(JobName=glue_job_name,
                                           RunId=glue_run_id)
            job_status = resp['JobRun']['JobRunState']
            if job_status not in ('STARTING', 'RUNNING', 'STOPPING'):
                flag = False
        
        # Making the glue job log URL
        log_region = config['aws']['region_name']
        aws_log_url = log_url_aws.format(jobRunId=glue_run_id, jobName=glue_job_name,
                                         region=log_region)

        # Updating job metrics in job_run_table
        if job_status == "SUCCEEDED":

            if socket_flag:
                dashboard_data = {
                    table_name: {"database": schema_name, "status": "InProgress", "rows": 0,
                                 "s3_duration": resp['JobRun']['ExecutionTime'], "sf_duration": 0,
                                 "mode": load_type, "service": service, "avg_duration": 0},
                    "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
                if split:
                    dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id,
                                                                                  table_name,
                                                                                  schema_name)
                    dashboard_data[table_name]['rows'] = dashboard_rows
                    dashboard_data[table_name]['s3_duration'] = dashboard_s3
                    dashboard_data[table_name]['sf_duration'] = dashboard_sf
                    dashboard_data[table_name]['avg_duration'] = round(
                        (dashboard_s3 + dashboard_sf) / 2, 2)
                send_message("sf_data_run_status", dashboard_data, user_id)
            if split:
                updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                               "object_parent": schema_name}
                array_filters = [{"stat.split_id": split_id}]
                newvalues = {"$set": {"splits.$[stat].glue_job_run_id_s3": glue_run_id,
                                      "splits.$[stat].split_status_s3": "Success",
                                      "splits.$[stat].start_time_s3": str(
                                          resp['JobRun']['StartedOn']),
                                      "splits.$[stat].end_time_s3": str(
                                          resp['JobRun']['CompletedOn']),
                                      "splits.$[stat].copy_s3": resp['JobRun']['ExecutionTime'],
                                      "splits.$[stat].message": "Teradata to S3 Migration is Successfull",
                                      "splits.$[stat].file_name": base_timestamp,
                                      "splits.$[stat].aws_log_url_s3":aws_log_url}}
                db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                             array_filters)
            else:
                updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                               "object_parent": schema_name}
                newvalues = {"$set": {"glue_job_run_id_s3": glue_run_id,
                                      "status_s3": "Success",
                                      "start_time_s3": str(resp['JobRun']['StartedOn']),
                                      "end_time_s3": str(resp['JobRun']['CompletedOn']),
                                      "copy_s3": resp['JobRun']['ExecutionTime'],
                                      "message": "Teradata to S3 Migration is Successfull",
                                      "file_name": base_timestamp,
                                      "aws_log_url_s3":aws_log_url}}
                db.job_run_detail.update_one(updatequery, newvalues)
        elif job_status == "FAILED" or job_status == 'STOPPED':
            if socket_flag:
                dashboard_data = {table_name: {"database": schema_name, "status": "Fail", "rows": 0,
                                               "s3_duration": 0, "sf_duration": 0,
                                               "mode": load_type, "service": service,
                                               "avg_duration": 0}, "pipeline_id": pipeline_id,
                                  "pipeline_run_id": pipeline_run_id}
                if split:
                    dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id,
                                                                                  table_name,
                                                                                  schema_name)
                    dashboard_data[table_name]['status'] = "InProgress"
                    dashboard_data[table_name]['rows'] = dashboard_rows
                    dashboard_data[table_name]['s3_duration'] = dashboard_s3
                    dashboard_data[table_name]['sf_duration'] = dashboard_sf
                    dashboard_data[table_name]['avg_duration'] = round(
                        (dashboard_s3 + dashboard_sf) / 2, 2)
                send_message("sf_data_run_status", dashboard_data, user_id)
            if job_status == 'STOPPED':
                message = "TD to S3 glue job has been stopped"
            else:
                message = resp['JobRun']['ErrorMessage']
            if split:
                updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                               "object_parent": schema_name}
                array_filters = [{"stat.split_id": split_id}]
                newvalues = {"$set": {"splits.$[stat].glue_job_run_id_s3": glue_run_id,
                                      "splits.$[stat].split_status_s3": "Fail",
                                      "splits.$[stat].split_status_sf": "Fail",
                                      "splits.$[stat].start_time_s3": str(
                                          resp['JobRun']['StartedOn']),
                                      "splits.$[stat].end_time_s3": str(
                                          resp['JobRun']['CompletedOn']),
                                      "splits.$[stat].copy_s3": resp['JobRun']['ExecutionTime'],
                                      "splits.$[stat].message": message,
                                      "splits.$[stat].file_name": None,
                                      "splits.$[stat].noofrows_read_sf": 0,
                                      "splits.$[stat].noofrows_written_sf": 0,
                                      "splits.$[stat].noofrows_skipped_sf": 0,
                                      "splits.$[stat].aws_log_url_s3": aws_log_url}}
                db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                             array_filters)
            else:
                updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                               "object_parent": schema_name}
                newvalues = {"$set": {"glue_job_run_id_s3": glue_run_id,
                                      "status_s3": "Fail", "status_sf": "Fail",
                                      "start_time_s3": str(resp['JobRun']['StartedOn']),
                                      "end_time_s3": str(resp['JobRun']['CompletedOn']),
                                      "copy_s3": resp['JobRun']['ExecutionTime'],
                                      "message": message,
                                      "file_name": None,
                                      "aws_log_url_s3": aws_log_url,
                                      "noofrows_read_sf": 0,
                                      "noofrows_skipped_sf": 0,
                                      "noofrows_written_sf": 0,
                                      }}
                db.job_run_detail.update_one(updatequery, newvalues)
            return False, ''


    except Exception:
        if socket_flag:
            dashboard_data = {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":0,"sf_duration":0,"mode":load_type,"service":service,"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
            if split:
                dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id, table_name, schema_name)
                dashboard_data[table_name]['status'] = "InProgress"
                dashboard_data[table_name]['rows'] = dashboard_rows
                dashboard_data[table_name]['s3_duration'] = dashboard_s3
                dashboard_data[table_name]['sf_duration'] = dashboard_sf
                dashboard_data[table_name]['avg_duration'] = round((dashboard_s3+dashboard_sf)/2,2)
            send_message("sf_data_run_status", dashboard_data, user_id)
        if split:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            array_filters = [{"stat.split_id": split_id}]
            newvalues = {"$set": {"splits.$[stat].split_status_s3": "Fail",
                                  "splits.$[stat].split_status_sf": "Fail",
                                  "splits.$[stat].end_time_s3": int(datetime.utcnow().timestamp()),
                                  "splits.$[stat].copy_s3": None,
                                  "splits.$[stat].noofrows_read_sf": 0,
                                  "splits.$[stat].noofrows_written_sf": 0,
                                  "splits.$[stat].noofrows_skipped_sf": 0,
                                  "splits.$[stat].message": "Teradata DWH to s3 migration failed"}}
            db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                         array_filters)
        else:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            fail_dict.update({"message": "Teradata DWH to s3 migration failed"})
            db.job_run_detail.update_one(updatequery, {"$set": fail_dict})
        log.error(traceback.format_exc())
        return False, ''

    log.info("END")
    return base_timestamp, resp['JobRun']['ExecutionTime']


def td_to_s3_ftp(table_name, job_run_id, schema_name, load_type, base_timestamp,
                 source_link_service_id, project_id, service, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
        Executes FTPtos3 glue job and migrates data from teradata to s3
    """
    try:
        result = db.link_service.find_one({"link_service_id": source_link_service_id,
                                           "active": True})
        hostname = result["db_hostname"]
        shared_path = result["shared_path"]
        port = result["port"]

        # Validating Schema
        flag = schema_validation(table_name, source_link_service_id, load_type, schema_name,
                                 job_run_id, project_id)
        if not flag:
            return False, ''

        # Fetching details to start glue job
        glue_job_name = config['aws']['glue_job_name_FTP']
        if load_type.upper() == "FULL LOAD":
            load_type_path = config['ftp']['fullload']
        elif load_type.upper() == "INCREMENTAL LOAD":
            load_type_path = config['ftp']['incremental']

        # Starting the Glue Job
        resp = glue_client.start_job_run(JobName=glue_job_name, Arguments={
            "--db_name": schema_name,
            "--tb_name": table_name,
            "--ftp_hostname": hostname,
            "--ftp_port": str(port),
            "--link_service_id": source_link_service_id,
            "--region_name": config['aws']['region_name'],
            "--ftp_path": shared_path,
            "--load_type": load_type_path,
            "--bucket_name": config["aws"]["bucket_name"],
            "--date": base_timestamp[:8],
            "--time":base_timestamp[8:]
        })

        log.info(resp['JobRunId'])
        glue_run_id = resp['JobRunId']

        # Monitoring the glue job and updating the status
        updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                       "object_parent": schema_name}
        newvalues = {"$set": {"status_s3": "InProgress"}}
        db.job_run_detail.update_one(updatequery, newvalues)
        flag = True
        while flag:
            # Checking after every 60 seconds
            time.sleep(5)
            resp = glue_client.get_job_run(JobName=glue_job_name,
                                           RunId=glue_run_id)
            job_status = resp['JobRun']['JobRunState']
            if job_status not in ('STARTING', 'RUNNING', 'STOPPING'):
                flag = False
        
        # Making the glue job log URL
        log_region = config['aws']['region_name']
        aws_log_url = log_url_aws.format(jobRunId = glue_run_id, jobName = glue_job_name, region = log_region)

        # Updating job metrics in job_run_table
        if job_status == "SUCCEEDED":
            if socket_flag:
                dashboard_data = {table_name:{"database":schema_name,"status": "InProgress","rows":0,"s3_duration":resp['JobRun']['ExecutionTime'],"sf_duration":0,"mode":load_type,"service":service,"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
                send_message("sf_data_run_status", dashboard_data, user_id)
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            newvalues = {"$set": {"glue_job_run_id_s3": glue_run_id,
                                  "status_s3": "Success",
                                  "start_time_s3": str(resp['JobRun']['StartedOn']),
                                  "end_time_s3": str(resp['JobRun']['CompletedOn']),
                                  "copy_s3": resp['JobRun']['ExecutionTime'],
                                  "message": "Teradata to S3 Migration is Successfull",
                                  "file_name": base_timestamp,
                                  "aws_log_url_s3": aws_log_url}}
            db.job_run_detail.update_one(updatequery, newvalues)
        elif job_status == "FAILED" or job_status == 'STOPPED':
            if socket_flag:
                dashboard_data = {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":0,"sf_duration":0,"mode":load_type,"service":service,"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
                send_message("sf_data_run_status", dashboard_data, user_id)
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            if job_status == 'STOPPED':
                message = "TD to S3 glue job has been stopped"
            else:
                message = resp['JobRun']['ErrorMessage']
            newvalues = {"$set": {"glue_job_run_id_s3": glue_run_id,
                                  "status_s3": "Fail", "status_sf": "Fail",
                                  "start_time_s3": str(resp['JobRun']['StartedOn']),
                                  "end_time_s3": str(resp['JobRun']['CompletedOn']),
                                  "copy_s3": resp['JobRun']['ExecutionTime'],
                                  "message": message,
                                  "noofrows_read_sf": 0,
                                  "noofrows_skipped_sf": 0,
                                  "noofrows_written_sf": 0,
                                  "file_name": None,
                                  "aws_log_url_s3": aws_log_url}}
            db.job_run_detail.update_one(updatequery, newvalues)
            return False, ''


    except Exception:
        if socket_flag:
            dashboard_data = {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":0,"sf_duration":0,"mode":load_type,"service":service}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
            send_message("sf_data_run_status", dashboard_data, user_id)
        updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                       "object_parent": schema_name}
        newvalues = {
            "$set": {"status_s3": "Fail", "status_sf": "Fail",
                     "message": "Teradata FTP to s3 migration failed",
                     "end_time_s3": int(datetime.utcnow().timestamp()),
                     "copy_duration_s3": None,
                     "file_name": None
                     }}
        db.job_run_detail.update_one(updatequery, newvalues)
        log.error(traceback.format_exc())
        return False, ''

    log.info("END")
    return base_timestamp, resp['JobRun']['ExecutionTime']


def td_s3_migration(data, base_timestamp):
    """ This consumer read a message in json and execute
        TD to S3 data migration and produce data to sf-dm-blob-snowflake topic
    """
    log.info("START")
    try:
        # Reading required values from Kafka data
        job_id = data['job_id']
        table_name = data['table_name']
        job_run_id = data['job_run_id']
        start_time = data['start']
        load_type = data['load_type']
        schema_name = data['schema_name']
        server = config["kafka"]["host"]
        topic = config["kafka"]["topic_s3_sf"]
        user_id = data['user_id']
        socket_flag = data['socket_flag']
        pipeline_id = data['pipeline_id']
        pipeline_run_id = data['pipeline_run_id']
        service = db.job_registry.find_one({"job_id":job_id})
        if bool(service):
            service = service['data_migration_option']
        else:
            service = ""
        producer = KafkaProducer(bootstrap_servers=server,
                                 value_serializer=lambda x: dumps(x).encode('utf-8'))

        # Checking if the message is data_end
        if data["index"] == "split_end":
            data_end = {
                "job_id": job_id,
                "job_run_id": job_run_id,
                "start": start_time,
                "table_name": table_name,
                "run_by": data["run_by"],
                "index": "split_end",
                "load_type": load_type,
                "schema_name": schema_name,
                "user_id": user_id,
                "socket_flag": socket_flag,
                "pipeline_id": pipeline_id,
                "pipeline_run_id": pipeline_run_id
            }
            producer.send(topic, value=data_end)

        # Checking if the message is split_end
        elif data["index"] == "job_end":
            split_end = {
                "job_id": job_id,
                "job_run_id": job_run_id,
                "start": start_time,
                "run_by": data["run_by"],
                "table_name": table_name,
                "index": "job_end",
                "load_type": load_type,
                "schema_name": None,
                "user_id": user_id,
                "socket_flag": socket_flag,
                "pipeline_id": pipeline_id,
                "pipeline_run_id": pipeline_run_id
            }
            producer.send(topic, value=split_end)

        # Starting the glue job if the message is not data_end
        else:
            sink_link_service_id = data['sink_link_service_id']
            split = data['split']
            split_id = data['split_id']
            # Checking if the schema exists in the target
            query = {"link_service_id": sink_link_service_id, "active": True}
            result = db.link_service.find_one(query, {"_id": 0})
            tgt_host_name = result["db_hostname"]
            tgt_user_name = get_secret(sink_link_service_id + "-username")

            # Decrypt the password
            tgt_syn_password = get_secret(sink_link_service_id + "-password")
            warehouse_name = config['snowflake']['warehouse']
            sf_conn_string = config["snowflake"]["conn"].format(hostname=tgt_host_name,
                                                                uid=tgt_user_name,
                                                                pwd=tgt_syn_password,
                                                                warehouse=warehouse_name)
            conn = pyodbc.connect(sf_conn_string)
            cur = conn.cursor()
            database_name = config['snowflake']['idea_database_snowflake']
            pre_copy_script = snowflake.query["check_schema_query"].format(
                database_name=database_name.upper(),
                schema_name=schema_name.upper(),
                table_name=table_name.upper())
            try:
                cur.execute(pre_copy_script)
                cur.commit()
            except Exception as e:
                if socket_flag:
                    dashboard_data = {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":0,"sf_duration":0,"mode":load_type,"service":service,"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
                    if split:
                        dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id, table_name, schema_name)
                        dashboard_data[table_name]['status'] = "InProgress"
                        dashboard_data[table_name]['rows'] = dashboard_rows
                        dashboard_data[table_name]['s3_duration'] = dashboard_s3
                        dashboard_data[table_name]['sf_duration'] = dashboard_sf
                        dashboard_data[table_name]['avg_duration'] = round((dashboard_s3+dashboard_sf)/2,2)
                    send_message("sf_data_run_status", dashboard_data, user_id)
                message = "Schema not yet migrated."
                if split and data["index"] == "middle":
                    log.info("split not start")
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    array_filters = [{"stat.split_id": split_id}]
                    newvalues = {"$set": {"splits.$[stat].split_status_s3": "Fail",
                                          "splits.$[stat].split_status_sf": "Fail",
                                          "splits.$[stat].noofrows_read_sf": 0,
                                          "splits.$[stat].noofrows_written_sf": 0,
                                          "splits.$[stat].noofrows_skipped_sf": 0,
                                          "splits.$[stat].end_time_s3": int(
                                              datetime.utcnow().timestamp()),
                                          "splits.$[stat].copy_s3": None,
                                          "splits.$[stat].message": message,
                                          "splits.$[stat].file_name": None}}
                    db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                                 array_filters)
                else:
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
                    fail_dict.update({"message": message})
                    db.job_run_detail.update_one(updatequery, {"$set": fail_dict})
                log.error(traceback.format_exc())
                return False
            log.debug("Given table {} schema exists".format(table_name))
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            newvalues = {"$set": {"status_s3": "InProgress"}}

            # Truncating the table in case of Full Load and in start message
            if data["index"] == "start":
                if load_type.upper() == "FULL LOAD" :
                    pre_copy_script = snowflake.query["pre_copy_script"].format(
                        database_name=database_name.upper(),
                        schema_name=schema_name.upper(),
                        table_name=table_name.upper())
                    cur.execute(pre_copy_script)
                    cur.commit()
                    log.info("Truncate Successfull")
                log.info("Start message ended")
                return
            
            conn.close()
            start_time_str = data['start_time_str']
            db.job_run_detail.update_one(updatequery, newvalues)
            project_id = data['project_id']
            source_link_service_id = data['source_link_service_id']
            link_query = {"link_service_id": source_link_service_id, "active": True}
            source_link_service_type = db.link_service.find_one(link_query,
                                                                {"link_service_type": 1, "_id": 0})
            source_link_service_type = source_link_service_type['link_service_type']

            file_name = False

         # Starting the job if the schema is preset
            if source_link_service_type.upper() == "TERADATA FTP":
                file_name, s3_duration = td_to_s3_ftp(table_name, job_run_id, schema_name, load_type,
                                         base_timestamp, source_link_service_id, project_id, service, user_id, socket_flag, pipeline_id, pipeline_run_id)
            elif source_link_service_type.upper() == "TERADATA DWH":
                split_from = data['split_from']
                split_to = data['split_to']
                column_name = data["column_name"]
                file_name, s3_duration = td_to_s3(table_name, job_run_id, split_id, schema_name, load_type,
                                     base_timestamp, split, split_from, split_to, column_name,
                                     source_link_service_id, project_id, service, user_id, socket_flag, pipeline_id, pipeline_run_id)
            if file_name:
                data = {
                    "job_id": job_id,
                    "job_run_id": job_run_id,
                    "load_type": load_type,
                    "source_link_service_id": source_link_service_id,
                    "sink_link_service_id": sink_link_service_id,
                    "start": start_time,
                    "start_time_str": start_time_str,
                    "schema_name": schema_name,
                    "table_name": table_name,
                    "file_name": file_name,
                    "run_by": data["run_by"],
                    "split": split,
                    "split_id": split_id,
                    "index": "middle",
                    "user_id": user_id,
                    "socket_flag": socket_flag,
                    "s3_duration": s3_duration,
                    "pipeline_id": pipeline_id,
                    "pipeline_run_id": pipeline_run_id
                }
                producer.send(topic, value=data)
    except Exception:
        log.error(traceback.format_exc())
        if split:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            array_filters = [{"stat.split_id": split_id}]
            newvalues = {"$set": {"splits.$[stat].split_status_s3": "Fail",
                                  "splits.$[stat].split_status_sf": "Fail",
                                  "splits.$[stat].end_time_s3": int(datetime.utcnow().timestamp()),
                                  "splits.$[stat].copy_s3": None,
                                  "splits.$[stat].noofrows_read_sf": 0,
                                  "splits.$[stat].noofrows_written_sf": 0,
                                  "splits.$[stat].noofrows_skipped_sf": 0,
                                  "splits.$[stat].message": "Teradata DWH to s3 migration failed",
                                  "splits.$[stat].file_name":file_name}}
            db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                         array_filters)
        else:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            newvalues = {"$set": {"status_s3": "Fail", "status_sf": "Fail",
                                  "message": "Teradata to s3 migration failed"
                , "end_time_s3": int(datetime.utcnow().timestamp()),
                                  "noofrows_read_sf": 0,
                                  "noofrows_written_sf": 0,
                                  "noofrows_skipped_sf": 0,
                                   "copy_duration_s3": None,
                                  "file_name": file_name}}
            db.job_run_detail.update_one(updatequery, newvalues)
        return
    log.info("END")
