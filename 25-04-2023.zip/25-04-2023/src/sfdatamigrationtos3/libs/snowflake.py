query = {
    "check_schema_query": "select * from {database_name}.{schema_name}.{table_name} limit 1",
    "pre_copy_script" : "Truncate table {database_name}.{schema_name}.{table_name}"
}
